# LSV AIDE Compatibility Audit

This build keeps guest framework code Java 8 compatible and avoids lambda syntax.

## Compile-time API boundaries

The following optional Android APIs are accessed through reflection or explicit API guards where practical:

- `Application.getProcessName()`
- `PackageInfo.getLongVersionCode()`
- `Context.startForegroundService()`
- manifest `IntentFilter` scheme-specific-part APIs

The goal is to prevent an older/incomplete AIDE Android stub from producing an unknown-method error merely because the runtime device is newer.

## Runtime boundary

The guest still runs in LSV's `:guest` process. Android's own Activity/window token lifecycle remains authoritative; LSV keeps the virtual package identity, resources, services, permissions, and diagnostic state on the LSV side.

## Diagnostic persistence

Every important guest checkpoint is persisted to `virtual/diagnostics/<package>/active.txt`. This is intentional: a native crash or abrupt process death can happen before an uncaught Java exception is delivered.

## Verification

The preflight verifier checks APK structure, manifest, dex, package metadata, data directories, framework facades, source paths and diagnostic persistence before launch. It reports all checks instead of stopping at the first failure.
