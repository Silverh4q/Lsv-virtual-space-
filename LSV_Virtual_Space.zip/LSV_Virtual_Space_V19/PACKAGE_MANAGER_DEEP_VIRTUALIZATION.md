# LSV PackageManager Deep Virtualization

This layer makes the guest PackageManager model stateful and guest-owned.

Implemented:
- package/application metadata from imported APKs
- version name/code and source APK path
- requested permission declarations
- guest component enabled/disabled state
- Activity/Service/Receiver/Provider metadata queries
- manifest intent queries through the existing guest resolver
- guest application labels through GuestResourceSessionManager when labelRes exists
- guest Resources lookup from the imported APK
- signature SHA-256 digests from APK signing metadata
- package/application/component snapshots
- PackageManager information exposed through the framework Binder response
- ActivityManager lifecycle events create/visible/close corresponding guest WindowManager sessions
- overlay window sessions remain gated by LSV's virtual overlay permission

This intentionally does not register the guest package with Android system_server. Concrete Android framework objects remain host objects; guest operations cross the LSV mediation boundary.
