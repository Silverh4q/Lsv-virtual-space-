# AIDE compile-error fixes

This revision fixes the 14 errors shown in the supplied AIDE screenshots.

## Fixed files

### `app/src/main/java/com/lsv/virtualspace/process/GuestProcessState.java`
- Kept the mutable state model used by `GuestProcessSupervisor`.
- Added integer lifecycle constants and compatibility aliases `CREATED` and `PREPARED`.
- Added `nameOf(int)` for IPC status text.

### `app/src/main/java/com/lsv/virtualspace/process/GuestProcessService.java`
- Changed the service's runtime state field to `int` so comparisons use the integer lifecycle constants correctly.
- Removed invalid enum-style `CREATED`/`PREPARED` usage.
- `PREPARE` now moves the service to `READY`.

### `app/src/main/java/com/lsv/virtualspace/ipc/GuestProcessMessenger.java`
- Replaced invalid `state.name()` call with `GuestProcessState.nameOf(state.getState())`.

### `app/src/main/java/com/lsv/virtualspace/virtual/VirtualPackageManager.java`
- Added `getPackageInfo(String packageName)` and resolves the registered `VirtualApp` before reading APK metadata.

### `app/src/main/java/com/lsv/virtualspace/virtual/VirtualActivityManager.java`
- Added `findLaunchableActivity(String packageName)` used by the intent router.

### `app/src/main/java/com/lsv/virtualspace/virtual/GuestExecutionCapability.java`
- Added `isSupported()` as an API-compatible alias of `isAvailable()`.

### `app/src/main/AndroidManifest.xml`
- Removed `android:dataExtractionRules` because the AIDE/aapt environment shown in the screenshots does not provide that Android framework attribute.
- Kept the compatible `fullBackupContent` rules.

The `res/xml/data_extraction_rules.xml` resource remains in the project for newer build environments but is not referenced by the manifest, so older AIDE/aapt versions do not fail on the unsupported manifest attribute.
