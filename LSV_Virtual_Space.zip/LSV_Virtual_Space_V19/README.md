# LSV Virtual Space

This is the finalized app-controlled virtualization architecture for LSV Virtual Space.

## Removed

The original LSV memory/runtime tooling has intentionally been removed from this project:

- floating overlay/menu tooling
- memory scanning/patching code
- Frida components
- Dobby components
- KittyMemory components
- inline-hook libraries
- ESP overlay code
- native injection backend
- game hooking UI

The project is now a normal Android application foundation.

## Current milestone

The project has been finalized through the complete app-controlled virtualization architecture. It includes:

- AIDE-oriented Java 8 Android project
- APK import/export through Android Storage Access Framework
- private virtual APK/data storage
- virtual package/activity/service/provider metadata and routing
- guest application/context/resource/class-loader preparation boundaries
- dedicated `:guest` host process and Messenger/Binder-style IPC protocol
- lifecycle, task, service, provider, configuration, crash and restart handling
- graphics surface and input handoff contracts
- ABI/native-library diagnostics and staging without loading guest libraries into the host process
- Android-version compatibility diagnostics
- project-specific manifest, resources, themes, icon, storage and backup rules
- Google Play Services/Play Store compatibility detection without bundling proprietary Google packages

The project deliberately does not claim to replace Android's privileged AMS/PMS/system Binder services.

## Why

A non-root Android application cannot execute an arbitrary APK as a fully isolated Android installation merely by copying the APK into private storage. A real virtual runtime must reproduce/intercept important Android package, activity, service, provider, and process behavior.

The next implementation stage should integrate/adapt a VirtualApp-style runtime behind `com.lsv.virtualspace.virtual`.

## Reference

`Sandbox1.zip` was inspected for architectural reference. Its useful concepts include:

- VirtualCore
- virtual package management
- virtual activity management
- virtual process management
- application repository/catalog
- per-app virtualization

Its old implementation should not be copied wholesale into this project because it contains obsolete Android assumptions and native hooking dependencies that conflict with the clean AIDE/no-hooking goal.

## Google Play services

Google Play services and Play Store are intentionally not bundled here. They need a compatible runtime/system integration and should be handled as a separate compatibility phase.

## AIDE

The source deliberately avoids Java lambda syntax and external UI libraries. If the installed AIDE version uses a different Android Gradle Plugin range, the plugin version in the root `build.gradle` may need to be adjusted to the version bundled/supported by that AIDE release.


## APK installation flow

1. Open LSV Virtual Space.
2. Tap `ADD APK FROM STORAGE`.
3. Android's document picker opens.
4. Select an `.apk` from internal storage, Downloads, or another document provider.
5. LSV copies the APK into its private `virtual/apks` directory.
6. LSV parses the APK package name and application label.
7. A private data directory is created for the virtual app.
8. The app appears under `Installed in LSV`.
9. `REMOVE` deletes the registered APK and its private LSV data.

This is a sandbox registration/install step. It does not call Android's normal
system installer and does not claim that the guest APK is already executing
inside an isolated Android process.

## Steps 5-10 integration

The project now contains one isolated guest-runtime preparation layer covering:

- guest APK dex/resource artifact loading
- guest activity/service/provider metadata resolution
- per-package class-loader registry
- guest permission policy and private data-path policy
- native-library/ABI/runtime diagnostics
- Google Play Services / Play Store compatibility reporting
- a `GuestEngine` boundary for a future full process/Binder virtualization backend

The current `PreparationGuestEngine` intentionally reports execution as unavailable. This prevents LSV from launching an APK as if it were isolated when the required Android framework virtualization layer is not actually present.

## Package name

The project package/namespace is already standardized as:

`com.lsv.virtualspace`

This value is used by `applicationId`, Gradle `namespace`, and the Java package tree. The user-facing application name remains **LSV Virtual Space**.

Do not rename only the Java folders: if you ever change the package later, update the Java package declarations, directory tree, Gradle `namespace`, `applicationId`, and any manifest component names together.


## Steps 11-20
The project now includes a preparation/diagnostic runtime coordinator, guest resource and
DexClassLoader preparation, intent routing metadata, lifecycle registry, storage layout, and
capability gating. Arbitrary guest process/Binder execution is still disabled by design.

## Steps 21-50
This build adds the next virtualization support layers: component/lifecycle registries, isolation policies, graphics/input/performance capability detection, storage quota/cache handling, crash/service diagnostics, and a game compatibility catalog.

Known game profiles are informational and compatibility-focused. They do not implement cheats, anti-cheat bypasses, memory editing, DLL/SO injection, or integrity circumvention.

## Steps 51-70
The project now contains a pluggable guest-process contract, process supervisor,
isolation policy, component table, backend registry, and Stage70Runtime coordinator.
The default bridge intentionally rejects execution because a real Android framework
virtualization backend is not present. This prevents a copied APK from being
mistaken for an actually running isolated Android process.


### Steps 71-90
The project now includes a framework-facing host proxy Activity, virtual task routing, logical service/provider routing, per-guest permission/configuration contexts, ABI-specific native staging, a graphics surface contract, and crash boundaries. The proxy deliberately does not fake arbitrary guest execution.

## Steps 91-110

This release adds the framework virtualization boundary: guest-scoped Binder request/reply models, service binding bookkeeping, provider authority namespacing, package session lifecycle, and host proxy lifecycle integration. Unsupported privileged system operations are reported explicitly. The project does not hook Android's system Binder or claim to replace AMS/PMS.

## Steps 111-130

The project now contains a guest application boundary for bootstrap planning, virtual context paths, resource sessions, component construction plans, and Android-version compatibility. The proxy Activity can prepare and display this metadata without installing the guest APK into Android or executing untrusted guest code in the LSV host process.


### Steps 131-150: process and storage boundary
The project now has a dedicated `:guest` host process boundary, lifecycle commands, storage permission handling, SAF-based APK export, and project-specific XML/resource files. Android 13+ relies on user-selected SAF access rather than broad external-storage permissions. The project now includes an embedded VirtualApp-style guest engine based on the supplied Sandbox reference. Launch first attempts virtual installation/execution through the engine and falls back to Android PackageInstaller when the device/runtime cannot support the virtual path.

## Steps 151-170

Added the dedicated guest-process IPC/lifecycle boundary, Messenger protocol, process client, activity-result routing, crash/restart policy, configuration bridge, graphics surface handoff, input boundary, and an explicit AndroidManifest audit. The project remains Java 8/AIDE-friendly with no Java lambda syntax and native C/C++ code is present in the embedded `virtual-engine` module; it is the native runtime layer from the supplied Sandbox reference and currently targets armeabi-v7a.

Storage uses the Android Storage Access Framework for modern Android. Legacy READ/WRITE_EXTERNAL_STORAGE permissions are declared only for Android versions where those permissions apply.

## Real APK launch behavior

The Launch action now has an explicit Android compatibility path. When the virtual execution backend is unavailable, LSV can invoke Android's PackageInstaller with user confirmation and then launch the installed package. This provides genuine Android Activity/native/graphics/service execution under Android's own application sandbox.

This compatibility path is deliberately not described as virtual execution. A normal non-root app cannot replace Android's privileged ActivityManager/PackageManager/Binder services, so LSV does not silently execute arbitrary third-party APK code inside its own UID.

## Real guest execution backend

The current build now attempts actual in-process guest execution from the LSV private repository. Launching a virtual app starts the dedicated `:guest` process, builds a guest `DexClassLoader`, loads guest resources and matching native libraries, creates a guest `Application` with a private `GuestContext`, and attaches/lifecycles the declared launcher `Activity`. The Android package-install compatibility route remains an explicit fallback only.

The runtime reports framework-attachment failures instead of displaying a fake running state. Compatibility depends on the Android/OEM framework because ActivityThread/Activity attachment is not exposed as a public SDK API on modern Android.

## Real virtual guest execution stage

The current launch path uses a dedicated `:guest` process and `GuestInstrumentation` to substitute a registered guest Activity while Android's ActivityThread performs the actual framework lifecycle. The target is not sent to the host PackageManager as the primary Launch action. See `REAL_VIRTUAL_GUEST_STAGE.md`.

## Continuous implementation / verification rule

LSV runtime work is not considered complete when a single subsystem has merely been added. Each implementation pass must continue through its dependent framework boundaries, add diagnostics, perform static compatibility audits, and leave the runtime in a state where the next boundary can be exercised. Runtime claims require actual Android/AIDE execution evidence; architecture alone is not treated as proof of compatibility.

See `DIAGNOSTIC_RUNTIME_CHAIN.md`.
