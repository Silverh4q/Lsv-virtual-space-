# Sandbox reference note

`Sandbox1.zip` was inspected to understand its VirtualApp-style architecture: virtual package/activity/service/provider management, stub components, Binder IPC, guest process bootstrap, storage redirection, and native runtime boundaries.

The incompatible `com.lody.*` implementation is **not copied into LSV's build**. LSV uses its own package namespace (`com.lsv.virtualspace`) and AIDE-safe Java/public Android APIs instead.
