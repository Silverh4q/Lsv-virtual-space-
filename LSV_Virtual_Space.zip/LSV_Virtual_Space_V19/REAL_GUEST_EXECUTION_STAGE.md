# LSV real guest execution stage

This stage is the first LSV implementation that attempts to execute guest APK code rather than showing a metadata/proxy screen.

## Runtime path

1. Guest APK remains in LSV private storage.
2. `DexClassLoader` loads the guest base/split APK dex files.
3. Guest native libraries matching the device ABI are extracted to the guest's private native directory.
4. Guest resources are loaded into an independent `AssetManager`/`Resources` instance.
5. `GuestContext` supplies the guest package identity and private data directories.
6. The declared guest `Application` is instantiated and attached.
7. The declared launcher `Activity` is instantiated and attached to the host stub Activity's window token.
8. `Instrumentation` drives the guest Activity lifecycle.
9. The guest Activity and Application are kept alive by `InProcessGuestRuntime`.

The guest Activity proxy runs in the dedicated `:guest` process, so guest execution is separated from the LSV launcher UI process.

## Platform boundary

The Activity/Application attachment step uses framework reflection because Android does not expose those constructors as public SDK APIs. Android versions/OEM builds that block the required hidden framework calls will return a concrete execution error instead of pretending the guest is running.

This is intentionally a version-gated execution backend. It does not install the guest into Android's real PackageManager and does not modify or bypass another application's integrity/anti-cheat systems.
