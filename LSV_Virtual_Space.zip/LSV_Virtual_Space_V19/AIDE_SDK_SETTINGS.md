# LSV Virtual Space — AIDE SDK settings

The app module intentionally uses direct numeric Gradle values because some AIDE/older Gradle integrations do not correctly resolve local Groovy variables when generating the Android manifest.

Edit these lines in `app/build.gradle`:

```groovy
compileSdkVersion 35
minSdkVersion 23
targetSdkVersion 35
versionCode 1
versionName '1.0.0'
```

## What they mean
- `compileSdkVersion`: Android SDK used to compile the project. Set this to an SDK installed in AIDE.
- `minSdkVersion`: Oldest Android API level allowed to install the APK.
- `targetSdkVersion`: Android behavior target declared by the app.
- `versionCode`: Integer update/build number.
- `versionName`: Human-readable app version.

For this project the defaults are compile/target SDK 35 and minimum SDK 23. If AIDE does not have SDK 35 installed, change only `compileSdkVersion 35` and `targetSdkVersion 35` to a locally installed SDK level. Keep `minSdkVersion 23` unless you intentionally want to drop support for older Android versions.

Do not replace `versionCode 1` with a quoted string; Android requires `versionCode` to be an integer.
