# LSV Proxy Lifecycle / Android 36

The launch path no longer reflectively invokes `android.app.Activity.attach` or
tries to make a guest Activity object look like an Android-managed Activity.

`GuestActivityProxy` is the real declared Android Activity. `GuestProxyLifecycleController`
keeps LSV virtual task/component/session state synchronized with that real Activity.
The hand-off uses public PackageManager/PackageInstaller APIs.

This is intentionally different from an old VirtualApp implementation that patched
private ActivityManager/PackageManager/Binder services. Modern Android can block
those hidden APIs, and a normal application cannot replace those system services
using only public SDK calls.

The project therefore has two layers:

1. LSV virtual package/component/storage state and proxy lifecycle.
2. Android-managed application execution for arbitrary APK code.

For an imported APK that is not installed, Android's PackageInstaller confirmation
is required. For an already-installed package, LSV launches its normal launcher.

This removes the previous `Activity.attach` failure from the primary launch path.
