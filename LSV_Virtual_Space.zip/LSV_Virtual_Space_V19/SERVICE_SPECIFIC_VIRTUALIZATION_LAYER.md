# LSV service-specific virtualization layer

This layer turns the earlier system-service facade into stateful guest-scoped adapters.

## Implemented
- PackageManager facade: package/application/component metadata, explicit component lookup, manifest-driven activity/service/receiver intent queries, installed guest package/application snapshots, requested-permission presence checks.
- ActivityManager: reuses the existing central GuestActivityManager and manifest resolver.
- WindowManager: guest window/overlay sessions and visibility state; overlay remains controlled by LSV's virtual permission.
- NotificationManager: guest notification/channel namespace state with post/cancel operations.
- Clipboard: guest-private primary clipboard state instead of sharing host clipboard state through the virtual path.
- Location: guest-scoped update subscription state behind the virtual location permission boundary.
- Connectivity: guest-scoped network-state namespace.
- Power: guest-scoped wakelock state.
- Account: guest-scoped account namespace.

## Important boundary
The adapters are not pretending to replace Android framework classes with unrelated objects. `Context.getSystemService()` still returns the real Android service object for binary/API compatibility. Guest-sensitive operations that are explicitly mediated use the LSV framework/Binder path and are backed by virtual state.

A complete transparent `PackageManager`/`WindowManager` object replacement still requires a compatible framework proxy strategy on each Android release; this layer deliberately avoids hidden `Activity.attach`/framework-field mutation.
