# LSV VirtualApp-style guest engine

LSV now includes the VirtualApp-style engine from the supplied `Sandbox1.zip` as a dedicated `virtual-engine` library module.

## What the reference project was doing

The reference is not a conventional emulator. It uses application-level virtualization:

- a virtual package manager/catalog
- stub Activities/Services/Providers declared in the host manifest
- an engine/server process
- Binder IPC between the host and virtual process
- ActivityManager/PackageManager interception through the app process
- `Application`/Activity bootstrap through the Android runtime
- native I/O/Dex redirection for the guest process
- virtual per-app storage
- native code for path and runtime redirection

That is why a non-root virtual-space product can execute guest applications without installing every guest package into the host PackageManager.

## LSV integration

The engine is isolated in `virtual-engine/` and exposed through `VirtualAppEngine`.

The normal launch path is now:

`LSV APK repository -> VirtualAppEngine -> VirtualCore.installPackage -> virtual PackageManager -> stub Activity -> guest process -> guest Application/Activity`

If engine startup or guest launch fails on a particular Android/vendor build, LSV retains its Android PackageInstaller compatibility fallback.

## ABI note

The supplied Sandbox native engine is an older 32-bit native implementation. LSV currently builds the native engine for `armeabi-v7a`, matching the supplied source rather than falsely claiming arm64 support. A true arm64 engine needs a separate arm64-safe native hook/runtime implementation and cannot be produced by merely changing the ABI filter.

## Modern Android note

The reference relies on hidden/internal Android APIs and native runtime behavior. Android versions and OEM builds can change those internals. The LSV wrapper therefore reports startup/launch failures and preserves a normal Android launch fallback rather than silently claiming universal compatibility.

## Google services

The engine contains the reference project's Google-services integration hooks (`GmsSupport`). This does not bundle proprietary Google APKs. Google Play Services/Play Store must be present on the device and their packages must be legally available to the virtual environment.
