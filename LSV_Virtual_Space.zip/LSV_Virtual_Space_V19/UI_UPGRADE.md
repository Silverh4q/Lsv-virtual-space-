# LSV Virtual Space UI / App Source Upgrade

This build upgrades the main LSV interface without external UI libraries.

## Add application
The `+ Add` action now offers:
- Installed apps on this phone: lists visible non-system user applications and attempts to copy the selected host APK into LSV.
- APK file from storage: uses Android Storage Access Framework.

Copying an installed APK does not uninstall or modify the host application. Android may restrict direct access to an installed APK on some devices; in that case the UI explains that the storage picker can be used instead.

## Themes
Themes are stored in SharedPreferences and survive app restarts:
- System default
- Light
- Dark
- Black
- White

No AppCompat or external dependency is required.

## UI
- Toolbar with application count and theme control
- Rounded virtual-app cards
- App icons from imported APK metadata
- Launch / Export / Remove actions
- Empty-state screen
- Refined guest proxy screen using the same theme

## Android permissions
`QUERY_ALL_PACKAGES` is declared because listing installed applications is an explicit core feature of this app. Legacy storage permissions remain version-limited; modern import/export uses SAF.

## Launch fallback

The Launch action now offers an explicit **Android compatibility launch** when the true virtual execution backend is unavailable. Android is asked to install the selected APK with user confirmation and then launch it. This is the reliable full-execution path for arbitrary APKs on a normal non-root device; it is not a virtual install.
