# LSV System-Service Mediation Layer

This layer sits after the virtual package/component resolver and before Android system-service use.

## Boundary

Guest Context -> GuestSystemServiceFacade -> GuestSystemServicePolicy -> host Android service

The facade attaches the guest package name and LSV virtual UID to every mediated request. Virtual policy/state is kept separate from the host package identity.

## Services covered by the facade

- PackageManager
- ActivityManager
- WindowManager
- NotificationManager
- ClipboardManager
- LocationManager
- ConnectivityManager
- PowerManager
- AccountManager
- AlarmManager
- Vibrator
- SensorManager
- Telephony
- AudioManager
- InputMethodManager

Concrete Android service objects are deliberately still returned by `getSystemService()` for compatibility. Replacing concrete framework classes with arbitrary Java facade objects would cause casts in real applications to fail. Operations that require virtualization use `GuestContext.requestSystemService()` and the Binder-backed `SYSTEM_SERVICE_REQUEST` operation.

## Policy

`GuestSystemServicePolicy` gates operations against the virtual permission database. Overlay is mediated by LSV state rather than pretending the guest package owns Android's real `SYSTEM_ALERT_WINDOW` grant. Location and account operations can likewise be checked against virtual grants.

## Next expansion

The next stage can add service-specific adapters where Android permits safe mediation without hidden API access, then progressively move package/activity/window/notification/clipboard/provider operations behind Binder while preserving the concrete Android API types visible to guest code.
