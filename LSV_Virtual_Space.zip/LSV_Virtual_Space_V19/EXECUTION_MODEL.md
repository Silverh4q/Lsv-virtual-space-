# LSV execution model

LSV now has two explicit launch paths:

1. **Virtual preparation**: the APK remains in LSV private storage and LSV resolves its package/activity/resources/process metadata. This path does not claim arbitrary guest Activity execution because a normal Android app cannot replace the privileged ActivityManager/PackageManager/Binder services.
2. **Android compatibility launch**: when full execution is required, LSV uses Android's PackageInstaller with explicit user confirmation. Android then gives the APK its normal application UID, framework lifecycle, graphics, native-library loading, permissions and services. This is a real launch, but it is an Android installation rather than a virtualized guest.

The compatibility path is intentionally explicit so LSV never silently installs or runs an imported APK outside its virtual repository.
