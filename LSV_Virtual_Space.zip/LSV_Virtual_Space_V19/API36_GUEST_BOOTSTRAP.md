# API 36 guest bootstrap

The guest runtime now performs a best-effort hidden-framework compatibility step before resolving `Activity.attach`.

It first requests VMRuntime hidden-API exemptions for the small set of framework classes needed by the LSV guest bootstrap, then resolves the runtime `Activity.attach` signature dynamically rather than assuming one fixed Android release signature.

This is intentionally isolated in `HiddenApiBridge` and does not depend on a copied VirtualApp framework.

If an OEM build still refuses the exemption, LSV reports the actual framework failure instead of presenting a false running state. A normal Android application cannot guarantee access to hidden framework APIs on every OEM/API build.
