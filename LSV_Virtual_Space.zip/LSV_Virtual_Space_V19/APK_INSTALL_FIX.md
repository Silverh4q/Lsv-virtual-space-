# APK installation fix

The uploaded APK that failed installation was inspected directly. It was ZIP-valid and had a valid legacy v1 signature, but it had no APK Signature Scheme v2/v3 signing block. The final fixed APK is signed with APK Signature Scheme v2 using SHA-256/RSA and has a clean APK ZIP without the old conflicting v1 signature files.

The app module also explicitly enables both v1 and v2 signing for the AIDE/Gradle debug build when supported by the installed Android Gradle Plugin.

SDK settings remain direct values:
- compileSdkVersion 35
- minSdkVersion 23
- targetSdkVersion 35
- versionCode 1
- versionName 1.0.0
- applicationId com.lsv.virtualspace

AIDE may use its own embedded build/signing toolchain depending on how the project is imported. The prebuilt APK in `prebuilt/` is provided as the directly installable artifact from this repair.
