# Engine boundary

The previous implementation attempted to instantiate an arbitrary guest Activity
and invoke the hidden `Activity.attach` method. On the tested Android 36 device,
that produced `NoSuchMethodException: android.app.Activity.attach is hidden`.

That approach has been removed from the active launch path.

A complete private-framework virtualizer would need privileged/internal framework
service interception (ActivityManager, PackageManager, ActivityThread/Instrumentation,
Binder and window/task management) plus Android-version-specific native support.
Those are not replaced by a single reflection call. LSV now keeps the public-API
proxy route as the reliable execution boundary rather than reporting a fake guest
Activity as running.
