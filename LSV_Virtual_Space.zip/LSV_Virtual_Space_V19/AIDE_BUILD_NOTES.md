# AIDE build notes

## SDK values

Edit only these direct values in `app/build.gradle`:

```groovy
compileSdkVersion 35
minSdkVersion 23
targetSdkVersion 35
versionCode 1
versionName '1.0.0'
```

## Signing

There is intentionally **no custom `signingConfigs` block** in the app module. AIDE/Gradle supplies its normal debug signing configuration automatically for debug builds. This avoids AIDE versions that reject `v1SigningEnabled`/`v2SigningEnabled` inside the project Gradle script.

For a release APK, configure a real keystore through AIDE's release-signing UI rather than hard-coding a private keystore password in this project.

## Native engine

The `virtual-engine` module uses Android NDK build files from the supplied Sandbox reference and currently targets `armeabi-v7a` because that is the ABI implemented by the reference native hook layer.
