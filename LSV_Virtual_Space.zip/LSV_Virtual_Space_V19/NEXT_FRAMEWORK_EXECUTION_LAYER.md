# LSV Virtual Space — Framework Execution Layer

This layer continues directly from the Framework Service Virtualization build.
It is package-agnostic and uses imported guest APK metadata as the source of
component identity.

## Implemented in this layer

- Central `GuestPackageManagerFacade` over the virtual package registry.
- Guest Service proxy now loads the declared Service class with the guest
  `DexClassLoader` and dispatches `onCreate`, `onStartCommand`, `onBind`,
  `onUnbind`, and `onDestroy` through `GuestServiceManager`.
- Service instances and binding counts are tracked per virtual package and
  component.
- Guest BroadcastReceiver proxy now loads and executes the declared receiver
  class. Explicit receiver components are routed directly; absent an explicit
  receiver, exported receivers are used as the current manifest-metadata
  fallback.
- Guest ContentProvider host creates the declared provider class, attaches it
  using Android's public `ContentProvider.attachInfo`, and exposes query/call,
  getType, insert, delete, and update operations through the framework Binder
  boundary.
- Provider instances are cached by virtual package + authority and shut down
  when the virtual package is cleared.
- Receiver and Service execution occurs through the `:guest` process endpoints.

## Deliberate boundary

This is not a claim that Android's global PackageManager/ActivityManager has
been replaced. The virtual PackageManager is an LSV facade and the framework
Binder service is the mediation boundary. Host system_server still owns the
real installed-package database.

The next framework work is to make component resolution and system-service
mediation more complete, including manifest intent-filter resolution, guest
permission state, virtual storage identities, and cross-process state.

No game-specific, Unity-specific, anti-cheat, memory-editing, or injection code
is included.

## AIDE compatibility

Java source is kept Java-8 style with no lambda expressions. This package was
structurally audited; compilation still needs to be performed by AIDE against
its configured Android SDK because this environment does not contain the
project's Android SDK/Gradle toolchain.
