# LSV Virtual Space — Final Project Audit

## Project identity
- Application/package: `com.lsv.virtualspace`
- User-facing name: `LSV Virtual Space`
- Java source/target: 8
- Minimum Android API: 23
- Target/compile API: 33
- No Java lambda expressions
- Native C/C++ sources are present only in `virtual-engine/`, isolated from the LSV UI/application layer
- No Frida, Dobby, KittyMemory, inline hooking, memory editing, ESP, DLL/SO injection, or anti-cheat bypass components

## Android application surface
- `LsvApplication` initializes the virtual runtime.
- `MainActivity` provides APK import, virtual-app listing, launch routing, APK export, and removal.
- `GuestActivityProxy` is the host Activity routing endpoint.
- `GuestProcessService` provides the dedicated `:guest` host-process boundary.
- `AndroidManifest.xml` explicitly declares all application components and API-limited legacy storage permissions.
- Modern APK import/export uses the Storage Access Framework.
- App icon, themes, colors, dimensions, strings, file paths, and backup/data-extraction resources are included.

## Virtual package/runtime surface
- APK archive inspection and virtual package catalog.
- Activity/service/provider/receiver/permission metadata resolution.
- Private per-package APK and data storage.
- Guest class-loader/resource preparation boundaries.
- Virtual Activity/task routing.
- Guest service and provider routing/bookkeeping.
- Guest-scoped Binder request/reply models.
- Guest lifecycle and package session state.
- Dedicated guest process lifecycle/IPC boundary.
- Configuration, graphics, input, ABI/native-library, performance, storage, and crash diagnostics.
- Game compatibility profiles are informational only.

## Storage
- LSV-owned guest files remain under the application's private storage.
- APK import uses `ACTION_OPEN_DOCUMENT`.
- APK export uses `ACTION_CREATE_DOCUMENT`.
- Legacy `READ_EXTERNAL_STORAGE` is declared/requested only through API 32.
- Legacy `WRITE_EXTERNAL_STORAGE` is declared only through API 28.
- `MANAGE_EXTERNAL_STORAGE` is intentionally not requested.
- Backup rules exclude the internal `virtual/` repository from automatic backup/data transfer.

## Important platform boundary
A normal non-root Android application cannot replace or globally intercept Android's privileged ActivityManagerService, PackageManagerService, system Binder, or install an arbitrary APK as an isolated virtual Android application purely from public application APIs. This project therefore implements the complete app-controlled virtualization architecture and explicit host/process/framework boundaries without falsely claiming privileged framework replacement.

A truly arbitrary third-party APK runtime on modern Android requires a dedicated, version-specific virtualization engine with deeper framework integration, and some applications (especially games using demanding native/graphics/platform features) may still require capabilities unavailable to a normal application. The project does not bypass those Android security boundaries.

## Audit result
The source tree was statically audited for:
- malformed XML
- manifest component references
- missing internal Java imports
- brace imbalance
- Java lambda syntax
- native source files
- stale prohibited tooling references in executable source

The project is packaged as an AIDE-oriented Android Java project. An actual Android build should be performed by AIDE or another environment containing the Android SDK and the configured Android Gradle Plugin.
