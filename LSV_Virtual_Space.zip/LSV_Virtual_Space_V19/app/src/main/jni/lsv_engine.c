/*
 * LSV native ABI bridge.
 * This is deliberately small and self-contained so AIDE can package a
 * prebuilt ARM library without requiring a project-wide NDK build.
 * Virtualization policy remains in the Java LSV engine.
 */
__attribute__((visibility("default"))) int lsv_engine_version(void) {
    return 1;
}
