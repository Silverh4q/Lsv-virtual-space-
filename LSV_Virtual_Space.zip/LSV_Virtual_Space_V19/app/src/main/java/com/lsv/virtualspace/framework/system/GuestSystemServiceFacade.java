package com.lsv.virtualspace.framework.system;

import android.content.Context;
import android.os.Bundle;
import java.util.HashMap;
import java.util.Map;
import com.lsv.virtualspace.framework.identity.GuestIdentity;
import com.lsv.virtualspace.framework.identity.GuestIdentityManager;
import com.lsv.virtualspace.framework.permissions.GuestPermissionManager;
import com.lsv.virtualspace.framework.packages.GuestPackageManagerFacade;
import com.lsv.virtualspace.framework.packages.GuestPackageRegistry;
import com.lsv.virtualspace.framework.runtime.GuestActivityManager;
import com.lsv.virtualspace.framework.system.adapters.*;

/** One service-specific mediation boundary shared by every guest process. */
public final class GuestSystemServiceFacade {
 private final Context hostContext; private final GuestIdentityManager identities; private final GuestPermissionManager permissions;
 private final GuestSystemServicePolicy policy; private final GuestSystemServiceState state; private final Map<String,GuestSystemServiceAdapter> adapters=new HashMap<String,GuestSystemServiceAdapter>();
 private GuestPackageManagerFacade packageManager; private GuestActivityManager activityManager;
 public GuestSystemServiceFacade(Context c,GuestIdentityManager i,GuestPermissionManager p){hostContext=c.getApplicationContext();identities=i;permissions=p;policy=new GuestSystemServicePolicy(p);state=new GuestSystemServiceState(this.hostContext);register(new GuestWindowManagerAdapter());register(new GuestNotificationManagerAdapter());register(new GuestClipboardAdapter());register(new GuestLocationAdapter());register(new GuestConnectivityAdapter());register(new GuestPowerAdapter());register(new GuestAccountAdapter());}
 public synchronized void attachPackageManager(GuestPackageManagerFacade facade){packageManager=facade;}
 public synchronized void attachActivityManager(GuestActivityManager m){activityManager=m;}
 public synchronized GuestPackageManagerFacade getPackageManagerFacade(){return packageManager;}
 public synchronized GuestActivityManager getActivityManager(){return activityManager;}
 public Object getService(String pkg,String name){if(pkg==null||name==null||!policy.canAcquireService(pkg,name))return null;return hostContext.getSystemService(name);}
 public GuestSystemServiceRequest request(String pkg,String service,String operation,Bundle args){GuestIdentity id=identities.get(pkg);int uid=id==null?-1:id.getVirtualUid();if(!policy.canUse(pkg,service,operation))return null;return new GuestSystemServiceRequest(pkg,uid,service,operation,args);}
 public synchronized Bundle dispatch(String pkg,String service,String operation,Bundle args){GuestSystemServiceRequest r=request(pkg,service,operation,args);if(r==null)return null;GuestSystemServiceAdapter a=adapters.get(service);if(a==null||!a.canHandle(operation))return null;return a.handle(pkg,r,state);}
 public synchronized void register(GuestSystemServiceAdapter a){if(a!=null)adapters.put(a.getServiceName(),a);}
 public GuestSystemServicePolicy getPolicy(){return policy;} public GuestSystemServiceState getState(){return state;} public GuestIdentity getIdentity(String pkg){return identities.getOrCreate(pkg);}
 public void setOverlayAllowed(String pkg,boolean allowed){permissions.setOverlayAllowed(pkg,allowed);state.put(pkg,GuestSystemServiceName.WINDOW,"overlayAllowed",String.valueOf(allowed));}
}
