package com.lsv.virtualspace.framework;

import java.util.HashMap;
import java.util.Map;

public final class GuestTaskManager {
    private final Map<String, GuestTaskRecord> tasks = new HashMap<String, GuestTaskRecord>();

    public synchronized GuestTaskRecord open(String packageName, String componentName) {
        GuestTaskRecord record = new GuestTaskRecord(packageName, componentName);
        tasks.put(packageName, record);
        record.setForeground(true);
        return record;
    }

    public synchronized GuestTaskRecord get(String packageName) {
        return tasks.get(packageName);
    }

    public synchronized void close(String packageName) {
        tasks.remove(packageName);
    }
}
