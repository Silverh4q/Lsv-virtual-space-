package com.lsv.virtualspace.engine;
public final class GuestEngineState {
    public static final int NEW=0, PREPARING=1, READY=2, RUNNING=3, STOPPING=4, STOPPED=5, FAILED=6;
    private final int state; private final String message;
    public GuestEngineState(int state,String message){this.state=state;this.message=message;}
    public int getState(){return state;} public String getMessage(){return message;}
}
