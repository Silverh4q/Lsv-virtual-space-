package com.lsv.virtualspace.framework.ipc;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

import com.lsv.virtualspace.framework.binder.GuestBinderCode;
import com.lsv.virtualspace.framework.binder.GuestBinderReply;

/** Client for the host framework Binder. Connection is lazy and process-local. */
public final class GuestFrameworkClient {
    private final Context context;
    private final String packageName;
    private final Object lock = new Object();
    private IBinder binder;
    private boolean connecting;

    public GuestFrameworkClient(Context context, String packageName) {
        this.context = context.getApplicationContext();
        this.packageName = packageName;
    }

    public GuestBinderReply dispatch(GuestBinderCode code, String component, Bundle data) {
        IBinder target = ensureConnected(1200L);
        if (target == null) return GuestBinderReply.fail("LSV framework Binder is not connected");
        Parcel request = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            request.writeString(packageName);
            request.writeString(code.name());
            request.writeString(component);
            request.writeBundle(data == null ? new Bundle() : data);
            target.transact(GuestFrameworkService.TRANSACTION_DISPATCH, request, reply, 0);
            boolean success = reply.readInt() != 0;
            String message = reply.readString();
            Bundle result = reply.readBundle(getClass().getClassLoader());
            return success ? GuestBinderReply.ok(result) : GuestBinderReply.fail(message);
        } catch (Throwable error) {
            return GuestBinderReply.fail(error.toString());
        } finally {
            request.recycle();
            reply.recycle();
        }
    }

    private IBinder ensureConnected(long timeoutMs) {
        synchronized (lock) {
            if (binder != null && binder.isBinderAlive()) return binder;
            if (!connecting) {
                connecting = true;
                Intent intent = new Intent(context, GuestFrameworkService.class);
                try {
                    context.bindService(intent, new ServiceConnection() {
                        public void onServiceConnected(ComponentName name, IBinder service) {
                            synchronized (lock) {
                                binder = service;
                                connecting = false;
                                lock.notifyAll();
                            }
                        }
                        public void onServiceDisconnected(ComponentName name) {
                            synchronized (lock) { binder = null; }
                        }
                    }, Context.BIND_AUTO_CREATE);
                } catch (Throwable error) {
                    connecting = false;
                }
            }
            long end = System.currentTimeMillis() + timeoutMs;
            while (binder == null && System.currentTimeMillis() < end) {
                try { lock.wait(50L); } catch (InterruptedException ignored) { break; }
            }
            return binder;
        }
    }
}
