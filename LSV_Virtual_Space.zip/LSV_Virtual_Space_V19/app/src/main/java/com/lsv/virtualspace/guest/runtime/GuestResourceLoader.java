package com.lsv.virtualspace.guest.runtime;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.Configuration;
import android.util.DisplayMetrics;

import com.lsv.virtualspace.hidden.HiddenApiBootstrap;

import java.lang.reflect.Method;
import java.util.List;

/** Creates guest resources from the base APK and its split APKs. */
public final class GuestResourceLoader {
    private GuestResourceLoader() { }

    public static Resources create(Context host, List<String> apkPaths) throws Exception {
        if (host == null) throw new IllegalArgumentException("host == null");
        if (apkPaths == null || apkPaths.size() == 0) {
            throw new IllegalStateException("Guest APK list is empty");
        }
        HiddenApiBootstrap.initialize(host);
        AssetManager assets = AssetManager.class.newInstance();
        Method addAssetPath = AssetManager.class.getDeclaredMethod("addAssetPath", String.class);
        addAssetPath.setAccessible(true);
        boolean added = false;
        for (String path : apkPaths) {
            if (path == null || path.length() == 0) continue;
            java.io.File file = new java.io.File(path);
            if (!file.isFile() || !file.canRead()) {
                throw new IllegalStateException("Guest resource APK is unreadable: " + path);
            }
            Object result = addAssetPath.invoke(assets, path);
            if (result instanceof Integer && ((Integer) result).intValue() != 0) {
                added = true;
            } else {
                throw new IllegalStateException("Guest AssetManager rejected APK: " + path);
            }
        }
        if (!added) throw new IllegalStateException("Guest resources could not be attached");
        DisplayMetrics metrics = new DisplayMetrics();
        metrics.setTo(host.getResources().getDisplayMetrics());
        Configuration configuration = new Configuration(host.getResources().getConfiguration());
        Resources hostResources = host.getResources();
        Resources resources = new Resources(assets, metrics, configuration);
        // Force an initial configuration snapshot so guest resources use the
        // device locale/density while remaining backed by guest APK assets.
        try { resources.updateConfiguration(configuration, metrics); } catch (Throwable ignored) { }
        return resources;
    }
}
