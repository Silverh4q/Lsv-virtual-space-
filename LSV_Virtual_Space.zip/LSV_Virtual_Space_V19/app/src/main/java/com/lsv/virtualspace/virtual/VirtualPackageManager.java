package com.lsv.virtualspace.virtual;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.apps.VirtualAppRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * Read-only package metadata service for applications registered in LSV.
 *
 * It deliberately uses Android's APK parser rather than pretending that the
 * virtual package is installed in the host PackageManager.
 */
public class VirtualPackageManager {
    private final Context context;
    private final VirtualAppRepository repository;

    public VirtualPackageManager(Context context, VirtualAppRepository repository) {
        this.context = context.getApplicationContext();
        this.repository = repository;
    }

    public List<VirtualApp> getInstalledApps() {
        return repository.getApps();
    }

    public PackageInfo getPackageInfo(String packageName) {
        if (packageName == null) {
            return null;
        }
        List<VirtualApp> apps = repository.getApps();
        for (VirtualApp app : apps) {
            if (packageName.equals(app.getPackageName())) {
                return getPackageInfo(app);
            }
        }
        return null;
    }

    public PackageInfo getPackageInfo(VirtualApp app) {
        PackageManager pm = context.getPackageManager();
        return pm.getPackageArchiveInfo(
            app.getApkPath(),
            PackageManager.GET_ACTIVITIES |
            PackageManager.GET_SERVICES |
            PackageManager.GET_PROVIDERS |
            PackageManager.GET_RECEIVERS |
            PackageManager.GET_PERMISSIONS |
            (android.os.Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES)
        );
    }

    public List<ActivityInfo> getLaunchableActivities(VirtualApp app) {
        List<ActivityInfo> result = new ArrayList<ActivityInfo>();
        PackageInfo info = getPackageInfo(app);

        if (info == null || info.activities == null) {
            return result;
        }

        for (ActivityInfo activity : info.activities) {
            if (activity.exported) {
                result.add(activity);
            }
        }

        return result;
    }

    public ApplicationInfo getApplicationInfo(VirtualApp app) {
        PackageManager pm = context.getPackageManager();
        PackageInfo info = getPackageInfo(app);

        if (info == null || info.applicationInfo == null) {
            return null;
        }

        ApplicationInfo ai = info.applicationInfo;
        ai.sourceDir = app.getApkPath();
        ai.publicSourceDir = app.getApkPath();
        return ai;
    }
}
