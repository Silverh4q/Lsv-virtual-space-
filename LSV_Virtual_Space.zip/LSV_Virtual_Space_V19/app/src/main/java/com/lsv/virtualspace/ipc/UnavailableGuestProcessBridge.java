package com.lsv.virtualspace.ipc;

public final class UnavailableGuestProcessBridge implements GuestProcessBridge {
    public boolean isAvailable(){return false;}
    public GuestLaunchResult prepare(GuestLaunchRequest r){return GuestLaunchResult.rejected("No real guest process backend is installed.");}
    public GuestLaunchResult start(GuestLaunchRequest r){return GuestLaunchResult.rejected("Guest execution remains disabled until a supported virtualization backend is installed.");}
    public void stop(String p){}
}
