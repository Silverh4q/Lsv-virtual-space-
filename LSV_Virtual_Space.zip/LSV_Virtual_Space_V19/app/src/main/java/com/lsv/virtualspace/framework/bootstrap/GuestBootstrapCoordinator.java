package com.lsv.virtualspace.framework.bootstrap;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.framework.context.GuestContextSpec;
import com.lsv.virtualspace.framework.context.GuestContextSpecFactory;

/** Coordinates safe guest bootstrap preparation; execution remains behind a backend contract. */
public final class GuestBootstrapCoordinator {
    private final Context context;

    public GuestBootstrapCoordinator(Context context) {
        this.context = context.getApplicationContext();
    }

    public GuestBootstrapPlan prepare(VirtualApp app) {
        return GuestBootstrapPlanner.plan(app, context.getPackageManager());
    }

    public GuestContextSpec prepareContext(VirtualApp app) {
        return GuestContextSpecFactory.create(app);
    }
}
