package com.lsv.virtualspace.framework;

public final class GuestActivityContract {
    public static final String EXTRA_PACKAGE = "lsv.guest.package";
    public static final String EXTRA_COMPONENT = "lsv.guest.component";
    public static final String EXTRA_ACTION = "lsv.guest.action";
    public static final String EXTRA_GUEST_INTENT = "lsv.guest.intent";
    private GuestActivityContract() { }
}
