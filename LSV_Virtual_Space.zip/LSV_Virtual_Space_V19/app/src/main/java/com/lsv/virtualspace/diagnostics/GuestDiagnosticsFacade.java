package com.lsv.virtualspace.diagnostics;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.virtual.VirtualCore;

/** Public diagnostic entry point used by the host UI and launch engine. */
public final class GuestDiagnosticsFacade {
    private GuestDiagnosticsFacade() { }

    public static GuestDiagnosticController controller(Context context) {
        return GuestDiagnosticController.get(context);
    }

    public static void begin(Context context, VirtualApp app, String component) {
        GuestDiagnosticController.get(context).begin(app == null ? null : app.getPackageName(), component);
    }

    public static void stage(Context context, String stage, String detail) {
        GuestDiagnosticController.get(context).stage(stage, detail);
    }

    public static void fail(Context context, String kind, Throwable error) {
        GuestDiagnosticController.get(context).fail(kind, error);
    }

    public static String latest(Context context, String packageName) {
        return GuestDiagnosticController.get(context).getLastReport(packageName);
    }

    public static String preflight(Context context, VirtualApp app) {
        return GuestPreflight.run(context, app);
    }

    public static GuestDiagnosticsSelfTest.Result selfTest(Context context) {
        return GuestDiagnosticsSelfTest.run(context);
    }

    public static String active(Context context, String packageName) {
        return GuestDiagnosticController.get(context).getStore().readActive(packageName);
    }

    public static java.io.File reportFile(Context context, String packageName) {
        return new java.io.File(new java.io.File(GuestDiagnosticController.get(context).getStore().getRoot(),
            packageName == null ? "unknown" : packageName.replaceAll("[^A-Za-z0-9._-]", "_")), "latest.txt");
    }
}
