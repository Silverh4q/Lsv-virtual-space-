package com.lsv.virtualspace.framework.system.adapters;
import android.os.Bundle; import com.lsv.virtualspace.framework.system.*;
public final class GuestAccountAdapter implements GuestSystemServiceAdapter {
 public String getServiceName(){return GuestSystemServiceName.ACCOUNT;}
 public boolean canHandle(String op){return "add".equals(op)||"remove".equals(op)||"list".equals(op);}
 public Bundle handle(String pkg,GuestSystemServiceRequest r,GuestSystemServiceState s){Bundle o=new Bundle();String name=r.getArguments()==null?null:r.getArguments().getString("name");String k="account:"+(name==null?"default":name);if("add".equals(r.getOperation()))s.put(pkg,getServiceName(),k,"present");else if("remove".equals(r.getOperation()))s.remove(pkg,getServiceName(),k);o.putBoolean("accepted",true);o.putString("name",name);return o;}
}
