package com.lsv.virtualspace.profiles;
import android.content.Context; import com.lsv.virtualspace.graphics.*; import com.lsv.virtualspace.performance.*;
public final class GameProfileManager {
    private final Context context; private final GameCompatibilityCatalog catalog=new GameCompatibilityCatalog();
    public GameProfileManager(Context c){context=c.getApplicationContext();}
    public GameProfile create(String pkg){String n=catalog.getName(pkg); if(n==null)n="Generic Android Game"; return new GameProfile(pkg,n,new GraphicsCapabilityDetector().detect(context),new PerformanceProfileDetector().detect(context));}
    public boolean isKnownGame(String pkg){return catalog.isKnownGame(pkg);} public GameCompatibilityCatalog getCatalog(){return catalog;}
}
