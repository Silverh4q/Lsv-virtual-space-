package com.lsv.virtualspace.routing;

public final class GuestIntentRoute {
    private final String packageName;
    private final String componentName;
    private final String action;

    public GuestIntentRoute(String packageName, String componentName, String action) {
        this.packageName = packageName;
        this.componentName = componentName;
        this.action = action;
    }

    public String getPackageName() { return packageName; }
    public String getComponentName() { return componentName; }
    public String getAction() { return action; }
}
