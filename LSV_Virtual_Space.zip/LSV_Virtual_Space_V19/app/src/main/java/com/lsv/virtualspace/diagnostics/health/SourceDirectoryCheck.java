package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class SourceDirectoryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "SOURCE_DIRECTORY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && app.getApkPath() != null && new java.io.File(app.getApkPath()).canRead();
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
