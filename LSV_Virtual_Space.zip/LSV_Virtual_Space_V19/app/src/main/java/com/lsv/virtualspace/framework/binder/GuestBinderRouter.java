package com.lsv.virtualspace.framework.binder;

import android.content.pm.ActivityInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.content.Intent;
import java.util.List;
import com.lsv.virtualspace.framework.runtime.GuestActivityManagerRouter;

import com.lsv.virtualspace.framework.identity.GuestIdentity;
import com.lsv.virtualspace.framework.identity.GuestIdentityManager;
import com.lsv.virtualspace.framework.packages.GuestPackageRecord;
import com.lsv.virtualspace.framework.packages.GuestPackageRegistry;
import com.lsv.virtualspace.framework.permissions.GuestPermissionManager;
import com.lsv.virtualspace.framework.providers.GuestProviderManager;
import com.lsv.virtualspace.framework.services.GuestServiceManager;
import com.lsv.virtualspace.framework.system.GuestSystemServiceFacade;
import com.lsv.virtualspace.virtual.VirtualPackageManager;

/** Central host-side framework request dispatcher. */
public final class GuestBinderRouter {
    private final VirtualPackageManager packages;
    private final GuestServiceManager services;
    private final GuestProviderManager providers;
    private final GuestPackageRegistry packageRegistry;
    private final GuestPermissionManager permissions;
    private final GuestIdentityManager identities;
    private final GuestSystemServiceFacade systemServices;

    public GuestBinderRouter(VirtualPackageManager packages,
                             GuestServiceManager services,
                             GuestProviderManager providers) {
        this(packages, services, providers,
            new GuestPackageRegistry(packages, new GuestIdentityManager()),
            new GuestPermissionManager(packages), new GuestIdentityManager());
    }

    public GuestBinderRouter(VirtualPackageManager packages,
                             GuestServiceManager services,
                             GuestProviderManager providers,
                             GuestPackageRegistry packageRegistry,
                             GuestPermissionManager permissions,
                             GuestIdentityManager identities) {
        this.packages = packages;
        this.services = services;
        this.providers = providers;
        this.packageRegistry = packageRegistry;
        this.permissions = permissions;
        this.identities = identities;
        this.systemServices = null;
    }

    public GuestBinderRouter(VirtualPackageManager packages,
                             GuestServiceManager services,
                             GuestProviderManager providers,
                             GuestPackageRegistry packageRegistry,
                             GuestPermissionManager permissions,
                             GuestIdentityManager identities,
                             GuestSystemServiceFacade systemServices) {
        this.packages = packages;
        this.services = services;
        this.providers = providers;
        this.packageRegistry = packageRegistry;
        this.permissions = permissions;
        this.identities = identities;
        this.systemServices = systemServices;
    }

    public void startGuestService(String packageName, String component, Intent intent) {
        services.start(packageName, component, intent);
    }

    public GuestBinderReply bindGuestService(String packageName, String component) {
        return services.bind(packageName, component);
    }

    public void unbindGuestService(String packageName, String component) {
        services.unbind(packageName, component);
    }

    public void stopGuestService(String packageName, String component) {
        services.stop(packageName, component);
    }

    public GuestBinderReply dispatch(GuestBinderRequest request) {
        if (request == null || request.getPackageName() == null || request.getCode() == null)
            return GuestBinderReply.fail("Invalid framework request");
        GuestPackageRecord record = packageRegistry.ensure(request.getPackageName());
        if (record == null) return GuestBinderReply.fail("Guest package not registered");

        switch (request.getCode()) {
            case START_ACTIVITY:
                return resolveIntent(record, request);
            case START_SERVICE:
                return resolveServiceIntent(record, request);
            case STOP_SERVICE:
                services.stop(request.getPackageName(), request.getComponent());
                return GuestBinderReply.ok(new Bundle());
            case SEND_BROADCAST:
                return resolveReceivers(record, request);
            case BIND_SERVICE:
                return services.bind(request.getPackageName(), request.getComponent());
            case UNBIND_SERVICE:
                return services.unbind(request.getPackageName(), request.getComponent());
            case QUERY_PROVIDER:
            case CALL_PROVIDER:
            case RESOLVE_PROVIDER:
                return providers.route(request);
            case CHECK_PERMISSION:
                return checkPermission(request);
            case GET_PACKAGE_INFO:
                return packageInfo(record);
            case GET_VIRTUAL_IDENTITY:
                return identity(record.getIdentity());
            case SYSTEM_SERVICE_REQUEST:
                return systemService(request);
            case RESOLVE_ACTIVITY:
                return resolveActivity(record, request.getComponent());
            case RESOLVE_INTENT:
                return resolveIntent(record, request);
            case RESOLVE_SERVICE:
                return resolveService(record, request.getComponent());
            default:
                return GuestBinderReply.fail("Framework operation is not routed: " + request.getCode());
        }
    }

    private GuestBinderReply systemService(GuestBinderRequest request) {
        if (systemServices == null) return GuestBinderReply.fail("System-service facade unavailable");
        String service = request.getData().getString("service");
        String operation = request.getData().getString("operation");
        if (service == null || operation == null) return GuestBinderReply.fail("System-service request incomplete");
        Bundle out = systemServices.dispatch(request.getPackageName(), service, operation, request.getData());
        if (out == null) return GuestBinderReply.fail("System-service operation denied or unsupported: " + service + "/" + operation);
        com.lsv.virtualspace.framework.identity.GuestIdentity identity =
            systemServices.getIdentity(request.getPackageName());
        if (identity != null) {
            out.putString("packageName", identity.getPackageName());
            out.putInt("virtualUid", identity.getVirtualUid());
        }
        out.putString("service", service);
        out.putString("operation", operation);
        return GuestBinderReply.ok(out);
    }

    private GuestBinderReply checkPermission(GuestBinderRequest request) {
        String permission = request.getData().getString("permission");
        Bundle b = new Bundle();
        b.putInt("result", permissions.check(request.getPackageName(), permission));
        b.putBoolean("granted", permissions.isGranted(request.getPackageName(), permission));
        return GuestBinderReply.ok(b);
    }

    private GuestBinderReply packageInfo(GuestPackageRecord record) {
        Bundle b = new Bundle();
        b.putString("packageName", record.getPackageName());
        b.putString("sourceDir", record.getApplicationInfo().sourceDir);
        b.putInt("versionCode", record.getPackageInfo().versionCode);
        b.putString("versionName", record.getPackageInfo().versionName);
        b.putBoolean("enabled", record.getApplicationInfo().enabled);
        b.putString("label", guestLabel(record));
        b.putStringArray("requestedPermissions", record.getPackageInfo().requestedPermissions == null ? new String[0] : record.getPackageInfo().requestedPermissions);
        b.putInt("activityCount", record.getPackageInfo().activities == null ? 0 : record.getPackageInfo().activities.length);
        b.putInt("serviceCount", record.getPackageInfo().services == null ? 0 : record.getPackageInfo().services.length);
        b.putInt("providerCount", record.getPackageInfo().providers == null ? 0 : record.getPackageInfo().providers.length);
        b.putInt("receiverCount", record.getPackageInfo().receivers == null ? 0 : record.getPackageInfo().receivers.length);
        return GuestBinderReply.ok(b);
    }

    private String guestLabel(GuestPackageRecord record) {
        android.content.pm.ApplicationInfo ai = record.getApplicationInfo();
        if (ai == null) return record.getPackageName();
        if (ai.nonLocalizedLabel != null) return String.valueOf(ai.nonLocalizedLabel);
        return record.getPackageName();
    }

    private GuestBinderReply identity(GuestIdentity identity) {
        Bundle b = new Bundle();
        b.putInt("virtualUid", identity.getVirtualUid());
        b.putInt("userId", identity.getUserId());
        b.putString("packageName", identity.getPackageName());
        return GuestBinderReply.ok(b);
    }

    private GuestBinderReply resolveActivity(GuestPackageRecord record, String component) {
        if (record.getPackageInfo().activities == null) return GuestBinderReply.fail("No guest activities");
        for (ActivityInfo info : record.getPackageInfo().activities) {
            if (info != null && info.name != null && info.name.equals(component)) {
                Bundle b = new Bundle(); b.putString("className", info.name); return GuestBinderReply.ok(b);
            }
        }
        return GuestBinderReply.fail("Activity not found: " + component);
    }

    private GuestBinderReply resolveIntent(GuestPackageRecord record, GuestBinderRequest request) {
        Intent intent = (Intent) request.getData().getParcelable("intent");
        if (intent == null) return GuestBinderReply.fail("Intent payload missing");
        GuestActivityManagerRouter router = new GuestActivityManagerRouter(packages, packageRegistry);
        String component = router.resolveActivity(record.getPackageName(), intent);
        if (component == null) return GuestBinderReply.fail("No matching guest activity");
        Bundle b = new Bundle();
        b.putString("packageName", record.getPackageName());
        b.putString("className", component);
        b.putString("component", record.getPackageName() + "/" + component);
        return GuestBinderReply.ok(b);
    }

    private GuestBinderReply resolveServiceIntent(GuestPackageRecord record, GuestBinderRequest request) {
        Intent intent = (Intent) request.getData().getParcelable("intent");
        if (intent == null) return GuestBinderReply.fail("Intent payload missing");
        String component = packageRegistry.getIntentResolver().resolveService(
            record.getPackageName(), record.getPackageInfo(), intent);
        if (component == null) return GuestBinderReply.fail("No matching guest service");
        Bundle b = new Bundle();
        b.putString("packageName", record.getPackageName());
        b.putString("className", component);
        b.putString("component", record.getPackageName() + "/" + component);
        return GuestBinderReply.ok(b);
    }

    private GuestBinderReply resolveReceivers(GuestPackageRecord record, GuestBinderRequest request) {
        Intent intent = (Intent) request.getData().getParcelable("intent");
        if (intent == null) return GuestBinderReply.fail("Intent payload missing");
        List<String> receivers = packageRegistry.getIntentResolver().resolveReceivers(
            record.getPackageName(), record.getPackageInfo(), intent);
        Bundle b = new Bundle();
        b.putStringArrayList("components", new java.util.ArrayList<String>(receivers));
        b.putInt("count", receivers.size());
        return GuestBinderReply.ok(b);
    }

    private GuestBinderReply resolveService(GuestPackageRecord record, String component) {
        if (record.getPackageInfo().services == null) return GuestBinderReply.fail("No guest services");
        for (ServiceInfo info : record.getPackageInfo().services) {
            if (info != null && info.name != null && info.name.equals(component)) {
                Bundle b = new Bundle(); b.putString("className", info.name); return GuestBinderReply.ok(b);
            }
        }
        return GuestBinderReply.fail("Service not found: " + component);
    }
}
