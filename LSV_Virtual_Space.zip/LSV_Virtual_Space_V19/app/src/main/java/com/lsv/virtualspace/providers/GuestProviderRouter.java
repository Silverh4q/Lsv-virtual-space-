package com.lsv.virtualspace.providers;

import java.util.HashMap;
import java.util.Map;

/** Namespaced provider routing table for future Binder/provider virtualization. */
public final class GuestProviderRouter {
    private final Map<String, GuestProviderRoute> routes = new HashMap<String, GuestProviderRoute>();

    public synchronized void register(GuestProviderRoute route) {
        if (route != null && route.getAuthority() != null) routes.put(route.getAuthority(), route);
    }

    public synchronized GuestProviderRoute resolve(String authority) {
        return routes.get(authority);
    }

    public synchronized String virtualAuthority(String packageName, String authority) {
        String safePackage = packageName == null ? "unknown" : packageName.replace('.', '_');
        String safeAuthority = authority == null ? "provider" : authority.replace('.', '_');
        return "com.lsv.virtualspace.guest." + safePackage + "." + safeAuthority;
    }
}
