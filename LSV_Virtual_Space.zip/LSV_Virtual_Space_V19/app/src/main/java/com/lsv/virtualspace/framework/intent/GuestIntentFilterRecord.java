package com.lsv.virtualspace.framework.intent;

import android.content.IntentFilter;

/** Manifest-declared intent filter owned by one virtual guest component. */
public final class GuestIntentFilterRecord {
    private final String packageName;
    private final String componentName;
    private final String componentType;
    private final IntentFilter filter;
    private final boolean exported;

    public GuestIntentFilterRecord(String packageName, String componentName,
                                   String componentType, IntentFilter filter,
                                   boolean exported) {
        this.packageName = packageName;
        this.componentName = componentName;
        this.componentType = componentType;
        this.filter = filter;
        this.exported = exported;
    }

    public String getPackageName() { return packageName; }
    public String getComponentName() { return componentName; }
    public String getComponentType() { return componentType; }
    public IntentFilter getFilter() { return filter; }
    public boolean isExported() { return exported; }
}
