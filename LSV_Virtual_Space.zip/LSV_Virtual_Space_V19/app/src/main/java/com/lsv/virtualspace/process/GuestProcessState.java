package com.lsv.virtualspace.process;

public final class GuestProcessState {
    public static final int NEW=0, PREPARING=1, READY=2, RUNNING=3, STOPPING=4, STOPPED=5, FAILED=6;
    /** Compatibility aliases used by older LSV process lifecycle code. */
    public static final int CREATED=NEW;
    public static final int PREPARED=READY;
    private final String packageName;
    private int state;
    private String message;
    public GuestProcessState(String p){packageName=p;state=NEW;message="Created";}
    public String getPackageName(){return packageName;}
    public int getState(){return state;}
    public String getMessage(){return message;}
    public void set(int s,String m){state=s;message=m==null?"":m;}
    public static String nameOf(int value){
        switch(value){
            case NEW: return "NEW";
            case PREPARING: return "PREPARING";
            case READY: return "READY";
            case RUNNING: return "RUNNING";
            case STOPPING: return "STOPPING";
            case STOPPED: return "STOPPED";
            case FAILED: return "FAILED";
            default: return "UNKNOWN";
        }
    }
}
