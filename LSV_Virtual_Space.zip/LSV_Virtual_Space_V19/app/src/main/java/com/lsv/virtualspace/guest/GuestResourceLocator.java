package com.lsv.virtualspace.guest;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;

import java.lang.reflect.Method;

/** Creates an isolated Resources view of an imported APK without installing it. */
public final class GuestResourceLocator {
    private GuestResourceLocator() {}

    public static Resources open(Context host, String apkPath) throws Exception {
        AssetManager assets = AssetManager.class.newInstance();
        Method addAssetPath = AssetManager.class.getMethod("addAssetPath", String.class);
        Integer cookie = (Integer) addAssetPath.invoke(assets, apkPath);
        if (cookie == null || cookie.intValue() == 0) {
            throw new IllegalStateException("Unable to attach guest APK resources");
        }
        Resources hostRes = host.getResources();
        return new Resources(assets, hostRes.getDisplayMetrics(), hostRes.getConfiguration());
    }
}
