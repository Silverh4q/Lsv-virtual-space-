package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class DiagnosticStoreCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "DIAGNOSTIC_STORE"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && ensureDirectory(new java.io.File(context.getFilesDir(), "virtual/diagnostics"));
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }

    private static boolean ensureDirectory(java.io.File file) {
        if (file == null) return false;
        return file.isDirectory() || file.mkdirs();
    }
}
