package com.lsv.virtualspace.diagnostics;

/** One immutable runtime breadcrumb. */
public final class GuestDiagnosticEvent {
    public final long time;
    public final String stage;
    public final String detail;
    public final String thread;

    public GuestDiagnosticEvent(long time, String stage, String detail, String thread) {
        this.time = time;
        this.stage = stage;
        this.detail = detail;
        this.thread = thread;
    }
}
