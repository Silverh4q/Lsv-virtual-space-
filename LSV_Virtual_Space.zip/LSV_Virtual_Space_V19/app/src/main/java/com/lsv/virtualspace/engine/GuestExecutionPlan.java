package com.lsv.virtualspace.engine;
public final class GuestExecutionPlan {
    private final String packageName, activityName, apkPath, dataPath; private final boolean supported; private final String reason;
    public GuestExecutionPlan(String p,String a,String apk,String data,boolean s,String r){packageName=p;activityName=a;apkPath=apk;dataPath=data;supported=s;reason=r;}
    public String getPackageName(){return packageName;} public String getActivityName(){return activityName;} public String getApkPath(){return apkPath;} public String getDataPath(){return dataPath;} public boolean isSupported(){return supported;} public String getReason(){return reason;}
}
