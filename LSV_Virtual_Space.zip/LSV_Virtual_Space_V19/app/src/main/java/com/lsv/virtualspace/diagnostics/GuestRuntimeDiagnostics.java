package com.lsv.virtualspace.diagnostics;

import android.os.Build;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.virtual.VirtualPackageManager;

import java.util.Locale;

/** Reports compatibility facts needed before attempting guest execution. */
public class GuestRuntimeDiagnostics {
    private final VirtualPackageManager packages;

    public GuestRuntimeDiagnostics(VirtualPackageManager packages) {
        this.packages = packages;
    }

    public String inspect(VirtualApp app) {
        StringBuilder out = new StringBuilder();
        out.append("Package: ").append(app.getPackageName()).append("\n");
        out.append("Android API: ").append(Build.VERSION.SDK_INT).append("\n");
        out.append("Host ABIs: ");
        String[] abis = Build.SUPPORTED_ABIS;
        if (abis != null) {
            for (int i = 0; i < abis.length; i++) {
                if (i > 0) out.append(", ");
                out.append(abis[i]);
            }
        }
        out.append("\n");
        android.content.pm.ApplicationInfo info = packages.getApplicationInfo(app);
        if (info != null) {
            out.append("Native library dir: ")
                .append(info.nativeLibraryDir == null ? "none" : info.nativeLibraryDir)
                .append("\n");
            out.append("Target SDK: ").append(info.targetSdkVersion).append("\n");
        }
        out.append("Graphics: host EGL/OpenGL/Vulkan compatibility must be verified at runtime.\n");
        out.append("ABI result: metadata-only; native execution is not claimed.\n");
        return out.toString();
    }
}
