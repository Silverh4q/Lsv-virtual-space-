package com.lsv.virtualspace.runtime;

public final class GuestProcessLaunch {
    private final String packageName;
    private final String apkPath;
    private final boolean isolatedHostProcess;
    public GuestProcessLaunch(String packageName, String apkPath, boolean isolatedHostProcess) {
        this.packageName = packageName; this.apkPath = apkPath; this.isolatedHostProcess = isolatedHostProcess;
    }
    public String getPackageName() { return packageName; }
    public String getApkPath() { return apkPath; }
    public boolean isIsolatedHostProcess() { return isolatedHostProcess; }
}
