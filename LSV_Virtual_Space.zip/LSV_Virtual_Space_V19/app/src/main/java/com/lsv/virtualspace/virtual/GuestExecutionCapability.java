package com.lsv.virtualspace.virtual;

/** Explicit capability result for the guest backend. */
public class GuestExecutionCapability {
    private final boolean available;
    private final String reason;

    public GuestExecutionCapability(boolean available, String reason) {
        this.available = available;
        this.reason = reason;
    }

    public boolean isAvailable() { return available; }
    public boolean isSupported() { return available; }
    public String getReason() { return reason; }
}
