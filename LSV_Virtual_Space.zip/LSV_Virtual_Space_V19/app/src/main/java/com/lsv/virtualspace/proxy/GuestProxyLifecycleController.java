package com.lsv.virtualspace.proxy;

import android.app.Activity;
import android.content.Intent;
import android.view.Window;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.framework.GuestFrameworkHost;
import com.lsv.virtualspace.framework.GuestTaskManager;
import com.lsv.virtualspace.virtual.VirtualCore;

/**
 * Public-API proxy lifecycle controller.
 *
 * The declared GuestActivityProxy is the real Android Activity.  Guest
 * Activities are not reflectively attached to a fake Activity; Android owns
 * the real window/process lifecycle.  The controller keeps the virtual task
 * and framework routing state in sync with that host lifecycle.
 */
public final class GuestProxyLifecycleController {
    private final Activity host;
    private final GuestTaskManager tasks;
    private final GuestFrameworkHost framework;
    private VirtualApp app;
    private String component;
    private boolean active;

    public GuestProxyLifecycleController(Activity host) {
        this.host = host;
        VirtualCore core = VirtualCore.get();
        this.tasks = core.getGuestTaskManager();
        this.framework = core.getFrameworkHost();
    }

    public void onCreate(VirtualApp app, String component) {
        this.app = app;
        this.component = component;
        if (app != null) {
            tasks.open(app.getPackageName(), component);
            framework.onGuestHostCreated(app);
            active = true;
        }
    }

    /** Configures the real Android window used by the proxy Activity. */
    public void configureWindow() {
        Window window = host.getWindow();
        if (window == null) return;
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        window.getDecorView().setKeepScreenOn(false);
    }

    /**
     * The proxy is now only a virtual-engine endpoint. It never launches the
     * guest through Android's real PackageManager. The GuestInstrumentation
     * bridge substitutes the guest Activity while Android is constructing the
     * declared proxy Activity.
     */
    public boolean handOffToAndroid() {
        return false;
    }

    public boolean isActive() {
        return active;
    }

    public void onDestroy() {
        if (app != null) {
            framework.onGuestHostStopped(app);
            tasks.close(app.getPackageName());
        }
        active = false;
    }

    public VirtualApp getApp() { return app; }
    public String getComponent() { return component; }
}
