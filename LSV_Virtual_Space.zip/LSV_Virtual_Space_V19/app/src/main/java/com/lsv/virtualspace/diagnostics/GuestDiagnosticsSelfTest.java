package com.lsv.virtualspace.diagnostics;

import android.content.Context;

/** Non-invasive diagnostic self-test. It never launches or modifies a guest APK. */
public final class GuestDiagnosticsSelfTest {
    public static final class Result {
        public int passed;
        public int failed;
        public final StringBuilder text = new StringBuilder();
        public boolean isHealthy() { return failed == 0; }
    }

    private GuestDiagnosticsSelfTest() { }

    public static Result run(Context context) {
        Result r = new Result();
        check(r, "controller", context != null);
        if (context == null) return r;
        GuestDiagnosticController c = GuestDiagnosticController.get(context);
        check(r, "store", c.getStore() != null && c.getStore().getRoot().isDirectory());
        check(r, "api compatibility", GuestApiCompatibility.processName() != null);
        c.begin("__lsv_diagnostic_test__", "self-test");
        c.stage(GuestRuntimeStage.TEST_BEGIN, "diagnostic self-test");
        c.stage(GuestRuntimeStage.IDENTITY_READY, "identity checkpoint");
        c.heartbeat("self-test heartbeat");
        check(r, "active report", c.snapshot() != null);
        c.success("self-test complete");
        String report = c.getLastReport("__lsv_diagnostic_test__");
        check(r, "persisted report", report != null && report.indexOf("TEST_BEGIN") >= 0);
        c.getStore().saveCheckpoint(c.snapshot());
        check(r, "active checkpoint", c.getStore().readActive("__lsv_diagnostic_test__") != null);
        return r;
    }

    private static void check(Result r, String name, boolean ok) {
        if (ok) { r.passed++; r.text.append("PASS ").append(name).append('\n'); }
        else { r.failed++; r.text.append("FAIL ").append(name).append('\n'); }
    }
}
