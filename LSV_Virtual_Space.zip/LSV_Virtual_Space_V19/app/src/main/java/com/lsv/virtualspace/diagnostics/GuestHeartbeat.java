package com.lsv.virtualspace.diagnostics;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

/** Keeps a lightweight guest heartbeat so the host can distinguish a clean stop from a dead guest. */
public final class GuestHeartbeat {
    private final android.content.Context context;
    private final GuestDiagnosticController diagnostics;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running;
    private final Runnable beat = new Runnable() {
        @Override public void run() {
            if (!running) return;
            GuestProcessPresence.touch(context, diagnostics.getActivePackage());
            diagnostics.heartbeat("guest process alive");
            handler.postDelayed(this, 1000L);
        }
    };

    public GuestHeartbeat(Context context) {
        this.context = context.getApplicationContext();
        diagnostics = GuestDiagnosticController.get(context);
    }

    public void start() { if (running) return; running = true; handler.post(beat); }
    public void stop() { running = false; handler.removeCallbacks(beat); }
}
