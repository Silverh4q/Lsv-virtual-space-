package com.lsv.virtualspace.ipc;

import android.os.Bundle;
import android.os.Message;

/** Small, versioned IPC envelope used between the LSV host and guest-process boundary. */
public final class GuestIpcMessage {
    public static final int VERSION = 1;
    public static final int PREPARE = 1;
    public static final int START = 2;
    public static final int STOP = 3;
    public static final int PING = 4;
    public static final int RESULT = 100;

    public static final String KEY_VERSION = "lsv.ipc.version";
    public static final String KEY_PACKAGE = "lsv.ipc.package";
    public static final String KEY_COMPONENT = "lsv.ipc.component";
    public static final String KEY_STATUS = "lsv.ipc.status";
    public static final String KEY_DETAIL = "lsv.ipc.detail";

    private GuestIpcMessage() { }

    public static Message create(int what, String packageName, String component) {
        Message message = Message.obtain();
        message.what = what;
        Bundle data = new Bundle();
        data.putInt(KEY_VERSION, VERSION);
        data.putString(KEY_PACKAGE, packageName);
        data.putString(KEY_COMPONENT, component);
        message.setData(data);
        return message;
    }
}
