package com.lsv.virtualspace.ipc;

public interface GuestProcessBridge {
    boolean isAvailable();
    GuestLaunchResult prepare(GuestLaunchRequest request);
    GuestLaunchResult start(GuestLaunchRequest request);
    void stop(String packageName);
}
