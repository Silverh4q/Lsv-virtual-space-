package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ApkReadableCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "APK_READABLE"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && app.getApkPath() != null && new java.io.File(app.getApkPath()).length() > 0;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
