package com.lsv.virtualspace.components;

public final class GuestComponentRecord {
    public static final int ACTIVITY=1,SERVICE=2,RECEIVER=3,PROVIDER=4;
    private final int type; private final String packageName; private final String className; private final boolean exported;
    public GuestComponentRecord(int t,String p,String c,boolean e){type=t;packageName=p;className=c;exported=e;}
    public int getType(){return type;} public String getPackageName(){return packageName;} public String getClassName(){return className;} public boolean isExported(){return exported;}
}
