package com.lsv.virtualspace.process;

public final class GuestProcessCommand {
    public static final String ACTION_PREPARE = "com.lsv.virtualspace.PREPARE_GUEST";
    public static final String ACTION_STOP = "com.lsv.virtualspace.STOP_GUEST";
    public static final String EXTRA_PACKAGE = "guest_package";
    public static final String EXTRA_APK = "guest_apk";
    public static final String EXTRA_COMPONENT = "guest_component";
    private GuestProcessCommand() { }
}
