package com.lsv.virtualspace.proxy;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.lsv.virtualspace.virtual.VirtualCore;

/** Host endpoint that dispatches the request into the real guest Service class. */
public final class GuestServiceProxy extends Service {
    private static final String TAG = "LSV-GuestService";
    private String packageName;
    private String component;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        packageName = intent.getStringExtra("lsv.guest.package");
        component = intent.getStringExtra("lsv.guest.component");
        Intent guestIntent = intent.getParcelableExtra(com.lsv.virtualspace.framework.GuestActivityContract.EXTRA_GUEST_INTENT);
        try {
            VirtualCore.get().getFrameworkHost().startGuestService(packageName, component, guestIntent);
        } catch (Throwable error) {
            Log.e(TAG, "guest service route failed: " + packageName + "/" + component, error);
        }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) {
        if (intent != null) {
            packageName = intent.getStringExtra("lsv.guest.package");
            component = intent.getStringExtra("lsv.guest.component");
        }
        try {
            return VirtualCore.get().getFrameworkHost().bindGuestService(packageName, component);
        } catch (Throwable error) {
            Log.e(TAG, "guest service bind route failed", error);
            return null;
        }
    }

    @Override public boolean onUnbind(Intent intent) {
        try {
            VirtualCore.get().getFrameworkHost().unbindGuestService(packageName, component);
        } catch (Throwable ignored) { }
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        try { VirtualCore.get().getFrameworkHost().stopGuestService(packageName, component); }
        catch (Throwable ignored) { }
        super.onDestroy();
    }
}
