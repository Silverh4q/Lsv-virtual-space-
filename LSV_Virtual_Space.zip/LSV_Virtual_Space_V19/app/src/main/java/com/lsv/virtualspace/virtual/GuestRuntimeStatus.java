package com.lsv.virtualspace.virtual;

public final class GuestRuntimeStatus {
    public static final int READY = 1;
    public static final int BLOCKED = 2;
    public static final int FAILED = 3;

    private final int state;
    private final String message;

    public GuestRuntimeStatus(int state, String message) {
        this.state = state;
        this.message = message == null ? "" : message;
    }

    public int getState() { return state; }
    public String getMessage() { return message; }
}
