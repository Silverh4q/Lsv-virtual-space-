package com.lsv.virtualspace.framework.system;

import android.os.Bundle;

/** Service-specific guest operation adapter. */
public interface GuestSystemServiceAdapter {
    String getServiceName();
    boolean canHandle(String operation);
    Bundle handle(String packageName, GuestSystemServiceRequest request, GuestSystemServiceState state);
}
