package com.lsv.virtualspace.diagnostics;

import android.app.Application;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Process;

import java.lang.reflect.Method;

/** Small API compatibility boundary used to avoid compile-time references to optional APIs. */
public final class GuestApiCompatibility {
    private GuestApiCompatibility() { }

    public static String processName() {
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                Method m = Application.class.getMethod("getProcessName");
                Object value = m.invoke(null);
                if (value != null) return String.valueOf(value);
            } catch (Throwable ignored) { }
        }
        return "pid-" + Process.myPid();
    }

    public static long longVersionCode(PackageInfo info) {
        if (info == null) return 0L;
        try {
            Method m = PackageInfo.class.getMethod("getLongVersionCode");
            Object value = m.invoke(info);
            if (value instanceof Long) return ((Long) value).longValue();
            if (value instanceof Number) return ((Number) value).longValue();
        } catch (Throwable ignored) { }
        return info.versionCode;
    }
}
