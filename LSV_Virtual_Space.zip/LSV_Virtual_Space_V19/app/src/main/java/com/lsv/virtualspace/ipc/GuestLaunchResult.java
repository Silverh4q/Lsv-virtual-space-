package com.lsv.virtualspace.ipc;

public final class GuestLaunchResult {
    private final boolean accepted;
    private final String message;
    public GuestLaunchResult(boolean a,String m){accepted=a;message=m;}
    public boolean isAccepted(){return accepted;}
    public String getMessage(){return message;}
    public static GuestLaunchResult rejected(String m){return new GuestLaunchResult(false,m);}
}
