package com.lsv.virtualspace.apps;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class VirtualApp {
    private final String packageName;
    private final String label;
    private final String apkPath;
    private final String dataPath;

    public VirtualApp(String packageName, String label, String apkPath, String dataPath) {
        this.packageName = packageName;
        this.label = label;
        this.apkPath = apkPath;
        this.dataPath = dataPath;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getLabel() {
        return label;
    }

    public String getApkPath() {
        return apkPath;
    }

    public String getDataPath() {
        return dataPath;
    }

    /** Returns base.apk followed by any staged split APKs. */
    public List<String> getApkPaths() {
        List<String> paths = new ArrayList<String>();
        paths.add(apkPath);
        File base = new File(apkPath);
        File splitDir = new File(base.getParentFile(), base.getName() + ".splits");
        File[] splits = splitDir.listFiles();
        if (splits != null) {
            List<String> names = new ArrayList<String>();
            for (File file : splits) {
                if (file.isFile() && file.getName().endsWith(".apk")) {
                    names.add(file.getAbsolutePath());
                }
            }
            Collections.sort(names);
            paths.addAll(names);
        }
        return paths;
    }
}
