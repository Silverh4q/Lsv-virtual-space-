package com.lsv.virtualspace.proxy;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.lsv.virtualspace.guest.runtime.GuestComponentEnvironment;

/** Generic host endpoint that executes the guest BroadcastReceiver class. */
public final class GuestReceiverProxy extends BroadcastReceiver {
    public static final String ACTION_PREFIX = "com.lsv.virtualspace.GUEST_BROADCAST.";
    private static final String TAG = "LSV-GuestReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String pkg = intent.getStringExtra("lsv.guest.receiver.package");
        String component = intent.getStringExtra("lsv.guest.receiver.component");
        Intent guest = intent.getParcelableExtra("lsv.guest.receiver.intent");
        if (pkg == null) {
            Log.w(TAG, "guest receiver route missing package");
            return;
        }
        try {
            GuestComponentEnvironment env = GuestComponentEnvironment.open(context, pkg);
            if (component != null && component.length() > 0) {
                execute(env, component, guest);
                return;
            }
            android.content.pm.ActivityInfo[] receivers = env.getPackageInfo().receivers;
            if (receivers == null) return;
            for (android.content.pm.ActivityInfo info : receivers) {
                if (info != null && info.name != null && info.exported) {
                    execute(env, info.name, guest);
                }
            }
        } catch (Throwable error) {
            Log.e(TAG, "guest receiver failed: " + pkg + "/" + component, error);
        }
    }

    private void execute(GuestComponentEnvironment env, String component, Intent guest) throws Exception {
        Class<?> type = env.getClassLoader().loadClass(component);
        Object object = type.newInstance();
        if (!(object instanceof BroadcastReceiver)) {
            throw new IllegalStateException("Guest component is not a BroadcastReceiver: " + component);
        }
        ((BroadcastReceiver) object).onReceive(env.getContext(), guest == null ? new Intent() : new Intent(guest));
        Log.d(TAG, "guest receiver executed: " + env.getApp().getPackageName() + "/" + component);
    }
}
