package com.lsv.virtualspace.framework;

import android.content.Context;
import android.content.Intent;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.routing.GuestIntentRoute;
import com.lsv.virtualspace.routing.GuestIntentRouter;
import com.lsv.virtualspace.virtual.VirtualActivityManager;
import com.lsv.virtualspace.virtual.VirtualPackageManager;
import com.lsv.virtualspace.virtual.VirtualStorage;
import com.lsv.virtualspace.framework.binder.GuestBinderRequest;
import com.lsv.virtualspace.framework.binder.GuestBinderReply;
import com.lsv.virtualspace.framework.binder.GuestBinderRouter;
import com.lsv.virtualspace.framework.services.GuestServiceManager;
import com.lsv.virtualspace.framework.providers.GuestProviderManager;
import com.lsv.virtualspace.framework.packages.GuestPackageSessionManager;
import com.lsv.virtualspace.framework.packages.GuestPackageRegistry;
import com.lsv.virtualspace.framework.packages.GuestPackageManagerFacade;
import com.lsv.virtualspace.framework.identity.GuestIdentityManager;
import com.lsv.virtualspace.framework.permissions.GuestPermissionManager;
import com.lsv.virtualspace.framework.lifecycle.GuestLifecycleBridge;
import com.lsv.virtualspace.framework.bootstrap.GuestRuntimePreparation;
import com.lsv.virtualspace.framework.bootstrap.GuestRuntimePreparer;
import com.lsv.virtualspace.framework.runtime.GuestActivityManager;
import com.lsv.virtualspace.framework.system.GuestSystemServiceFacade;
import com.lsv.virtualspace.framework.resources.GuestResourceSessionManager;

/** Host-side framework boundary for virtual component routing and lifecycle. */
public final class GuestFrameworkHost {
    private final Context context;
    private final GuestIntentRouter router;
    private final VirtualPackageManager packageManager;
    private final VirtualStorage storage;
    private final GuestBinderRouter binderRouter;
    private final GuestLifecycleBridge lifecycle;
    private final GuestRuntimePreparer runtimePreparer;
    private final GuestPackageManagerFacade guestPackageManager;
    private final GuestActivityManager activityManager;
    private final GuestSystemServiceFacade systemServices;

    public GuestFrameworkHost(Context context,
                              VirtualActivityManager activities,
                              VirtualPackageManager packageManager,
                              VirtualStorage storage) {
        this.context = context.getApplicationContext();
        this.router = new GuestIntentRouter(activities);
        this.packageManager = packageManager;
        this.storage = storage;
        GuestIdentityManager identities = new GuestIdentityManager();
        GuestPackageRegistry packageRegistry = new GuestPackageRegistry(packageManager, identities);
        GuestResourceSessionManager resourceSessions = new GuestResourceSessionManager(this.context);
        GuestServiceManager services = new GuestServiceManager(this.context);
        GuestProviderManager providers = new GuestProviderManager(packageRegistry, this.context);
        GuestPermissionManager permissions = new GuestPermissionManager(packageManager);
        this.systemServices = new GuestSystemServiceFacade(this.context, identities, permissions);
        this.guestPackageManager = new GuestPackageManagerFacade(packageRegistry, resourceSessions);
        this.activityManager = new GuestActivityManager(this.context, packageManager, packageRegistry);
        this.systemServices.attachPackageManager(this.guestPackageManager);
        this.systemServices.attachActivityManager(this.activityManager);
        this.activityManager.attachSystemServices(this.systemServices);
        this.binderRouter = new GuestBinderRouter(packageManager, services, providers, packageRegistry, permissions, identities, systemServices);
        this.lifecycle = new GuestLifecycleBridge(new GuestPackageSessionManager());
        this.runtimePreparer = new GuestRuntimePreparer(this.context);
    }

    public GuestPackageManagerFacade getGuestPackageManager() { return guestPackageManager; }

    public GuestActivityManager getActivityManager() { return activityManager; }

    public GuestSystemServiceFacade getSystemServices() { return systemServices; }

    public GuestRuntimePreparation prepareGuestRuntime(VirtualApp app) {
        return runtimePreparer.prepare(app);
    }

    public Intent createProxyIntent(VirtualApp app, Intent guestIntent) {
        GuestIntentRoute route = router.route(app.getPackageName(), guestIntent);
        if (route == null) {
            return null;
        }
        Intent proxy = new Intent(context, com.lsv.virtualspace.proxy.GuestActivityProxy.class);
        proxy.putExtra(GuestActivityContract.EXTRA_PACKAGE, route.getPackageName());
        proxy.putExtra(GuestActivityContract.EXTRA_COMPONENT, route.getComponentName());
        proxy.putExtra(GuestActivityContract.EXTRA_ACTION, route.getAction());
        proxy.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return proxy;
    }

    public boolean isGuestRegistered(VirtualApp app) {
        return app != null && packageManager.getPackageInfo(app) != null;
    }

    public GuestBinderReply dispatchBinder(GuestBinderRequest request) {
        return binderRouter.dispatch(request);
    }

    public void startGuestService(String packageName, String component, Intent intent) {
        binderRouter.startGuestService(packageName, component, intent);
    }

    public android.os.IBinder bindGuestService(String packageName, String component) {
        GuestBinderReply reply = binderRouter.bindGuestService(packageName, component);
        return reply.isSuccess() ? reply.getData().getBinder("binder") : null;
    }

    public void unbindGuestService(String packageName, String component) {
        binderRouter.unbindGuestService(packageName, component);
    }

    public void stopGuestService(String packageName, String component) {
        binderRouter.stopGuestService(packageName, component);
    }

    public void onGuestHostCreated(VirtualApp app) {
        if (app != null) lifecycle.onCreate(app.getPackageName());
    }

    public void onGuestHostStopped(VirtualApp app) {
        if (app != null) lifecycle.onStop(app.getPackageName());
    }

    public boolean isGuestLifecycleActive(VirtualApp app) {
        return app != null && lifecycle.isActive(app.getPackageName());
    }

    public String getGuestDataPath(VirtualApp app) {
        return app == null ? null : app.getDataPath();
    }
}
