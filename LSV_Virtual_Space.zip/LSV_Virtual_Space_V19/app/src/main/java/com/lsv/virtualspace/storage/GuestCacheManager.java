package com.lsv.virtualspace.storage;
import java.io.*;
public final class GuestCacheManager { public long size(File f){if(f==null||!f.exists())return 0; if(f.isFile())return f.length(); long n=0; File[] a=f.listFiles(); if(a!=null)for(File x:a)n+=size(x); return n;} public void clear(File f){if(f==null||!f.exists())return; File[] a=f.listFiles(); if(a!=null)for(File x:a){if(x.isDirectory())clear(x); if(!x.delete()){} }} }
