package com.lsv.virtualspace.google;

/**
 * Placeholder boundary for Google Play services / Play Store integration.
 *
 * Google components require a compatible Android runtime and cannot be made
 * functional by merely copying their APKs into private app storage.
 */
public final class GoogleServicesManager {
    private GoogleServicesManager() {
    }

    public static boolean isConfigured() {
        return false;
    }
}
