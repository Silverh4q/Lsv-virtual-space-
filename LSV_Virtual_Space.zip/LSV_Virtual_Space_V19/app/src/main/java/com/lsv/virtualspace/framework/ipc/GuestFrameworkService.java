package com.lsv.virtualspace.framework.ipc;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

import com.lsv.virtualspace.framework.GuestFrameworkHost;
import com.lsv.virtualspace.framework.binder.GuestBinderCode;
import com.lsv.virtualspace.framework.binder.GuestBinderReply;
import com.lsv.virtualspace.framework.binder.GuestBinderRequest;
import com.lsv.virtualspace.virtual.VirtualCore;

/** Real Binder boundary between guest processes and the LSV host framework. */
public final class GuestFrameworkService extends Service {
    public static final String ACTION = "com.lsv.virtualspace.action.GUEST_FRAMEWORK";
    private final IBinder binder = new FrameworkBinder();

    @Override public IBinder onBind(Intent intent) { return binder; }

    private final class FrameworkBinder extends Binder {
        private static final int TRANSACTION_DISPATCH = 1;

        @Override protected boolean onTransact(int code, Parcel data, Parcel reply, int flags)
                throws RemoteException {
            if (code != TRANSACTION_DISPATCH) return super.onTransact(code, data, reply, flags);
            String packageName = data.readString();
            String op = data.readString();
            String component = data.readString();
            Bundle input = data.readBundle(getClass().getClassLoader());
            GuestBinderCode binderCode;
            try { binderCode = GuestBinderCode.valueOf(op); }
            catch (Throwable error) {
                writeReply(reply, GuestBinderReply.fail("Unknown framework operation: " + op));
                return true;
            }
            GuestFrameworkHost host = VirtualCore.get().getFrameworkHost();
            GuestBinderReply result = host.dispatchBinder(
                new GuestBinderRequest(packageName, binderCode, component, input));
            writeReply(reply, result);
            return true;
        }

        private void writeReply(Parcel reply, GuestBinderReply result) {
            reply.writeInt(result.isSuccess() ? 1 : 0);
            reply.writeString(result.getMessage());
            reply.writeBundle(result.getData());
        }
    }

    public static final int TRANSACTION_DISPATCH = 1;
}
