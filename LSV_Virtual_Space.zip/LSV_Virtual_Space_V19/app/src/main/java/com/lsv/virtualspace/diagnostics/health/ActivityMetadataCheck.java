package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ActivityMetadataCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "ACTIVITY_METADATA"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && context != null && context.getPackageManager().getPackageArchiveInfo(app.getApkPath(), android.content.pm.PackageManager.GET_ACTIVITIES) != null;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
