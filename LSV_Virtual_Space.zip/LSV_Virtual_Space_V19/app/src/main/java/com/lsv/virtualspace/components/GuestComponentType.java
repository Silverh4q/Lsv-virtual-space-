package com.lsv.virtualspace.components;
public enum GuestComponentType { ACTIVITY, SERVICE, RECEIVER, PROVIDER }
