package com.lsv.virtualspace.components;

import java.util.ArrayList; import java.util.List;

public final class GuestComponentTable {
    private final List<GuestComponentRecord> records=new ArrayList<GuestComponentRecord>();
    public void add(GuestComponentRecord r){if(r!=null)records.add(r);}
    public List<GuestComponentRecord> getAll(){return new ArrayList<GuestComponentRecord>(records);}
    public int size(){return records.size();}
}
