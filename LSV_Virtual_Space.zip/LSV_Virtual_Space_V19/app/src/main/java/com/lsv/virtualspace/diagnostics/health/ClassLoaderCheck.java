package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ClassLoaderCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "CLASSLOADER"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && context.getClassLoader() != null;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
