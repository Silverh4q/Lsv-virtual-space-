package com.lsv.virtualspace.performance;
public final class GuestPerformanceProfile {
    private final int targetFps; private final boolean backgroundPause; private final int memoryClassMb;
    public GuestPerformanceProfile(int fps,boolean pause,int mem){targetFps=fps;backgroundPause=pause;memoryClassMb=mem;}
    public int getTargetFps(){return targetFps;} public boolean isBackgroundPauseEnabled(){return backgroundPause;} public int getMemoryClassMb(){return memoryClassMb;}
}
