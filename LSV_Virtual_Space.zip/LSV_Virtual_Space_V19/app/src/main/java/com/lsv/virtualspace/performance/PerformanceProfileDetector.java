package com.lsv.virtualspace.performance;
import android.app.ActivityManager; import android.content.Context;
public final class PerformanceProfileDetector {
    public GuestPerformanceProfile detect(Context c){ActivityManager a=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE); int m=a==null?128:a.getMemoryClass(); int fps=m>=256?60:30; return new GuestPerformanceProfile(fps,true,m);}
}
