package com.lsv.virtualspace.framework.bootstrap;

/** Immutable description of a guest bootstrap; planning only, no guest code is executed. */
public final class GuestBootstrapPlan {
    private final String packageName;
    private final String apkPath;
    private final String dataPath;
    private final String applicationClass;
    private final int targetSdk;
    private final boolean applicationDefault;

    public GuestBootstrapPlan(String packageName, String apkPath, String dataPath,
                              String applicationClass, int targetSdk,
                              boolean applicationDefault) {
        this.packageName = packageName;
        this.apkPath = apkPath;
        this.dataPath = dataPath;
        this.applicationClass = applicationClass;
        this.targetSdk = targetSdk;
        this.applicationDefault = applicationDefault;
    }

    public String getPackageName() { return packageName; }
    public String getApkPath() { return apkPath; }
    public String getDataPath() { return dataPath; }
    public String getApplicationClass() { return applicationClass; }
    public int getTargetSdk() { return targetSdk; }
    public boolean usesDefaultApplication() { return applicationDefault; }
}
