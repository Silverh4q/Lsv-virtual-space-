package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class CodeCacheCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "CODE_CACHE"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && ensureDirectory(context.getCodeCacheDir());
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }

    private static boolean ensureDirectory(java.io.File file) {
        if (file == null) return false;
        return file.isDirectory() || file.mkdirs();
    }
}
