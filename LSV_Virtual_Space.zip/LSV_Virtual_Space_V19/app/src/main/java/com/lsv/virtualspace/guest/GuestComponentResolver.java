package com.lsv.virtualspace.guest;

import android.content.pm.ActivityInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.virtual.VirtualPackageManager;

import java.util.ArrayList;
import java.util.List;

/** Resolves guest components from APK metadata without installing them. */
public class GuestComponentResolver {
    private final VirtualPackageManager packages;

    public GuestComponentResolver(VirtualPackageManager packages) {
        this.packages = packages;
    }

    public List<ActivityInfo> activities(VirtualApp app) {
        List<ActivityInfo> result = new ArrayList<ActivityInfo>();
        android.content.pm.PackageInfo info = packages.getPackageInfo(app);
        if (info != null && info.activities != null) {
            for (ActivityInfo item : info.activities) {
                result.add(item);
            }
        }
        return result;
    }

    public List<ServiceInfo> services(VirtualApp app) {
        List<ServiceInfo> result = new ArrayList<ServiceInfo>();
        android.content.pm.PackageInfo info = packages.getPackageInfo(app);
        if (info != null && info.services != null) {
            for (ServiceInfo item : info.services) {
                result.add(item);
            }
        }
        return result;
    }

    public List<ProviderInfo> providers(VirtualApp app) {
        List<ProviderInfo> result = new ArrayList<ProviderInfo>();
        android.content.pm.PackageInfo info = packages.getPackageInfo(app);
        if (info != null && info.providers != null) {
            for (ProviderInfo item : info.providers) {
                result.add(item);
            }
        }
        return result;
    }
}
