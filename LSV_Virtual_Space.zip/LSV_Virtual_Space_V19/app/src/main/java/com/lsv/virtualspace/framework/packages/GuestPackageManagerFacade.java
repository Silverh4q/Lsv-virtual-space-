package com.lsv.virtualspace.framework.packages;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.res.Resources;

import com.lsv.virtualspace.framework.resources.GuestResourceSession;
import com.lsv.virtualspace.framework.resources.GuestResourceSessionManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Guest PackageManager implementation. All package/component queries are
 * resolved against LSV's virtual package database, never host installed apps.
 */
public final class GuestPackageManagerFacade {
    private final GuestPackageRegistry registry;
    private final GuestResourceSessionManager resources;

    public GuestPackageManagerFacade(GuestPackageRegistry registry) {
        this(registry, null);
    }

    public GuestPackageManagerFacade(GuestPackageRegistry registry, GuestResourceSessionManager resources) {
        this.registry = registry;
        this.resources = resources;
    }

    public PackageInfo getPackageInfo(String packageName, int flags) {
        return getPackageInfo(packageName);
    }

    public ApplicationInfo getApplicationInfo(String packageName, int flags) {
        return getApplicationInfo(packageName);
    }

    public PackageInfo getPackageInfo(String packageName) {
        GuestPackageRecord r = registry.ensure(packageName);
        return r == null ? null : r.getPackageInfo();
    }

    public ApplicationInfo getApplicationInfo(String packageName) {
        GuestPackageRecord r = registry.ensure(packageName);
        return r == null ? null : r.getApplicationInfo();
    }

    public ActivityInfo getActivityInfo(String packageName, String className) {
        return resolveActivity(packageName, className);
    }

    public ServiceInfo getServiceInfo(String packageName, String className) {
        return resolveService(packageName, className);
    }

    public ProviderInfo getProviderInfo(String packageName, String authority) {
        return resolveProvider(packageName, authority);
    }

    public ActivityInfo resolveActivity(String packageName, String className) {
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null || r.getPackageInfo().activities == null) return null;
        for (ActivityInfo i : r.getPackageInfo().activities) {
            if (i != null && className != null && className.equals(i.name) && isEnabled(packageName, i.name)) return i;
        }
        return null;
    }

    public ServiceInfo resolveService(String packageName, String className) {
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null || r.getPackageInfo().services == null) return null;
        for (ServiceInfo i : r.getPackageInfo().services) {
            if (i != null && className != null && className.equals(i.name) && isEnabled(packageName, i.name)) return i;
        }
        return null;
    }

    public ProviderInfo resolveProvider(String packageName, String authority) {
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null || r.getPackageInfo().providers == null) return null;
        for (ProviderInfo i : r.getPackageInfo().providers) {
            if (i == null || i.authority == null || !isEnabled(packageName, i.name)) continue;
            String[] a = i.authority.split(";");
            for (String v : a) if (authority != null && authority.equals(v)) return i;
        }
        return null;
    }

    public ActivityInfo[] activities(String packageName) {
        GuestPackageRecord r = registry.ensure(packageName);
        return r == null ? null : enabledActivities(packageName, r.getPackageInfo().activities);
    }

    public ServiceInfo[] services(String packageName) {
        GuestPackageRecord r = registry.ensure(packageName);
        return r == null ? null : enabledServices(packageName, r.getPackageInfo().services);
    }

    public ActivityInfo[] receivers(String packageName) {
        GuestPackageRecord r = registry.ensure(packageName);
        return r == null ? null : enabledActivities(packageName, r.getPackageInfo().receivers);
    }

    public ProviderInfo[] providers(String packageName) {
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null || r.getPackageInfo().providers == null) return null;
        ArrayList<ProviderInfo> out = new ArrayList<ProviderInfo>();
        for (ProviderInfo p : r.getPackageInfo().providers) if (p != null && isEnabled(packageName, p.name)) out.add(p);
        return out.toArray(new ProviderInfo[out.size()]);
    }

    public List<PackageInfo> getInstalledPackages() {
        List<PackageInfo> out = new ArrayList<PackageInfo>();
        for (GuestPackageRecord r : registry.snapshot()) out.add(r.getPackageInfo());
        return out;
    }

    public List<ApplicationInfo> getInstalledApplications() {
        List<ApplicationInfo> out = new ArrayList<ApplicationInfo>();
        for (GuestPackageRecord r : registry.snapshot()) out.add(r.getApplicationInfo());
        return out;
    }

    public List<ResolveInfo> queryIntentActivities(String packageName, Intent intent) {
        List<ResolveInfo> out = new ArrayList<ResolveInfo>();
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null || intent == null) return out;
        String c = registry.getIntentResolver().resolveActivity(packageName, r.getPackageInfo(), intent);
        if (c != null) { ActivityInfo a = resolveActivity(packageName, c); if (a != null) { ResolveInfo ri = new ResolveInfo(); ri.activityInfo = a; out.add(ri); } }
        return out;
    }

    public List<ResolveInfo> queryIntentServices(String packageName, Intent intent) {
        List<ResolveInfo> out = new ArrayList<ResolveInfo>();
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null || intent == null) return out;
        String c = registry.getIntentResolver().resolveService(packageName, r.getPackageInfo(), intent);
        if (c != null) { ServiceInfo s = resolveService(packageName, c); if (s != null) { ResolveInfo ri = new ResolveInfo(); ri.serviceInfo = s; out.add(ri); } }
        return out;
    }

    public List<ResolveInfo> queryIntentReceivers(String packageName, Intent intent) {
        List<ResolveInfo> out = new ArrayList<ResolveInfo>();
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null || intent == null) return out;
        for (String c : registry.getIntentResolver().resolveReceivers(packageName, r.getPackageInfo(), intent)) {
            ActivityInfo a = findReceiver(r.getPackageInfo(), c);
            if (a != null && isEnabled(packageName, a.name)) { ResolveInfo ri = new ResolveInfo(); ri.activityInfo = a; out.add(ri); }
        }
        return out;
    }

    public boolean hasPackage(String packageName) { return registry.ensure(packageName) != null; }

    public boolean hasPermission(String packageName, String permission) {
        PackageInfo p = getPackageInfo(packageName);
        if (p == null || p.requestedPermissions == null) return false;
        for (String x : p.requestedPermissions) if (permission != null && permission.equals(x)) return true;
        return false;
    }

    public String[] requestedPermissions(String packageName) {
        PackageInfo p = getPackageInfo(packageName);
        return p == null || p.requestedPermissions == null ? new String[0] : p.requestedPermissions.clone();
    }

    public boolean isPackageEnabled(String packageName) {
        ApplicationInfo a = getApplicationInfo(packageName);
        return a != null && a.enabled;
    }

    public boolean isComponentEnabled(String packageName, String className) {
        return isEnabled(packageName, className);
    }

    public void setComponentEnabled(String packageName, String className, boolean enabled) {
        registry.setComponentEnabled(packageName, className, enabled);
    }

    public String getApplicationLabel(String packageName) {
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null) return null;
        ApplicationInfo a = r.getApplicationInfo();
        if (a == null) return packageName;
        if (a.labelRes != 0 && resources != null) {
            try {
                GuestResourceSession s = resources.open(packageName, r.getApkPath());
                return s.getResources().getString(a.labelRes);
            } catch (Throwable ignored) { }
        }
        return a.nonLocalizedLabel == null ? packageName : String.valueOf(a.nonLocalizedLabel);
    }

    public Resources getResources(String packageName) {
        GuestPackageRecord r = registry.ensure(packageName);
        if (r == null || resources == null) return null;
        try { return resources.open(packageName, r.getApkPath()).getResources(); }
        catch (Throwable ignored) { return null; }
    }

    public String getSourceDir(String packageName) {
        ApplicationInfo a = getApplicationInfo(packageName);
        return a == null ? null : a.sourceDir;
    }

    public String getVersionName(String packageName) { PackageInfo p = getPackageInfo(packageName); return p == null ? null : p.versionName; }
    public long getVersionCode(String packageName) {
        PackageInfo p = getPackageInfo(packageName); if (p == null) return -1L;
        return com.lsv.virtualspace.diagnostics.GuestApiCompatibility.longVersionCode(p);
    }

    public String[] getSignatureDigests(String packageName) {
        PackageInfo p = getPackageInfo(packageName);
        if (p == null) return new String[0];
        android.content.pm.Signature[] signatures = p.signatures;
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            try {
                java.lang.reflect.Field field = PackageInfo.class.getField("signingInfo");
                Object signing = field.get(p);
                if (signing != null) {
                    java.lang.reflect.Method multiple = signing.getClass().getMethod("hasMultipleSigners");
                    java.lang.reflect.Method current = signing.getClass().getMethod(
                        ((Boolean) multiple.invoke(signing)).booleanValue() ? "getApkContentsSigners" : "getSigningCertificateHistory");
                    Object value = current.invoke(signing);
                    if (value instanceof android.content.pm.Signature[]) {
                        signatures = (android.content.pm.Signature[]) value;
                    }
                }
            } catch (Throwable ignored) { }
        }
        if (signatures == null) return new String[0];
        java.util.ArrayList<String> out = new java.util.ArrayList<String>();
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            for (android.content.pm.Signature s : signatures) out.add(toHex(md.digest(s.toByteArray())));
        } catch (Throwable ignored) { }
        return out.toArray(new String[out.size()]);
    }

    public ComponentName component(String packageName, String className) { return className == null ? null : new ComponentName(packageName, className); }

    private boolean isEnabled(String pkg, String component) {
        return registry.isComponentEnabled(pkg, component);
    }
    private ActivityInfo findReceiver(PackageInfo p, String c) {
        if (p.receivers == null) return null;
        for (ActivityInfo a : p.receivers) if (a != null && c.equals(a.name)) return a;
        return null;
    }
    private ActivityInfo[] enabledActivities(String pkg, ActivityInfo[] in) {
        if (in == null) return null; ArrayList<ActivityInfo> out = new ArrayList<ActivityInfo>();
        for (ActivityInfo a : in) if (a != null && isEnabled(pkg, a.name)) out.add(a);
        return out.toArray(new ActivityInfo[out.size()]);
    }
    private ServiceInfo[] enabledServices(String pkg, ServiceInfo[] in) {
        if (in == null) return null; ArrayList<ServiceInfo> out = new ArrayList<ServiceInfo>();
        for (ServiceInfo a : in) if (a != null && isEnabled(pkg, a.name)) out.add(a);
        return out.toArray(new ServiceInfo[out.size()]);
    }
    private static String toHex(byte[] b) { StringBuilder s=new StringBuilder(); for(byte v:b)s.append(String.format("%02x", v & 255)); return s.toString(); }
}
