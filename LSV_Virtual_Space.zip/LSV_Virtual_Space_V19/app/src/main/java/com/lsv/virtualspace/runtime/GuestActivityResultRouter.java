package com.lsv.virtualspace.runtime;

import android.content.Intent;

import java.util.HashMap;
import java.util.Map;

/** Routes activity results by virtual guest package without exposing host request-code collisions. */
public final class GuestActivityResultRouter {
    private final Map<Integer, String> requests = new HashMap<Integer, String>();

    public synchronized void register(int requestCode, String packageName) {
        if (packageName != null) requests.put(requestCode, packageName);
    }

    public synchronized String consumePackage(int requestCode) {
        return requests.remove(requestCode);
    }

    public synchronized Intent sanitizeResult(Intent result) {
        if (result == null) return null;
        Intent copy = new Intent(result);
        copy.setComponent(null);
        return copy;
    }

    public synchronized void clear() { requests.clear(); }
}
