package com.lsv.virtualspace.framework.packages;

/** Guest-owned enabled/disabled state for a manifest component. */
public final class GuestComponentState {
    private final String packageName;
    private final String componentName;
    private final String type;
    private boolean enabled;

    public GuestComponentState(String packageName, String componentName, String type, boolean enabled) {
        this.packageName = packageName;
        this.componentName = componentName;
        this.type = type;
        this.enabled = enabled;
    }
    public String getPackageName() { return packageName; }
    public String getComponentName() { return componentName; }
    public String getType() { return type; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}
