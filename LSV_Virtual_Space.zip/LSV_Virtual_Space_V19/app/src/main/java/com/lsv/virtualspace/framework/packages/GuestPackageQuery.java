package com.lsv.virtualspace.framework.packages;

import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import java.util.List;

/** Snapshot returned by guest package queries. */
public final class GuestPackageQuery {
    private final String packageName;
    private final PackageInfo packageInfo;
    private final List<ResolveInfo> matches;
    public GuestPackageQuery(String packageName, PackageInfo packageInfo, List<ResolveInfo> matches) {
        this.packageName = packageName; this.packageInfo = packageInfo; this.matches = matches;
    }
    public String getPackageName() { return packageName; }
    public PackageInfo getPackageInfo() { return packageInfo; }
    public List<ResolveInfo> getMatches() { return matches; }
}
