package com.lsv.virtualspace;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.ImageView;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.graphics.drawable.Drawable;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.lsv.virtualspace.apps.InstalledAppInfo;
import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.apps.VirtualAppRepository;
import com.lsv.virtualspace.storage.StorageExportManager;
import com.lsv.virtualspace.storage.StoragePermissionManager;
import com.lsv.virtualspace.virtual.VirtualCore;
import com.lsv.virtualspace.overlay.OverlayPermissionHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_APK = 4101;
    private static final int EXPORT_APK = 4102;

    private VirtualApp exportTarget;
    private Dialog pickerLoading;
    private LinearLayout listContainer;
    private TextView countText;
    private VirtualAppRepository repository;
    private int primary;
    private int background;
    private int surface;
    private int text;
    private int secondary;
    private com.lsv.virtualspace.diagnostics.GuestProcessWatchdog guestWatchdog;
    private String activeGuestPackage;

    @Override
    protected void onCreate(Bundle state) {
        try {
            ThemeManager.apply(this);
            super.onCreate(state);
            updateThemeColors();
            if (!ensureLsvFrameworkReady()) {
                showFrameworkStartupFailure();
                return;
            }
            repository = VirtualCore.get().getAppRepository();
            buildUi();
            try { StoragePermissionManager.requestLegacyReadPermission(this); } catch (Throwable ignored) { }
            refreshList();
            guestWatchdog = new com.lsv.virtualspace.diagnostics.GuestProcessWatchdog(this);
        } catch (Throwable error) {
            try {
                com.lsv.virtualspace.diagnostics.HostStartupDiagnostics.record(this, error);
            } catch (Throwable ignored) { }
            try {
                showFrameworkStartupFailure();
            } catch (Throwable ignored) {
                finish();
            }
        }
    }

    private boolean ensureLsvFrameworkReady() {
        try {
            if (VirtualCore.get().isInitialized()) return true;
            boolean initialized = VirtualCore.get().tryInitialize(getApplicationContext());
            if (!initialized) {
                String message = VirtualCore.get().getInitializationError();
                com.lsv.virtualspace.diagnostics.HostStartupDiagnostics.record(
                    this, new IllegalStateException(message == null ? "VirtualCore initialization failed" : message));
                return false;
            }
            return VirtualCore.get().isInitialized();
        } catch (Throwable error) {
            com.lsv.virtualspace.diagnostics.HostStartupDiagnostics.record(this, error);
            return false;
        }
    }

    private void showFrameworkStartupFailure() {
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(background);

        TextView title = label("LSV framework could not start", 20, text);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));

        String report = com.lsv.virtualspace.diagnostics.HostStartupDiagnostics.latest(this);
        if (report == null || report.length() == 0) report = "No startup report was available.";
        TextView details = label(report, 12, secondary);
        details.setGravity(Gravity.CENTER);
        details.setTextIsSelectable(true);
        root.addView(details, new LinearLayout.LayoutParams(-1, dp(220)));

        Button retry = smallButton("Retry");
        retry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                recreate();
            }
        });
        root.addView(retry, new LinearLayout.LayoutParams(-1, dp(50)));
        setContentView(root);
    }

    private void updateThemeColors() {
        primary = getResources().getColor(R.color.lsv_primary);
        background = ThemeManager.background(this);
        surface = ThemeManager.surface(this);
        text = ThemeManager.primaryText(this);
        secondary = ThemeManager.secondaryText(this);
        getWindow().setStatusBarColor(
            getResources().getColor(R.color.lsv_status_bar)
        );
        getWindow().setNavigationBarColor(
            getResources().getColor(R.color.lsv_navigation_bar)
        );
    }

    private void buildUi() {
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(background);
        root.setClipToPadding(false);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                view.setPadding(0, top + dp(10), 0, bottom + dp(8));
                return insets;
            }
        });

        root.addView(buildToolbar(), new LinearLayout.LayoutParams(-1, dp(104)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(background);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(24), dp(18), dp(44));

        content.addView(buildHero(), new LinearLayout.LayoutParams(-1, dp(178)));

        TextView section = label("YOUR VIRTUAL APPS", 12, secondary);
        section.setTypeface(null, android.graphics.Typeface.BOLD);
        section.setPadding(dp(4), dp(24), 0, dp(10));
        content.addView(section, new LinearLayout.LayoutParams(-1, dp(48)));

        LinearLayout countRow = new LinearLayout(this);
        countRow.setGravity(Gravity.CENTER_VERTICAL);
        countText = label("0 applications", 13, secondary);
        countRow.addView(countText, new LinearLayout.LayoutParams(0, -1, 1));
        Button refresh = smallButton("Refresh");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { refreshList(); }
        });
        countRow.addView(refresh, new LinearLayout.LayoutParams(dp(92), dp(42)));
        content.addView(countRow, new LinearLayout.LayoutParams(-1, dp(54)));

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(listContainer, new LinearLayout.LayoutParams(-1, -2));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private View buildToolbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(18), dp(12), dp(12), dp(12));
        bar.setBackgroundColor(surface);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("LSV Virtual Space", 20, text);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView sub = label("Private app workspace", 11, secondary);
        titles.addView(title, new LinearLayout.LayoutParams(-1, dp(34)));
        titles.addView(sub, new LinearLayout.LayoutParams(-1, dp(24)));
        bar.addView(titles, new LinearLayout.LayoutParams(0, -1, 1));

        Button theme = smallButton("Theme");
        theme.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { showThemeDialog(); }
        });
        bar.addView(theme, new LinearLayout.LayoutParams(dp(78), dp(52)));

        Button overlay = smallButton("Overlay");
        overlay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                if (OverlayPermissionHelper.isGranted(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "LSV overlay permission is enabled", Toast.LENGTH_SHORT).show();
                } else {
                    OverlayPermissionHelper.openSettings(MainActivity.this);
                }
            }
        });
        LinearLayout.LayoutParams overlayLp = new LinearLayout.LayoutParams(dp(82), dp(52));
        overlayLp.leftMargin = dp(6);
        bar.addView(overlay, overlayLp);

        Button add = smallButton("+ Add");
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { showAddDialog(); }
        });
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(dp(78), dp(52));
        addLp.leftMargin = dp(10);
        bar.addView(add, addLp);

        return bar;
    }

    private View buildHero() {
        LinearLayout card = card();
        card.setPadding(dp(18), dp(16), dp(18), dp(16));

        TextView title = label("Your apps. Your space.", 22, text);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(title, new LinearLayout.LayoutParams(-1, dp(38)));

        TextView body = label(
            "Keep imported APKs and their virtual data separated from the host app.\n" +
            "Add an APK from storage or choose one already installed on this phone.",
            13,
            secondary
        );
        body.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(body, new LinearLayout.LayoutParams(-1, dp(78)));

        return card;
    }

    private void showAddDialog() {
        final Dialog dialog = new Dialog(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(14));
        root.setBackgroundColor(surface);

        TextView title = label("Add application", 20, text);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView hint = label("Choose how you want to add an application to LSV.", 13, secondary);
        hint.setPadding(0, 0, 0, dp(8));
        root.addView(hint, new LinearLayout.LayoutParams(-1, dp(38)));

        Button installed = dialogChoiceButton("Select from installed apps");
        installed.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                dialog.dismiss();
                showInstalledApps();
            }
        });
        root.addView(installed, new LinearLayout.LayoutParams(-1, dp(54)));

        Button storage = dialogChoiceButton("Select APK from storage");
        storage.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                dialog.dismiss();
                pickApk();
            }
        });
        LinearLayout.LayoutParams storageLp = new LinearLayout.LayoutParams(-1, dp(54));
        storageLp.topMargin = dp(10);
        root.addView(storage, storageLp);

        Button cancel = dialogChoiceButton("Cancel");
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { dialog.dismiss(); }
        });
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(-1, dp(48));
        cancelLp.topMargin = dp(12);
        root.addView(cancel, cancelLp);

        dialog.setContentView(root);
        dialog.setCancelable(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setDimAmount(0.35f);
        }
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(dp(330), -2);
        }
    }

    private Button dialogChoiceButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setTextColor(text);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(dp(16), 0, dp(16), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(background);
        bg.setStroke(dp(1), primary);
        bg.setCornerRadius(dp(13));
        button.setBackground(bg);
        return button;
    }

    private void showInstalledApps() {
        final Dialog loading = showLoadingDialog("Loading installed applications…");
        new Thread(new Runnable() {
            @Override public void run() {
                final List<InstalledAppInfo> apps = getInstalledApps();
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (loading.isShowing()) loading.dismiss();
                        showInstalledAppsDialog(apps);
                    }
                });
            }
        }).start();
    }

    private void showInstalledAppsDialog(final List<InstalledAppInfo> apps) {
        if (apps.isEmpty()) {
            new AlertDialog.Builder(this)
                .setTitle("Installed apps")
                .setMessage("No selectable user applications were found. You can still choose an APK file from storage.")
                .setPositiveButton("Choose APK", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface dialog, int which) {
                        pickApk();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
            return;
        }

        final LinearLayout dialogRoot = new LinearLayout(this);
        dialogRoot.setOrientation(LinearLayout.VERTICAL);
        dialogRoot.setPadding(dp(18), dp(4), dp(18), dp(8));

        final EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search applications");
        search.setTextColor(text);
        search.setHintTextColor(secondary);
        search.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable searchBg = new GradientDrawable();
        searchBg.setColor(surface);
        searchBg.setCornerRadius(dp(14));
        search.setBackground(searchBg);
        dialogRoot.addView(search, new LinearLayout.LayoutParams(-1, dp(52)));

        final ScrollView scroll = new ScrollView(this);
        final LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        rows.setPadding(0, dp(10), 0, 0);
        scroll.addView(rows);
        dialogRoot.addView(scroll, new LinearLayout.LayoutParams(-1, dp(430)));

        final AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Select installed app")
            .setView(dialogRoot)
            .setNegativeButton("Cancel", null)
            .create();

        final Runnable[] renderHolder = new Runnable[1];
        renderHolder[0] = new Runnable() {
            @Override public void run() {
                rows.removeAllViews();
                String query = search.getText().toString().trim().toLowerCase();
                int shown = 0;
                for (int i = 0; i < apps.size(); i++) {
                    final InstalledAppInfo app = apps.get(i);
                    String haystack = (app.getLabel() + " " + app.getPackageName()).toLowerCase();
                    if (query.length() > 0 && haystack.indexOf(query) < 0) continue;

                    LinearLayout row = new LinearLayout(MainActivity.this);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(dp(10), dp(8), dp(10), dp(8));
                    GradientDrawable rowBg = new GradientDrawable();
                    rowBg.setColor(surface);
                    rowBg.setCornerRadius(dp(14));
                    row.setBackground(rowBg);

                    ImageView icon = new ImageView(MainActivity.this);
                    if (app.getIcon() != null) icon.setImageDrawable(app.getIcon());
                    row.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

                    LinearLayout names = new LinearLayout(MainActivity.this);
                    names.setOrientation(LinearLayout.VERTICAL);
                    names.setPadding(dp(12), 0, dp(8), 0);
                    TextView name = label(app.getLabel(), 15, text);
                    name.setTypeface(null, android.graphics.Typeface.BOLD);
                    TextView pkg = label(app.getPackageName(), 11, secondary);
                    names.addView(name, new LinearLayout.LayoutParams(-1, dp(26)));
                    names.addView(pkg, new LinearLayout.LayoutParams(-1, dp(22)));
                    row.addView(names, new LinearLayout.LayoutParams(0, dp(58), 1));

                    Button select = smallButton("Add");
                    select.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View view) {
                            dialog.dismiss();
                            importInstalled(app);
                        }
                    });
                    row.addView(select, new LinearLayout.LayoutParams(dp(70), dp(44)));

                    LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, dp(74));
                    rowLp.bottomMargin = dp(8);
                    rows.addView(row, rowLp);
                    shown++;
                }
                if (shown == 0) {
                    TextView empty = label("No applications match your search.", 13, secondary);
                    empty.setGravity(Gravity.CENTER);
                    rows.addView(empty, new LinearLayout.LayoutParams(-1, dp(80)));
                }
            }
        };
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderHolder[0].run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        dialog.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override public void onShow(android.content.DialogInterface d) { renderHolder[0].run(); }
        });
        dialog.show();
        applyDialogTheme(dialog);
    }

    private List<InstalledAppInfo> getInstalledApps() {
        List<InstalledAppInfo> result = new ArrayList<InstalledAppInfo>();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> installed = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        for (ApplicationInfo info : installed) {
            if (info == null || info.packageName == null) continue;
            if (getPackageName().equals(info.packageName)) continue;
            if (info.sourceDir == null) continue;

            boolean system = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            boolean updatedSystem = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
            if (system && !updatedSystem) continue;

            CharSequence labelCs = info.loadLabel(pm);
            String label = labelCs == null ? info.packageName : labelCs.toString();
            result.add(new InstalledAppInfo(info.packageName, label, info.sourceDir, info.loadIcon(pm)));
        }

        Collections.sort(result, new Comparator<InstalledAppInfo>() {
            @Override
            public int compare(InstalledAppInfo left, InstalledAppInfo right) {
                return left.getLabel().compareToIgnoreCase(right.getLabel());
            }
        });
        return result;
    }

    private void importInstalled(final InstalledAppInfo info) {
        final Dialog loading = showLoadingDialog("Adding " + info.getLabel() + "…");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final VirtualApp app = repository.importInstalledPackage(info.getPackageName());
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (loading.isShowing()) loading.dismiss();
                            Toast.makeText(MainActivity.this, app.getLabel() + " added to LSV", Toast.LENGTH_LONG).show();
                            refreshList();
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (loading.isShowing()) loading.dismiss();
                            Toast.makeText(
                                MainActivity.this,
                                "Could not copy installed APK: " + e.getMessage() +
                                "\nIf Android blocks direct APK access, choose the APK from storage instead.",
                                Toast.LENGTH_LONG
                            ).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void pickApk() {
        pickerLoading = showLoadingDialog("Opening APK picker…");
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(intent, PICK_APK);
        } catch (Throwable error) {
            if (pickerLoading != null && pickerLoading.isShowing()) pickerLoading.dismiss();
            pickerLoading = null;
            Toast.makeText(this, "Could not open the APK picker: " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_APK && pickerLoading != null) {
            if (pickerLoading.isShowing()) pickerLoading.dismiss();
            pickerLoading = null;
        }

        if (requestCode == EXPORT_APK) {
            if (resultCode == RESULT_OK && data != null) finishExport(data.getData());
            return;
        }

        if (requestCode != PICK_APK || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) {
            Toast.makeText(this, "No APK was selected", Toast.LENGTH_SHORT).show();
            return;
        }
        installSelectedApk(uri);
    }

    private void installSelectedApk(final Uri uri) {
        final Dialog loading = showLoadingDialog("Importing APK…");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final VirtualApp app = repository.importApk(uri);
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (loading.isShowing()) loading.dismiss();
                            Toast.makeText(MainActivity.this, app.getLabel() + " added to LSV", Toast.LENGTH_LONG).show();
                            refreshList();
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (loading.isShowing()) loading.dismiss();
                            Toast.makeText(MainActivity.this, "APK import failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void refreshList() {
        if (listContainer == null) return;
        listContainer.removeAllViews();
        List<VirtualApp> apps = repository.getApps();
        if (countText != null) {
            countText.setText(apps.size() + (apps.size() == 1 ? " application" : " applications"));
        }

        if (apps.isEmpty()) {
            LinearLayout empty = card();
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(22), dp(24), dp(22), dp(24));
            TextView title = label("Your virtual space is empty", 18, text);
            title.setGravity(Gravity.CENTER);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            empty.addView(title, new LinearLayout.LayoutParams(-1, dp(34)));
            TextView message = label("Tap + Add to choose an installed app or import an APK file.", 13, secondary);
            message.setGravity(Gravity.CENTER);
            empty.addView(message, new LinearLayout.LayoutParams(-1, dp(48)));
            listContainer.addView(empty, new LinearLayout.LayoutParams(-1, dp(150)));
            return;
        }

        for (VirtualApp app : apps) addAppRow(app);
    }

    private void addAppRow(final VirtualApp app) {
        LinearLayout card = card();
        card.setPadding(dp(14), dp(14), dp(14), dp(12));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        ImageView icon = new ImageView(this);
        icon.setImageDrawable(loadAppIcon(app));
        top.addView(icon, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = label(app.getLabel(), 17, text);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView packageName = label(app.getPackageName(), 11, secondary);
        names.addView(name, new LinearLayout.LayoutParams(-1, dp(27)));
        names.addView(packageName, new LinearLayout.LayoutParams(-1, dp(22)));
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, dp(54), 1);
        nameLp.leftMargin = dp(12);
        top.addView(names, nameLp);
        card.addView(top, new LinearLayout.LayoutParams(-1, dp(58)));

        TextView state = label("Private LSV copy  •  Ready", 11, secondary);
        state.setPadding(dp(62), 0, 0, dp(4));
        card.addView(state, new LinearLayout.LayoutParams(-1, dp(28)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        Button launch = actionButton("Launch");
        launch.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { prepareForLaunch(app); }
        });
        Button export = actionButton("Export");
        export.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { beginExport(app); }
        });
        Button remove = actionButton("Remove");
        remove.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { removeApp(app); }
        });

        actions.addView(launch, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout.LayoutParams exportLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        exportLp.leftMargin = dp(6);
        actions.addView(export, exportLp);
        LinearLayout.LayoutParams removeLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        removeLp.leftMargin = dp(6);
        actions.addView(remove, removeLp);
        card.addView(actions, new LinearLayout.LayoutParams(-1, dp(54)));

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, dp(208));
        cardLp.bottomMargin = dp(10);
        listContainer.addView(card, cardLp);
    }

    private android.graphics.drawable.Drawable loadAppIcon(VirtualApp app) {
        try {
            PackageManager pm = getPackageManager();
            android.content.pm.PackageInfo info = pm.getPackageArchiveInfo(
                app.getApkPath(), PackageManager.GET_META_DATA
            );
            if (info != null && info.applicationInfo != null) {
                info.applicationInfo.sourceDir = app.getApkPath();
                info.applicationInfo.publicSourceDir = app.getApkPath();
                return info.applicationInfo.loadIcon(pm);
            }
        } catch (Exception ignored) {
        }
        return getDrawable(android.R.drawable.sym_def_app_icon);
    }

    private void prepareForLaunch(final VirtualApp app) {
        com.lsv.virtualspace.virtual.GuestLaunchInfo info =
            VirtualCore.get().getRuntimeController().prepare(app);
        if (info == null) {
            Toast.makeText(this, "This APK has no usable exported activity.", Toast.LENGTH_LONG).show();
            return;
        }

        final Dialog progress = showGuestLaunchProgress(app);
        com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.begin(this, app, info.getActivityName());
        com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.stage(this,
            com.lsv.virtualspace.diagnostics.GuestRuntimeStage.LAUNCH_REQUESTED,
            com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.preflight(this, app));
        com.lsv.virtualspace.diagnostics.GuestRuntimeVerification.Result verification =
            com.lsv.virtualspace.diagnostics.GuestRuntimeVerification.verify(this, app);
        com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.stage(this,
            "RUNTIME_VERIFICATION", verification.text.toString());
        com.lsv.virtualspace.diagnostics.health.GuestHealthSuite.Result health =
            com.lsv.virtualspace.diagnostics.health.GuestHealthSuite.run(this, app);
        com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.stage(this,
            "GUEST_HEALTH_SUITE", health.text);
        if (!verification.isHealthy()) {
            android.widget.Toast.makeText(this, "Guest preflight found " + verification.failed + " issue(s); launch will continue so diagnostics can capture the exact runtime boundary.", android.widget.Toast.LENGTH_LONG).show();
        }
        com.lsv.virtualspace.virtual.VirtualAppEngine.LaunchResult result =
            com.lsv.virtualspace.virtual.VirtualAppEngine.installAndLaunch(this, app);
        if (result.isSuccess()) {
            activeGuestPackage = app.getPackageName();
            if (guestWatchdog == null) guestWatchdog = new com.lsv.virtualspace.diagnostics.GuestProcessWatchdog(this);
            guestWatchdog.start(app.getPackageName(), getPackageName() + ":guest",
                new com.lsv.virtualspace.diagnostics.GuestProcessWatchdog.Listener() {
                    @Override public void onGuestProcessLost(String report) {
                        if (progress.isShowing()) progress.dismiss();
                        showGuestCrashReport(app, report);
                    }
                });
            new android.os.Handler(getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() {
                    if (progress.isShowing()) progress.dismiss();
                }
            }, 1600);
            return;
        }
        if (progress.isShowing()) progress.dismiss();
        showLaunchFallback(app, result.getError());
    }

    private Dialog showGuestLaunchProgress(final VirtualApp app) {
        final Dialog dialog = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(32), dp(28), dp(32), dp(28));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ThemeManager.surface(this));
        bg.setCornerRadius(dp(22));
        box.setBackground(bg);

        ProgressBar spinner = new ProgressBar(this);
        box.addView(spinner, new LinearLayout.LayoutParams(dp(52), dp(52)));
        TextView title = label("Launching " + app.getLabel(), 17, ThemeManager.primaryText(this));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(14), 0, dp(4));
        box.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));
        TextView state = label("Starting in LSV virtual environment...", 12, ThemeManager.secondaryText(this));
        state.setGravity(Gravity.CENTER);
        box.addView(state, new LinearLayout.LayoutParams(-1, dp(30)));

        dialog.setContentView(box);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setDimAmount(0.35f);
            dialog.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.setCancelable(false);
        dialog.show();
        return dialog;
    }

    private void showLaunchFallback(final VirtualApp app, String engineError) {
        String latest = com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.latest(this, app.getPackageName());
        if (latest == null) latest = com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.active(this, app.getPackageName());
        String message =
            "LSV could not start the guest inside its virtual process.\n\n" +
            "Engine detail: " + (engineError == null ? "unknown" : engineError) +
            "\n\nPreflight:\n" + com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.preflight(this, app) +
            "\n\nLast guest report:\n" + (latest == null ? "none" : latest) +
            "\nAndroid compatibility launch is intentionally not used here: the target must stay inside LSV.";

        new AlertDialog.Builder(this)
            .setTitle("Virtual launch failed")
            .setMessage(message)
            .setPositiveButton("Retry virtual launch", new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface dialog, int which) {
                    prepareForLaunch(app);
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showGuestCrashReport(VirtualApp app, String report) {
        if (report == null || report.length() == 0) {
            report = com.lsv.virtualspace.diagnostics.GuestDiagnosticsFacade.latest(this, app.getPackageName());
        }
        if (report == null || report.length() == 0) report = "No persisted guest report was available.";
        final String finalReport = report;
        new AlertDialog.Builder(this)
            .setTitle("Guest application crashed")
            .setMessage(finalReport)
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy report", new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface dialog, int which) {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("LSV guest crash", finalReport));
                    Toast.makeText(MainActivity.this, "Crash report copied", Toast.LENGTH_SHORT).show();
                }
            }).show();
    }

    private void removeApp(VirtualApp app) {
        if (repository.uninstall(app.getPackageName())) {
            Toast.makeText(this, app.getLabel() + " removed from LSV", Toast.LENGTH_SHORT).show();
            refreshList();
        } else {
            Toast.makeText(this, "Could not remove " + app.getLabel(), Toast.LENGTH_SHORT).show();
        }
    }

    private void beginExport(VirtualApp app) {
        exportTarget = app;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.android.package-archive");
        intent.putExtra(Intent.EXTRA_TITLE, app.getLabel() + ".apk");
        startActivityForResult(intent, EXPORT_APK);
    }

    private void finishExport(Uri uri) {
        if (exportTarget == null || uri == null) return;
        boolean ok = StorageExportManager.exportFile(this, new File(exportTarget.getApkPath()), uri);
        Toast.makeText(this, ok ? "APK saved to selected storage" : "Could not save APK", Toast.LENGTH_LONG).show();
        exportTarget = null;
    }

    private void showThemeDialog() {
        final String[] names = new String[] {
            "System default", "Light", "Dark", "Black", "White"
        };
        final String[] values = new String[] {
            ThemeManager.THEME_SYSTEM, ThemeManager.THEME_LIGHT,
            ThemeManager.THEME_DARK, ThemeManager.THEME_BLACK,
            ThemeManager.THEME_WHITE
        };
        String current = ThemeManager.getTheme(this);
        int checked = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(current)) checked = i;
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Choose theme")
            .setSingleChoiceItems(names, checked, new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface dialog, int which) {
                    ThemeManager.setTheme(MainActivity.this, values[which]);
                    dialog.dismiss();
                    recreate();
                }
            })
            .setNegativeButton("Cancel", null)
            .create();
        dialog.show();
        applyDialogTheme(dialog);
    }

    private Dialog showLoadingDialog(String message) {
        final Dialog dialog = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(22), dp(18), dp(22), dp(18));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(surface);
        bg.setCornerRadius(dp(18));
        box.setBackground(bg);

        ProgressBar progress = new ProgressBar(this);
        box.addView(progress, new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView label = label(message, 14, text);
        label.setPadding(dp(14), 0, 0, 0);
        box.addView(label, new LinearLayout.LayoutParams(0, dp(46), 1));

        dialog.setContentView(box);
        dialog.setCancelable(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setDimAmount(0.32f);
        }
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(dp(300), dp(84));
        }
        return dialog;
    }

    private void applyDialogTheme(AlertDialog dialog) {
        if (dialog == null) return;
        int dialogSurface = ThemeManager.surface(this);
        int dialogText = ThemeManager.primaryText(this);
        int dialogSecondary = ThemeManager.secondaryText(this);
        if (dialog.getWindow() != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(dialogSurface);
            bg.setCornerRadius(dp(18));
            dialog.getWindow().setBackgroundDrawable(bg);
        }
        TextView message = dialog.findViewById(android.R.id.message);
        if (message != null) message.setTextColor(dialogSecondary);
        TextView title = dialog.findViewById(getResources().getIdentifier("alertTitle", "id", "android"));
        if (title != null) title.setTextColor(dialogText);
        View decor = dialog.getWindow() == null ? null : dialog.getWindow().getDecorView();
        applyTextColors(decor, dialogText, dialogSecondary);

        Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button neutral = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        if (positive != null) positive.setTextColor(dialogText);
        if (negative != null) negative.setTextColor(dialogText);
        if (neutral != null) neutral.setTextColor(dialogText);

        android.widget.ListView list = dialog.getListView();
        if (list != null) {
            list.setBackgroundColor(dialogSurface);
            for (int i = 0; i < list.getChildCount(); i++) {
                applyTextColors(list.getChildAt(i), dialogText, dialogSecondary);
            }
        }
    }

    private void applyTextColors(View view, int primaryColor, int secondaryColor) {
        if (view == null) return;
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            if (tv.getId() == android.R.id.message) tv.setTextColor(secondaryColor);
            else if (tv.getText() != null && tv.getText().length() > 0) tv.setTextColor(primaryColor);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                applyTextColors(group.getChildAt(i), primaryColor, secondaryColor);
            }
        }
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(surface);
        bg.setCornerRadius(dp(16));
        layout.setBackground(bg);
        return layout;
    }

    private Button actionButton(String value) {
        Button button = smallButton(value);
        button.setAllCaps(false);
        return button;
    }

    private Button smallButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setTextColor(text);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setPadding(dp(6), 0, dp(6), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(surface);
        bg.setStroke(dp(1), primary);
        bg.setCornerRadius(dp(12));
        button.setBackground(bg);
        return button;
    }

    private TextView label(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        if (guestWatchdog != null) guestWatchdog.stop();
        guestWatchdog = null;
        if (pickerLoading != null && pickerLoading.isShowing()) pickerLoading.dismiss();
        pickerLoading = null;
        super.onDestroy();
    }
}
