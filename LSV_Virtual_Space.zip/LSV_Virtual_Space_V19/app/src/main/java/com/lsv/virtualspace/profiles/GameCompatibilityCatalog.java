package com.lsv.virtualspace.profiles;
import java.util.*;
public final class GameCompatibilityCatalog {
    private final Map<String,String> packages=new HashMap<String,String>();
    public GameCompatibilityCatalog(){
        packages.put("com.dts.freefireth","Free Fire"); packages.put("com.dts.freefiremax","Free Fire MAX");
        packages.put("com.activision.callofduty.shooter","Call of Duty: Mobile");
        packages.put("com.tencent.ig","PUBG Mobile"); packages.put("com.pubg.imobile","PUBG Mobile");
    }
    public boolean isKnownGame(String p){return packages.containsKey(p);} public String getName(String p){return packages.get(p);}
    public Set<String> getKnownPackages(){return new HashSet<String>(packages.keySet());}
}
