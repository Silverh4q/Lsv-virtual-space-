package com.lsv.virtualspace.virtual;

import com.lsv.virtualspace.apps.VirtualApp;

/**
 * Represents the lifecycle state of one virtual-app session.
 *
 * This object does not inject into or modify another process. It records the
 * state that the eventual guest execution backend must manage.
 */
public class GuestSession {
    public static final int STATE_CREATED = 0;
    public static final int STATE_PREPARED = 1;
    public static final int STATE_RUNNING = 2;
    public static final int STATE_STOPPED = 3;
    public static final int STATE_FAILED = 4;

    private final VirtualApp app;
    private int state;
    private String activityName;
    private String error;

    public GuestSession(VirtualApp app) {
        this.app = app;
        this.state = STATE_CREATED;
    }

    public VirtualApp getApp() {
        return app;
    }

    public int getState() {
        return state;
    }

    public String getActivityName() {
        return activityName;
    }

    public String getError() {
        return error;
    }

    public void prepared(String activityName) {
        this.activityName = activityName;
        this.error = null;
        this.state = STATE_PREPARED;
    }

    public void running() {
        this.error = null;
        this.state = STATE_RUNNING;
    }

    public void stopped() {
        this.state = STATE_STOPPED;
    }

    public void failed(String message) {
        this.error = message;
        this.state = STATE_FAILED;
    }
}
