package com.lsv.virtualspace.framework.binder;

import android.os.Bundle;

public final class GuestBinderReply {
    private final boolean success;
    private final String message;
    private final Bundle data;
    private GuestBinderReply(boolean success, String message, Bundle data) {
        this.success = success;
        this.message = message;
        this.data = data == null ? new Bundle() : new Bundle(data);
    }
    public static GuestBinderReply ok(Bundle data) { return new GuestBinderReply(true, "OK", data); }
    public static GuestBinderReply fail(String message) { return new GuestBinderReply(false, message, null); }
    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public Bundle getData() { return new Bundle(data); }
}
