package com.lsv.virtualspace.guest.runtime;

import android.app.Activity;
import android.app.Application;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Resources;
import android.content.pm.ActivityInfo;
import android.view.ContextThemeWrapper;

import com.lsv.virtualspace.hidden.HiddenApiBootstrap;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Framework bridge for a guest Activity.
 *
 * Android creates the Activity/window in the real :guest process. LSV then
 * replaces the Activity's context/application/resource state with the virtual
 * guest state. This is intentionally package-agnostic: the same path is used
 * for Java/Kotlin, Unity, Flutter and other Android Activity implementations.
 */
public final class GuestActivityContextBridge {
    private GuestActivityContextBridge() { }

    public static void bind(Activity activity, GuestContext guestContext,
                            Resources guestResources, Application guestApplication,
                            ActivityInfo activityInfo, Intent guestIntent,
                            int themeResId) throws Exception {
        if (activity == null || guestContext == null) {
            throw new IllegalArgumentException("activity/context == null");
        }

        // HiddenApiBootstrap is best-effort. On releases/vendors that permit
        // the access, the fields below provide the complete guest Context
        // boundary. If Android blocks them, the exception is surfaced instead
        // of silently pretending that virtualization succeeded.
        GuestDiagnosticController diagnostics = GuestDiagnosticController.get(activity);
        diagnostics.stage(GuestRuntimeStage.ACTIVITY_PREPARE, "hidden API bootstrap");
        HiddenApiBootstrap.initialize(activity);

        diagnostics.stage(GuestRuntimeStage.ACTIVITY_PREPARE, "bind ContextWrapper.mBase");
        setField(ContextWrapper.class, activity, "mBase", guestContext, true);
        setField(ContextThemeWrapper.class, activity, "mResources", guestResources, false);

        diagnostics.stage(GuestRuntimeStage.ACTIVITY_PREPARE, "bind guest resources/theme");
        if (themeResId != 0 && guestResources != null) {
            Resources.Theme theme = guestResources.newTheme();
            theme.applyStyle(themeResId, true);
            setField(ContextThemeWrapper.class, activity, "mTheme", theme, false);
            setField(ContextThemeWrapper.class, activity, "mThemeResource",
                Integer.valueOf(themeResId), false);
        }

        diagnostics.stage(GuestRuntimeStage.ACTIVITY_PREPARE, "bind guest application/info/intent");
        if (guestApplication != null) {
            setField(Activity.class, activity, "mApplication", guestApplication, true);
        }
        if (activityInfo != null) {
            setField(Activity.class, activity, "mActivityInfo", activityInfo, true);
        }
        if (guestIntent != null) {
            activity.setIntent(guestIntent);
            setField(Activity.class, activity, "mIntent", guestIntent, false);
        }
    }

    /** Attach a guest Application to the virtual Context before onCreate. */
    public static void attachApplication(Application application, GuestContext context)
            throws Exception {
        if (application == null || context == null) return;
        GuestDiagnosticController.get(context).stage(GuestRuntimeStage.APPLICATION_ATTACH, "Application.attach");
        HiddenApiBootstrap.initialize(context);
        Method attach = Application.class.getDeclaredMethod("attach", android.content.Context.class);
        attach.setAccessible(true);
        attach.invoke(application, context);
        context.setGuestApplication(application);
    }

    private static void setField(Class<?> owner, Object target, String name,
                                 Object value, boolean required) throws Exception {
        try {
            Field field = owner.getDeclaredField(name);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Throwable error) {
            if (required) {
                throw new IllegalStateException("Unable to virtualize " + owner.getName()
                    + "." + name + ": " + error, error);
            }
        }
    }
}
