package com.lsv.virtualspace.storage;

import java.io.File;

/** Stable directory layout for one virtual package. */
public final class GuestStorageLayout {
    private final File root;

    public GuestStorageLayout(File root) { this.root = root; }
    public File getRoot() { return root; }
    public File getData() { return new File(root, "data"); }
    public File getFiles() { return new File(getData(), "files"); }
    public File getCache() { return new File(getData(), "cache"); }
    public File getCodeCache() { return new File(getData(), "code_cache"); }
    public File getDatabase() { return new File(getData(), "databases"); }
    public File getSharedPrefs() { return new File(getData(), "shared_prefs"); }
    public File getDex() { return new File(getData(), "dex"); }

    public void ensure() {
        getRoot().mkdirs(); getData().mkdirs(); getFiles().mkdirs(); getCache().mkdirs();
        getCodeCache().mkdirs(); getDatabase().mkdirs(); getSharedPrefs().mkdirs(); getDex().mkdirs();
    }
}
