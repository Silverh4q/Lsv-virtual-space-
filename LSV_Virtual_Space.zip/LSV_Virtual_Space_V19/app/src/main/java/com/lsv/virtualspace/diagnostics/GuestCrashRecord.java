package com.lsv.virtualspace.diagnostics;
public final class GuestCrashRecord { private final String packageName,time,summary; public GuestCrashRecord(String p,String t,String s){packageName=p;time=t;summary=s;} public String getPackageName(){return packageName;} public String getTime(){return time;} public String getSummary(){return summary;} }
