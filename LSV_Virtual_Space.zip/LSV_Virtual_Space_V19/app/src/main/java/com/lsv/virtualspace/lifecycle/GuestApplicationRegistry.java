package com.lsv.virtualspace.lifecycle;

import java.util.HashMap;
import java.util.Map;

/** Tracks guest lifecycle state without pretending a guest process exists. */
public final class GuestApplicationRegistry {
    private final Map<String, GuestApplicationRecord> records =
        new HashMap<String, GuestApplicationRecord>();

    public synchronized GuestApplicationRecord getOrCreate(String packageName) {
        GuestApplicationRecord r = records.get(packageName);
        if (r == null) {
            r = new GuestApplicationRecord(packageName);
            records.put(packageName, r);
        }
        return r;
    }

    public synchronized void clear(String packageName) { records.remove(packageName); }
    public synchronized void clearAll() { records.clear(); }
}
