package com.lsv.virtualspace.storage;
import java.io.*;
public final class GuestStorageManager { private final GuestCacheManager cache=new GuestCacheManager(); public long getUsage(File root){return cache.size(root);} public GuestStorageQuota defaultQuota(){return new GuestStorageQuota(2L*1024L*1024L*1024L);} public void clearCache(File cacheDir){cache.clear(cacheDir);} }
