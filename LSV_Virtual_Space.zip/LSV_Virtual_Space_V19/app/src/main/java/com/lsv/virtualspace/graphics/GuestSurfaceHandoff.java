package com.lsv.virtualspace.graphics;

import android.view.Surface;

/** Describes a host-owned Surface handoff; it does not inject frames or native code. */
public final class GuestSurfaceHandoff {
    private Surface surface;
    private int width;
    private int height;

    public synchronized void attach(Surface surface, int width, int height) {
        this.surface = surface;
        this.width = Math.max(0, width);
        this.height = Math.max(0, height);
    }

    public synchronized Surface getSurface() { return surface; }
    public synchronized int getWidth() { return width; }
    public synchronized int getHeight() { return height; }
    public synchronized void detach() { surface = null; width = 0; height = 0; }
}
