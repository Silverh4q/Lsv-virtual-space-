package com.lsv.virtualspace.process;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Process;

/**
 * Very small cross-process bootstrap probe. It deliberately uses only
 * SharedPreferences so it can run before the virtual framework is initialized.
 */
public final class GuestProcessProbe {
    private static final String PREFS = "lsv_guest_process_probe";
    private static final String KEY_PID = "pid";
    private static final String KEY_STATE = "state";
    private static final String KEY_TIME = "time";
    private static final String KEY_PACKAGE = "package";
    private static final String KEY_COMPONENT = "component";

    private GuestProcessProbe() { }

    public static void mark(Context context, String state, String packageName, String component) {
        if (context == null) return;
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            p.edit()
                .putInt(KEY_PID, Process.myPid())
                .putString(KEY_STATE, state == null ? "UNKNOWN" : state)
                .putLong(KEY_TIME, System.currentTimeMillis())
                .putString(KEY_PACKAGE, packageName == null ? "" : packageName)
                .putString(KEY_COMPONENT, component == null ? "" : component)
                .commit();
        } catch (Throwable ignored) {
        }
    }

    public static String describe(Context context) {
        if (context == null) return "probe unavailable";
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String state = p.getString(KEY_STATE, "NONE");
            int pid = p.getInt(KEY_PID, -1);
            long time = p.getLong(KEY_TIME, 0L);
            String pkg = p.getString(KEY_PACKAGE, "");
            String component = p.getString(KEY_COMPONENT, "");
            return "state=" + state + ", pid=" + pid + ", time=" + time
                + ", package=" + pkg + ", component=" + component;
        } catch (Throwable error) {
            return "probe read failed: " + error.getClass().getName();
        }
    }

    public static void clear(Context context) {
        if (context == null) return;
        try { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit(); }
        catch (Throwable ignored) { }
    }
}
