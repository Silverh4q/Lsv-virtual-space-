package com.lsv.virtualspace.google;

public final class PlayServicesStatus {
    public static final int NOT_CONFIGURED = 0;
    public static final int DETECTED = 1;
    public static final int COMPATIBILITY_PENDING = 2;

    private PlayServicesStatus() {
    }
}
