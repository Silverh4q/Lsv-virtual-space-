package com.lsv.virtualspace.proxy;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.lsv.virtualspace.R;
import com.lsv.virtualspace.ThemeManager;
import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.framework.GuestActivityContract;
import com.lsv.virtualspace.framework.GuestTaskManager;
import com.lsv.virtualspace.guest.runtime.GuestInstrumentation;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;
import com.lsv.virtualspace.virtual.VirtualAppLookup;
import com.lsv.virtualspace.virtual.VirtualCore;

/** Host-side route endpoint for a virtual app. */
public final class GuestActivityProxy extends Activity {
    private GuestTaskManager tasks;
    private GuestProxyLifecycleController lifecycle;

    @Override
    protected void onCreate(Bundle state) {
        ThemeManager.apply(this);
        super.onCreate(state);
        tasks = VirtualCore.get().getGuestTaskManager();
        lifecycle = new GuestProxyLifecycleController(this);
        lifecycle.configureWindow();
        GuestDiagnosticController.get(this).stage(GuestRuntimeStage.PROCESS_ATTACHED,
            "GuestActivityProxy.onCreate pid=" + android.os.Process.myPid());
        if (!GuestInstrumentation.isInstalled()) {
            GuestDiagnosticController.get(this).stage(GuestRuntimeStage.FAILED,
                "GuestInstrumentation is not installed; proxy cannot substitute guest Activity");
        }

        String packageName = getIntent().getStringExtra(GuestActivityContract.EXTRA_PACKAGE);
        String component = getIntent().getStringExtra(GuestActivityContract.EXTRA_COMPONENT);
        VirtualApp app = VirtualAppLookup.find(VirtualCore.get().getAppRepository(), packageName);

        if (app == null || component == null) {
            showInvalid();
            return;
        }

        lifecycle.onCreate(app, component);

        // The proxy is only the Android route endpoint. GuestInstrumentation
        // replaces it with the guest Activity while Android continues to own
        // the real Activity/window lifecycle.
        final String appClass = app.getPackageName();
        showHandOff(app, component, appClass);
    }

    private void showHandOff(final VirtualApp app, final String component, final String appClass) {
        int background = ThemeManager.background(this);
        int surface = ThemeManager.surface(this);
        int text = ThemeManager.primaryText(this);
        int secondary = ThemeManager.secondaryText(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(background);

        LinearLayout card = card(surface);
        ProgressBar spinner = new ProgressBar(this);
        LinearLayout.LayoutParams spinnerLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        spinnerLp.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(spinner, spinnerLp);

        TextView title = text(app.getLabel(), 21, text);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView status = text("STARTING GUEST", 12, getResources().getColor(R.color.lsv_primary));
        status.setGravity(Gravity.CENTER);
        status.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(status, new LinearLayout.LayoutParams(-1, dp(32)));

        TextView details = text(
            "Virtual component\n" + component +
            "\n\nLSV proxy process is active.\n" +
            "Android is being asked to start the guest using its supported application lifecycle.",
            13, secondary
        );
        details.setGravity(Gravity.CENTER);
        card.addView(details, new LinearLayout.LayoutParams(-1, dp(150)));

        root.addView(card, new LinearLayout.LayoutParams(-1, dp(390)));
        setContentView(root);

        new android.os.Handler(getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() {
                boolean launched = lifecycle != null && lifecycle.handOffToAndroid();
                if (!launched) {
                    showGuestFailure(app, component, appClass, "LSV virtual instrumentation",
                        "The LSV guest Activity was not substituted by the virtual instrumentation bridge. The target was not launched outside LSV.");
                } else {
                    finish();
                }
            }
        }, 120);
    }

    private void showGuestFailure(final VirtualApp app, String component, String appClass, String api, String error) {
        int background = ThemeManager.background(this);
        int surface = ThemeManager.surface(this);
        int text = ThemeManager.primaryText(this);
        int secondary = ThemeManager.secondaryText(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(background);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(18));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(surface);
        cardBg.setCornerRadius(dp(20));
        card.setBackground(cardBg);

        ImageView icon = new ImageView(this);
        icon.setImageDrawable(loadIcon(app));
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(64), dp(64));
        iconLp.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(icon, iconLp);

        TextView title = text(app.getLabel(), 21, text);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView state = text("GUEST EXECUTION BLOCKED", 11, getResources().getColor(R.color.lsv_primary));
        state.setGravity(Gravity.CENTER);
        state.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(state, new LinearLayout.LayoutParams(-1, dp(28)));

        TextView details = text(
            "Activity\n" + component +
            "\n\nGuest application\n" + appClass +
            "\n\n" + api,
            13,
            secondary
        );
        details.setGravity(Gravity.CENTER);
        card.addView(details, new LinearLayout.LayoutParams(-1, dp(190)));

        TextView note = text(
            "LSV attempted real in-process guest execution.\n" +
            "Android rejected the required framework attachment: " + error,
            12,
            secondary
        );
        note.setGravity(Gravity.CENTER);
        card.addView(note, new LinearLayout.LayoutParams(-1, dp(76)));

        Button close = new Button(this);
        close.setText("Back to LSV");
        close.setAllCaps(false);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { finish(); }
        });
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, dp(48));
        closeLp.topMargin = dp(8);
        card.addView(close, closeLp);

        root.addView(card, new LinearLayout.LayoutParams(-1, dp(500)));
        setContentView(root);
    }

    private LinearLayout card(int surface) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(18));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(surface);
        bg.setCornerRadius(dp(20));
        card.setBackground(bg);
        return card;
    }

    private void showInvalid() {
        int background = ThemeManager.background(this);
        int text = ThemeManager.primaryText(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(28), dp(28), dp(28));
        root.setBackgroundColor(background);
        TextView title = text("Guest route unavailable", 21, text);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView body = text("The virtual app was removed or its route is invalid.", 14, ThemeManager.secondaryText(this));
        body.setGravity(Gravity.CENTER);
        root.addView(body, new LinearLayout.LayoutParams(-1, dp(80)));
        Button close = new Button(this);
        close.setText("Back to LSV");
        close.setAllCaps(false);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { finish(); }
        });
        root.addView(close, new LinearLayout.LayoutParams(-1, dp(48)));
        setContentView(root);
    }

    private android.graphics.drawable.Drawable loadIcon(VirtualApp app) {
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            android.content.pm.PackageInfo info = pm.getPackageArchiveInfo(app.getApkPath(), 0);
            if (info != null && info.applicationInfo != null) {
                info.applicationInfo.sourceDir = app.getApkPath();
                info.applicationInfo.publicSourceDir = app.getApkPath();
                return info.applicationInfo.loadIcon(pm);
            }
        } catch (Exception ignored) {
        }
        return getDrawable(android.R.drawable.sym_def_app_icon);
    }

    private TextView text(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        String packageName = getIntent().getStringExtra(GuestActivityContract.EXTRA_PACKAGE);
        if (lifecycle != null) {
            lifecycle.onDestroy();
        } else if (tasks != null && packageName != null) {
            tasks.close(packageName);
        }
        super.onDestroy();
    }
}
