package com.lsv.virtualspace.ipc;

public final class GuestLaunchRequest {
    private final String packageName;
    private final String activityName;
    private final String apkPath;
    private final String dataPath;
    public GuestLaunchRequest(String p,String a,String apk,String data){packageName=p;activityName=a;apkPath=apk;dataPath=data;}
    public String getPackageName(){return packageName;}
    public String getActivityName(){return activityName;}
    public String getApkPath(){return apkPath;}
    public String getDataPath(){return dataPath;}
}
