package com.lsv.virtualspace.policy;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.virtual.VirtualStorage;

import java.io.File;

/** Resolves guest data paths into the app's private LSV storage tree. */
public class GuestDataPolicy {
    private final VirtualStorage storage;

    public GuestDataPolicy(VirtualStorage storage) {
        this.storage = storage;
    }

    public File root(VirtualApp app) {
        return storage.getAppRoot(app);
    }

    public File files(VirtualApp app) {
        return storage.getFilesDirectory(app);
    }

    public File cache(VirtualApp app) {
        return storage.getCacheDirectory(app);
    }

    public boolean isInsideGuest(VirtualApp app, File file) {
        try {
            String root = root(app).getCanonicalPath();
            String path = file.getCanonicalPath();
            return path.equals(root) || path.startsWith(root + File.separator);
        } catch (Exception e) {
            return false;
        }
    }
}
