package com.lsv.virtualspace.install;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;

import com.lsv.virtualspace.apps.VirtualApp;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

/** Compatibility launcher using Android's own package sandbox. */
public final class SystemApkLauncher {
    public static final String ACTION_INSTALL_RESULT =
        "com.lsv.virtualspace.action.INSTALL_RESULT";

    private SystemApkLauncher() { }

    public static boolean isInstalled(Context context, String packageName) {
        if (packageName == null) return false;
        try {
            context.getPackageManager().getApplicationInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
            return false;
        }
    }

    public static boolean launchInstalled(Context context, String packageName) {
        if (packageName == null) return false;
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch == null) return false;
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(launch);
        return true;
    }

    /** Starts Android's user-confirmed package installation flow. */
    public static boolean installAndLaunch(Context context, VirtualApp app) {
        if (app == null) return false;
        try {
            PackageInstaller installer = context.getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL
            );
            // Do not call setRequireUserAction here. Older Android SDKs used by
            // some AIDE installations do not expose that API. A normal PackageInstaller
            // session still uses Android's own confirmation/security flow when required.
            params.setAppPackageName(app.getPackageName());

            int sessionId = installer.createSession(params);
            PackageInstaller.Session session = installer.openSession(sessionId);
            try {
                java.util.List<String> apkPaths = app.getApkPaths();
                for (int i = 0; i < apkPaths.size(); i++) {
                    File apk = new File(apkPaths.get(i));
                    String name = i == 0 ? "base.apk" : apk.getName();
                    OutputStream out = session.openWrite(name, 0, apk.length());
                    FileInputStream in = new FileInputStream(apk);
                    try {
                        byte[] buffer = new byte[32768];
                        int count;
                        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                        out.flush();
                        session.fsync(out);
                    } finally {
                        in.close();
                        out.close();
                    }
                }

                Intent result = new Intent(ACTION_INSTALL_RESULT);
                result.setPackage(context.getPackageName());
                result.putExtra("packageName", app.getPackageName());
                PendingIntent pending = PendingIntent.getBroadcast(
                    context,
                    sessionId,
                    result,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
                session.commit(pending.getIntentSender());
            } catch (Exception e) {
                session.abandon();
                throw e;
            } finally {
                session.close();
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }
}
