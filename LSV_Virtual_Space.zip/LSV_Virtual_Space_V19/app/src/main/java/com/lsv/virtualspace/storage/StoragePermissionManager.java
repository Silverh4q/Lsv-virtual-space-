package com.lsv.virtualspace.storage;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

/** Storage permission helper. SAF remains the preferred API on modern Android. */
public final class StoragePermissionManager {
    public static final int REQUEST_STORAGE = 5201;
    private StoragePermissionManager() { }

    public static boolean needsLegacyReadPermission() {
        return Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 32;
    }

    public static boolean hasLegacyReadPermission(Activity activity) {
        if (!needsLegacyReadPermission()) return true;
        return activity.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    public static void requestLegacyReadPermission(Activity activity) {
        if (needsLegacyReadPermission() && !hasLegacyReadPermission(activity)) {
            activity.requestPermissions(new String[] { Manifest.permission.READ_EXTERNAL_STORAGE }, REQUEST_STORAGE);
        }
    }
}
