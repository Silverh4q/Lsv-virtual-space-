package com.lsv.virtualspace.framework.runtime;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

/** Tracks a guest ServiceConnection while the host proxy owns the real binding. */
public final class GuestServiceConnection implements ServiceConnection {
    private final ServiceConnection delegate;
    public GuestServiceConnection(ServiceConnection delegate) { this.delegate = delegate; }
    public void onServiceConnected(ComponentName name, IBinder service) {
        if (delegate != null) delegate.onServiceConnected(name, service);
    }
    public void onServiceDisconnected(ComponentName name) {
        if (delegate != null) delegate.onServiceDisconnected(name);
    }
}
