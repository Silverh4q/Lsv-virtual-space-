package com.lsv.virtualspace.guest.runtime;

import android.app.Activity;
import android.app.Application;

public final class GuestRuntimeResult {
    private final boolean success;
    private final String message;
    private final Application application;
    private final Activity activity;

    private GuestRuntimeResult(boolean success, String message, Application application, Activity activity) {
        this.success = success;
        this.message = message;
        this.application = application;
        this.activity = activity;
    }

    public static GuestRuntimeResult success(Application application, Activity activity) {
        return new GuestRuntimeResult(true, "Guest activity is running in the LSV guest process.", application, activity);
    }

    public static GuestRuntimeResult failure(String message) {
        return new GuestRuntimeResult(false, message, null, null);
    }

    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public Application getApplication() { return application; }
    public Activity getActivity() { return activity; }
}
