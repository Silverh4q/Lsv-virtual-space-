package com.lsv.virtualspace.diagnostics;
import java.util.*;
public final class GuestCrashReporter { private final List<GuestCrashRecord> records=new ArrayList<GuestCrashRecord>(); public void record(String p,String t,String s){records.add(new GuestCrashRecord(p,t,s));} public List<GuestCrashRecord> getRecords(){return new ArrayList<GuestCrashRecord>(records);} public void clear(){records.clear();} }
