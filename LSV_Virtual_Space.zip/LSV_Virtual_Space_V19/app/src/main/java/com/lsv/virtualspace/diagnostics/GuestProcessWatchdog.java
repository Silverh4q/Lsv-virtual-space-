package com.lsv.virtualspace.diagnostics;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.List;

/** Host-side observer for a guest process that vanishes without a Java exception. */
public final class GuestProcessWatchdog {
    public interface Listener { void onGuestProcessLost(String report); }

    private final Context context;
    private final GuestDiagnosticController diagnostics;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String processName;
    private String packageName;
    private Listener listener;
    private boolean running;
    private boolean observed;
    private long startedAt;

    private final Runnable check = new Runnable() {
        @Override public void run() {
            if (!running) return;
            boolean alive = isProcessAlive(processName) ||
                GuestProcessPresence.isFresh(context, processName, 3500L);
            if (alive) {
                observed = true;
                handler.postDelayed(this, 750L);
                return;
            }
            if (observed) {
                running = false;
                diagnostics.stage(GuestRuntimeStage.PROCESS_EXIT, "guest process disappeared: " + processName);
                String existing = diagnostics.getStore().readLatest(packageName);
                if (existing == null || existing.indexOf("Exception:") < 0 || existing.indexOf("TIMELINE") < 0) {
                    diagnostics.fail("PROCESS_DISAPPEARED", null);
                }
                if (listener != null) listener.onGuestProcessLost(diagnostics.getStore().readLatest(packageName));
                return;
            }
            if (System.currentTimeMillis() - startedAt > 18000L) {
                running = false;
                diagnostics.stage(GuestRuntimeStage.PROCESS_EXIT, "guest process never became observable: " + processName);
                String existing = diagnostics.getStore().readLatest(packageName);
                if (existing == null || existing.indexOf("LSV GUEST RUNTIME REPORT") < 0) {
                    diagnostics.fail("PROCESS_NEVER_OBSERVED", null);
                } else if (existing.indexOf("GUEST_PROCESS_HANDSHAKE_TIMEOUT") < 0 &&
                           existing.indexOf("GUEST_PROCESS_RUNTIME_INIT_FAILED") < 0 &&
                           existing.indexOf("GUEST_PROCESS_START_FAILED") < 0 &&
                           existing.indexOf("GUEST_PROCESS_BIND_FAILED") < 0) {
                    diagnostics.fail("PROCESS_NEVER_OBSERVED", null);
                }
                if (listener != null) listener.onGuestProcessLost(diagnostics.getStore().readLatest(packageName));
                return;
            }
            handler.postDelayed(this, 750L);
        }
    };

    public GuestProcessWatchdog(Context context) {
        this.context = context.getApplicationContext();
        diagnostics = GuestDiagnosticController.get(context);
    }

    public void start(String packageName, String processName, Listener listener) {
        stop();
        this.packageName = packageName;
        this.processName = processName;
        this.listener = listener;
        observed = false;
        startedAt = System.currentTimeMillis();
        running = true;
        handler.post(check);
    }

    public void stop() {
        running = false;
        handler.removeCallbacks(check);
    }

    private boolean isProcessAlive(String name) {
        if (name == null) return false;
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return false;
            List<ActivityManager.RunningAppProcessInfo> list = am.getRunningAppProcesses();
            if (list == null) return false;
            for (ActivityManager.RunningAppProcessInfo info : list) {
                if (info != null && name.equals(info.processName)) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }
}
