package com.lsv.virtualspace.framework.providers;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import com.lsv.virtualspace.framework.binder.GuestBinderCode;
import com.lsv.virtualspace.framework.binder.GuestBinderReply;
import com.lsv.virtualspace.framework.binder.GuestBinderRequest;
import com.lsv.virtualspace.framework.packages.GuestPackageRegistry;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;

/** Provider routing plus real guest ContentProvider hosting. */
public final class GuestProviderManager {
    private final GuestProviderRegistry registry;
    private final GuestProviderHost host;
    private final Context context;

    public GuestProviderManager(GuestPackageRegistry packages, Context context) {
        registry = new GuestProviderRegistry(packages);
        this.context = context.getApplicationContext();
        host = new GuestProviderHost();
    }

    public GuestBinderReply route(GuestBinderRequest request) {
        String authority = request.getComponent();
        if (authority == null || authority.length() == 0) return GuestBinderReply.fail("Missing provider authority");
        android.content.pm.ProviderInfo info = registry.resolve(request.getPackageName(), authority);
        if (info == null) return GuestBinderReply.fail("Guest provider not found: " + authority);
        try {
            GuestDiagnosticController.get(context).stage(GuestRuntimeStage.SERVICE_REQUEST, "provider " + authority);
            Bundle d = request.getData();
            Uri uri = (Uri) d.getParcelable("uri");
            if (request.getCode() == GuestBinderCode.QUERY_PROVIDER) {
                Bundle result = host.query(context, request.getPackageName(), authority, uri,
                    d.getStringArray("projection"), d.getString("selection"),
                    d.getStringArray("selectionArgs"), d.getString("sortOrder"));
                result.putString("providerClass", info.name);
                return GuestBinderReply.ok(result);
            }
            if (request.getCode() == GuestBinderCode.CALL_PROVIDER) {
                String operation = d.getString("operation");
                if ("call".equals(operation)) {
                    Bundle result = host.call(context, request.getPackageName(), authority,
                        d.getString("method"), d.getString("arg"), d.getBundle("extras"));
                    return GuestBinderReply.ok(result);
                }
                if ("getType".equals(operation)) {
                    Bundle result = new Bundle();
                    result.putString("type", host.getType(context, request.getPackageName(), authority, uri));
                    return GuestBinderReply.ok(result);
                }
                if ("insert".equals(operation)) {
                    Uri resultUri = host.insert(context, request.getPackageName(), authority,
                        uri, (ContentValues) d.getParcelable("values"));
                    Bundle result = new Bundle(); result.putParcelable("uri", resultUri);
                    return GuestBinderReply.ok(result);
                }
                if ("delete".equals(operation)) {
                    Bundle result = new Bundle(); result.putInt("count", host.delete(context,
                        request.getPackageName(), authority, uri, d.getString("selection"), d.getStringArray("selectionArgs")));
                    return GuestBinderReply.ok(result);
                }
                if ("update".equals(operation)) {
                    Bundle result = new Bundle(); result.putInt("count", host.update(context,
                        request.getPackageName(), authority, uri, (ContentValues) d.getParcelable("values"),
                        d.getString("selection"), d.getStringArray("selectionArgs")));
                    return GuestBinderReply.ok(result);
                }
            }
        } catch (Throwable error) {
            GuestDiagnosticController.get(context).fail("GUEST_PROVIDER_FAILURE", error);
            return GuestBinderReply.fail("Guest provider execution failed: " + describe(error));
        }
        Bundle b = new Bundle();
        b.putString("authority", authority);
        b.putString("virtualAuthority", registry.virtualAuthority(request.getPackageName(), authority));
        b.putString("providerClass", info.name);
        b.putString("operation", request.getCode().name());
        return GuestBinderReply.ok(b);
    }

    public void clearPackage(String packageName) { host.clearPackage(packageName); }

    private String describe(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        String message = current.getMessage();
        return message == null || message.length() == 0 ? current.getClass().getSimpleName() : message;
    }
}
