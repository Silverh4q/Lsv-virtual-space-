package com.lsv.virtualspace.framework.system.adapters;

import android.os.Bundle;
import com.lsv.virtualspace.framework.system.*;

/** Guest-scoped clipboard namespace. It never reads/writes another guest's state. */
public final class GuestClipboardAdapter implements GuestSystemServiceAdapter {
    public String getServiceName() { return GuestSystemServiceName.CLIPBOARD; }
    public boolean canHandle(String op) {
        return "set_primary".equals(op) || "get_primary".equals(op) || "clear".equals(op);
    }
    public Bundle handle(String pkg, GuestSystemServiceRequest r, GuestSystemServiceState s) {
        Bundle out = new Bundle();
        String key = "primary";
        if ("set_primary".equals(r.getOperation())) {
            String text = r.getArguments() == null ? "" : r.getArguments().getString("text", "");
            s.put(pkg, getServiceName(), key, text == null ? "" : text);
        } else if ("clear".equals(r.getOperation())) {
            s.remove(pkg, getServiceName(), key);
        }
        String value = s.get(pkg, getServiceName(), key);
        out.putBoolean("accepted", true);
        out.putBoolean("hasPrimary", value != null);
        if (value != null) out.putString("text", value);
        return out;
    }
}
