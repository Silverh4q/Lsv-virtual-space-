package com.lsv.virtualspace.diagnostics;

import android.content.Context;

/** Compact transaction helper that makes every guest launch boundary observable. */
public final class GuestRuntimeTransaction {
    private final GuestDiagnosticController controller;
    private boolean failed;

    public GuestRuntimeTransaction(Context context, String packageName, String component) {
        controller = GuestDiagnosticController.get(context);
        controller.begin(packageName, component);
    }

    public void stage(String stage, String detail) { if (!failed) controller.stage(stage, detail); }

    public void fail(String kind, Throwable error) {
        failed = true;
        controller.fail(kind, error);
    }

    public void complete(String detail) {
        if (!failed) controller.success(detail);
    }

    public GuestDiagnosticController getController() { return controller; }
}
