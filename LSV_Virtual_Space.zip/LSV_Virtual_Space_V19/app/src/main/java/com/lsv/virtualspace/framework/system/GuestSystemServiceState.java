package com.lsv.virtualspace.framework.system;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/** Guest-scoped service state with optional host-side persistence. */
public final class GuestSystemServiceState {
    private final Map<String, Map<String, String>> values = new HashMap<String, Map<String, String>>();
    private final File stateFile;

    public GuestSystemServiceState() { this(null); }

    public GuestSystemServiceState(Context context) {
        stateFile = context == null ? null : new File(
            new File(context.getApplicationContext().getFilesDir(), "virtual/system-services"),
            "state.properties");
        if (stateFile != null) {
            File parent = stateFile.getParentFile();
            if (parent != null) parent.mkdirs();
            load();
        }
    }

    public synchronized void put(String packageName, String service, String key, String value) {
        Map<String, String> serviceValues = values.get(packageName);
        if (serviceValues == null) {
            serviceValues = new HashMap<String, String>();
            values.put(packageName, serviceValues);
        }
        serviceValues.put(service + ":" + key, value);
        save();
    }

    public synchronized String get(String packageName, String service, String key) {
        Map<String, String> serviceValues = values.get(packageName);
        if (serviceValues == null) return null;
        return serviceValues.get(service + ":" + key);
    }

    public synchronized void remove(String packageName, String service, String key) {
        Map<String, String> serviceValues = values.get(packageName);
        if (serviceValues == null) return;
        serviceValues.remove(service + ":" + key);
        if (serviceValues.isEmpty()) values.remove(packageName);
        save();
    }

    public synchronized void clear(String packageName) {
        values.remove(packageName);
        save();
    }

    public synchronized Map<String, String> snapshot(String packageName) {
        Map<String, String> result = new HashMap<String, String>();
        Map<String, String> source = values.get(packageName);
        if (source != null) result.putAll(source);
        return result;
    }

    private void load() {
        if (stateFile == null || !stateFile.isFile()) return;
        FileInputStream in = null;
        try {
            Properties p = new Properties();
            in = new FileInputStream(stateFile);
            p.load(in);
            for (String key : p.stringPropertyNames()) {
                String[] parts = key.split("\\|", 3);
                if (parts.length != 3) continue;
                Map<String, String> serviceValues = values.get(parts[0]);
                if (serviceValues == null) { serviceValues = new HashMap<String, String>(); values.put(parts[0], serviceValues); }
                serviceValues.put(parts[1] + ":" + parts[2], p.getProperty(key));
            }
        } catch (Throwable ignored) {
        } finally { if (in != null) try { in.close(); } catch (Throwable ignored) { } }
    }

    private void save() {
        if (stateFile == null) return;
        FileOutputStream out = null;
        try {
            Properties p = new Properties();
            for (Map.Entry<String, Map<String, String>> packageEntry : values.entrySet()) {
                for (Map.Entry<String, String> entry : packageEntry.getValue().entrySet()) {
                    String key = packageEntry.getKey() + "|" + entry.getKey().replace(':', '|');
                    p.setProperty(key, entry.getValue() == null ? "" : entry.getValue());
                }
            }
            out = new FileOutputStream(stateFile);
            p.store(out, "LSV virtual guest service state");
        } catch (Throwable ignored) {
        } finally { if (out != null) try { out.close(); } catch (Throwable ignored) { } }
    }
}
