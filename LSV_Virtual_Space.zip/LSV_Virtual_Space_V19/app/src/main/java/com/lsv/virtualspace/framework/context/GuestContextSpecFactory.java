package com.lsv.virtualspace.framework.context;

import java.io.File;

import com.lsv.virtualspace.apps.VirtualApp;

/** Creates isolated path specifications under the LSV virtual-app data root. */
public final class GuestContextSpecFactory {
    private GuestContextSpecFactory() {}

    public static GuestContextSpec create(VirtualApp app) {
        if (app == null) return null;
        File data = new File(app.getDataPath());
        File files = new File(data, "files");
        File cache = new File(data, "cache");
        files.mkdirs();
        cache.mkdirs();
        return new GuestContextSpec(
            app.getPackageName(), data.getAbsolutePath(),
            files.getAbsolutePath(), cache.getAbsolutePath(), app.getApkPath()
        );
    }
}
