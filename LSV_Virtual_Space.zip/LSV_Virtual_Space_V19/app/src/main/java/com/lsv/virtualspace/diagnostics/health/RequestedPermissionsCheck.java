package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class RequestedPermissionsCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "REQUESTED_PERMISSIONS"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && context != null && context.getPackageManager().getPackageArchiveInfo(app.getApkPath(), android.content.pm.PackageManager.GET_PERMISSIONS) != null;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
