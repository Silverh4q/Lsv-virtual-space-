package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ApplicationInfoCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "APPLICATION_INFO"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && context != null && context.getPackageManager().getApplicationInfo(app.getPackageName(), 0) != null;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
