package com.lsv.virtualspace.engine;

import android.os.Build;

/** AIDE-safe ABI detection without requiring a native toolchain. */
public final class AbiSupport {
    private AbiSupport() { }

    public static boolean isArm64() {
        if (Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_64_BIT_ABIS != null) {
            for (String abi : Build.SUPPORTED_64_BIT_ABIS) {
                if ("arm64-v8a".equals(abi)) return true;
            }
        }
        return "aarch64".equalsIgnoreCase(Build.CPU_ABI)
            || "arm64-v8a".equalsIgnoreCase(Build.CPU_ABI);
    }

    public static boolean isArm32() {
        if (Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_32_BIT_ABIS != null) {
            for (String abi : Build.SUPPORTED_32_BIT_ABIS) {
                if ("armeabi-v7a".equals(abi)) return true;
            }
        }
        return "armeabi-v7a".equalsIgnoreCase(Build.CPU_ABI)
            || "armeabi".equalsIgnoreCase(Build.CPU_ABI);
    }

    public static String preferredAbi() {
        if (isArm64()) return "arm64-v8a";
        if (isArm32()) return "armeabi-v7a";
        if (Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_ABIS != null
                && Build.SUPPORTED_ABIS.length > 0) {
            return Build.SUPPORTED_ABIS[0];
        }
        return Build.CPU_ABI == null ? "unknown" : Build.CPU_ABI;
    }

    public static String summary() {
        return "Preferred ABI: " + preferredAbi()
            + ", 64-bit ARM: " + isArm64()
            + ", 32-bit ARM: " + isArm32();
    }
}
