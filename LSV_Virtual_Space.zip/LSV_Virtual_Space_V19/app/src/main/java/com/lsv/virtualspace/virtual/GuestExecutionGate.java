package com.lsv.virtualspace.virtual;

import com.lsv.virtualspace.diagnostics.GuestCapabilityReport;

/** Single gate preventing preparation features from being mistaken for execution. */
public final class GuestExecutionGate {
    private GuestExecutionGate() {}

    public static GuestRuntimeStatus evaluate(GuestRuntimeConfig config, GuestCapabilityReport report) {
        if (config == null || report == null) {
            return new GuestRuntimeStatus(GuestRuntimeStatus.FAILED, "Missing runtime configuration or capability report.");
        }
        if (!config.isProcessHostEnabled() || !config.isBinderRoutingEnabled() || !config.isComponentRoutingEnabled()) {
            return new GuestRuntimeStatus(GuestRuntimeStatus.BLOCKED,
                "Guest execution requires a real process, Binder and component routing backend.");
        }
        if (!report.hasMetadata() || !report.hasResources() || !report.hasDexLoader()) {
            return new GuestRuntimeStatus(GuestRuntimeStatus.BLOCKED, "Guest artifacts are not ready.");
        }
        return new GuestRuntimeStatus(GuestRuntimeStatus.READY, "Guest execution prerequisites are present.");
    }
}
