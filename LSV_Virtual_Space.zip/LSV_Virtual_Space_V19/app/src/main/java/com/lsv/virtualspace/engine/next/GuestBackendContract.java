package com.lsv.virtualspace.engine.next;

import com.lsv.virtualspace.ipc.GuestProcessBridge;

/** Contract for a future real Android virtualization backend. */
public interface GuestBackendContract {
    String getName();
    boolean isSupported();
    GuestProcessBridge getProcessBridge();
}
