package com.lsv.virtualspace.graphics;

/** Surface hand-off contract for a future real guest renderer backend. */
public final class GuestSurfaceContract {
    private int width;
    private int height;
    private int format;

    public void configure(int width, int height, int format) {
        this.width = width;
        this.height = height;
        this.format = format;
    }

    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getFormat() { return format; }
}
