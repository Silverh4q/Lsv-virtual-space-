package com.lsv.virtualspace.runtime;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.process.GuestProcessController;

/** Coordinates the dedicated LSV process boundary without executing guest code in the UI process. */
public final class GuestExecutionBoundary {
    private final GuestProcessController controller;
    public GuestExecutionBoundary(android.content.Context context) { controller = new GuestProcessController(context); }
    public GuestProcessLaunch prepare(VirtualApp app) {
        if (app == null) return null;
        boolean started = controller.prepare(app.getPackageName(), app.getApkPath());
        if (!started) return null;
        return new GuestProcessLaunch(app.getPackageName(), app.getApkPath(), true);
    }
    public void stop() { controller.stop(); }
}
