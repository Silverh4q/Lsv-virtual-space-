package com.lsv.virtualspace.services;
import java.util.*;
public final class GuestServiceRegistry { private final Map<String,GuestServiceRecord> map=new HashMap<String,GuestServiceRecord>(); public void register(GuestServiceRecord r){map.put(r.getPackageName()+":"+r.getClassName(),r);} public GuestServiceRecord get(String p,String c){return map.get(p+":"+c);} public void stopAll(String p){for(GuestServiceRecord r:map.values())if(p.equals(r.getPackageName()))r.setRunning(false);} }
