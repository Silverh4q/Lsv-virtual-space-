package com.lsv.virtualspace.providers;

public final class GuestProviderRoute {
    private final String packageName;
    private final String authority;
    private final String className;

    public GuestProviderRoute(String packageName, String authority, String className) {
        this.packageName = packageName;
        this.authority = authority;
        this.className = className;
    }

    public String getPackageName() { return packageName; }
    public String getAuthority() { return authority; }
    public String getClassName() { return className; }
}
