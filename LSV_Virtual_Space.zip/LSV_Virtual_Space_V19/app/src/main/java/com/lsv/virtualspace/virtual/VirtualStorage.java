package com.lsv.virtualspace.virtual;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;

import java.io.File;

/**
 * Provides deterministic private storage locations for virtual applications.
 */
public class VirtualStorage {
    private final Context context;

    public VirtualStorage(Context context) {
        this.context = context.getApplicationContext();
    }

    public File getRoot() {
        File root = new File(context.getFilesDir(), "virtual");
        root.mkdirs();
        return root;
    }

    public File getAppRoot(VirtualApp app) {
        File root = new File(getRoot(), "data");
        File appRoot = new File(root, sanitize(app.getPackageName()));
        appRoot.mkdirs();
        return appRoot;
    }

    public File getFilesDirectory(VirtualApp app) {
        File dir = new File(getAppRoot(app), "files");
        dir.mkdirs();
        return dir;
    }

    public File getCacheDirectory(VirtualApp app) {
        File dir = new File(getAppRoot(app), "cache");
        dir.mkdirs();
        return dir;
    }

    private String sanitize(String value) {
        return value.replaceAll("[^A-Za-z0-9_.-]", "_");
    }
}
