package com.lsv.virtualspace.diagnostics;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.virtual.VirtualCore;
import com.lsv.virtualspace.virtual.VirtualPackageManager;

/** Deterministic preflight used before a real guest launch. */
public final class GuestPreflight {
    private GuestPreflight() { }

    public static String run(Context context, VirtualApp app) {
        StringBuilder out = new StringBuilder();
        out.append("LSV GUEST PREFLIGHT\n");
        out.append("API=").append(Build.VERSION.SDK_INT).append('\n');
        if (app == null) return out.append("FAIL: null app\n").toString();
        check(out, "APK_EXISTS", app.getApkPath() != null && new java.io.File(app.getApkPath()).isFile());
        check(out, "DATA_DIR", app.getDataPath() != null && new java.io.File(app.getDataPath()).isDirectory());
        try {
            VirtualPackageManager pm = VirtualCore.get().getRuntimeController().getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(app);
            check(out, "PACKAGE_INFO", ai != null);
            if (ai != null) {
                check(out, "SOURCE_DIR", ai.sourceDir != null && new java.io.File(ai.sourceDir).isFile());
                check(out, "CLASS_NAME", ai.className == null || ai.className.length() > 0);
                out.append("TARGET_SDK=").append(ai.targetSdkVersion).append('\n');
            }
        } catch (Throwable error) {
            out.append("FAIL: PACKAGE_MANAGER ").append(error.toString()).append('\n');
        }
        return out.toString();
    }

    private static void check(StringBuilder out, String name, boolean ok) {
        out.append(ok ? "PASS: " : "FAIL: ").append(name).append('\n');
    }
}
