package com.lsv.virtualspace.virtual;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualAppRepository;
import com.lsv.virtualspace.framework.GuestFrameworkHost;
import com.lsv.virtualspace.framework.GuestTaskManager;
import com.lsv.virtualspace.framework.bootstrap.GuestRuntimePreparer;

/**
 * Central entry point for the LSV virtualization layer.
 *
 * This is intentionally small in the first milestone. The real virtual
 * Activity/Service/Package managers will be added behind this API so the UI
 * does not depend on implementation details.
 */
public final class VirtualCore {
    private static final VirtualCore INSTANCE = new VirtualCore();

    private Context context;
    private VirtualAppRepository appRepository;
    private VirtualRuntimeController runtimeController;
    private GuestFrameworkHost frameworkHost;
    private GuestTaskManager guestTaskManager;
    private GuestRuntimePreparer guestRuntimePreparer;
    private String initializationError;

    private VirtualCore() {
    }

    public static VirtualCore get() {
        return INSTANCE;
    }

    public synchronized void initialize(Context context) {
        if (this.context != null && this.frameworkHost != null) {
            initializationError = null;
            return;
        }
        if (context == null) {
            throw new IllegalArgumentException("VirtualCore context is null");
        }

        Context appContext = context.getApplicationContext();
        VirtualAppRepository newRepository = null;
        VirtualRuntimeController newRuntimeController = null;
        GuestTaskManager newTaskManager = null;
        GuestRuntimePreparer newRuntimePreparer = null;
        GuestFrameworkHost newFrameworkHost = null;

        try {
            newRepository = new VirtualAppRepository(appContext);
            newRuntimeController = new VirtualRuntimeController(appContext);
            newTaskManager = new GuestTaskManager();
            newRuntimePreparer = new GuestRuntimePreparer(appContext);
            newFrameworkHost = new GuestFrameworkHost(
                appContext,
                newRuntimeController.getActivityManager(),
                newRuntimeController.getPackageManager(),
                newRuntimeController.getStorage()
            );
        } catch (Throwable error) {
            // Never leave VirtualCore half-initialized. A partially constructed
            // framework was one of the easiest ways for LSV itself to crash at
            // startup instead of reporting the real initialization failure.
            this.context = null;
            this.appRepository = null;
            this.runtimeController = null;
            this.guestTaskManager = null;
            this.guestRuntimePreparer = null;
            this.frameworkHost = null;
            initializationError = describe(error);
            throw new IllegalStateException("LSV framework initialization failed: "
                + describe(error), error);
        }

        // Publish the complete graph only after every dependency was created.
        this.context = appContext;
        this.appRepository = newRepository;
        this.runtimeController = newRuntimeController;
        this.guestTaskManager = newTaskManager;
        this.guestRuntimePreparer = newRuntimePreparer;
        this.frameworkHost = newFrameworkHost;
        this.initializationError = null;
    }

    public synchronized boolean tryInitialize(Context context) {
        try {
            initialize(context);
            return true;
        } catch (Throwable error) {
            initializationError = describe(error);
            return false;
        }
    }

    public synchronized boolean isInitialized() {
        return context != null && frameworkHost != null && runtimeController != null;
    }

    public synchronized String getInitializationError() {
        if (isInitialized()) return null;
        return initializationError == null ? "VirtualCore is not initialized." : initializationError;
    }

    private static String describe(Throwable error) {
        Throwable current = error;
        while (current != null && current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        if (current == null) return "Unknown initialization failure";
        String message = current.getMessage();
        if (message == null || message.length() == 0) {
            return current.getClass().getSimpleName();
        }
        return current.getClass().getSimpleName() + ": " + message;
    }

    public Context getContext() {
        return context;
    }

    public VirtualRuntimeController getRuntimeController() {
        if (runtimeController == null) {
            throw new IllegalStateException("VirtualCore has not been initialized");
        }
        return runtimeController;
    }

    public GuestFrameworkHost getFrameworkHost() {
        if (frameworkHost == null) {
            throw new IllegalStateException("VirtualCore has not been initialized");
        }
        return frameworkHost;
    }

    public GuestTaskManager getGuestTaskManager() {
        if (guestTaskManager == null) {
            throw new IllegalStateException("VirtualCore has not been initialized");
        }
        return guestTaskManager;
    }

    public GuestRuntimePreparer getGuestRuntimePreparer() {
        if (guestRuntimePreparer == null) {
            throw new IllegalStateException("VirtualCore has not been initialized");
        }
        return guestRuntimePreparer;
    }

    public VirtualAppRepository getAppRepository() {
        if (appRepository == null) {
            throw new IllegalStateException("VirtualCore has not been initialized");
        }
        return appRepository;
    }
}
