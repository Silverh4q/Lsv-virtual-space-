package com.lsv.virtualspace.framework.system.adapters;
import android.os.Bundle; import com.lsv.virtualspace.framework.system.*;
public final class GuestPowerAdapter implements GuestSystemServiceAdapter {
 public String getServiceName(){return GuestSystemServiceName.POWER;}
 public boolean canHandle(String op){return "acquire_wakelock".equals(op)||"release_wakelock".equals(op)||"is_held".equals(op);}
 public Bundle handle(String pkg,GuestSystemServiceRequest r,GuestSystemServiceState s){Bundle o=new Bundle();String id=r.getArguments()==null?"default":r.getArguments().getString("id","default");String k="wakelock:"+id;if("acquire_wakelock".equals(r.getOperation()))s.put(pkg,getServiceName(),k,"held");else if("release_wakelock".equals(r.getOperation()))s.remove(pkg,getServiceName(),k);o.putBoolean("held",s.get(pkg,getServiceName(),k)!=null);o.putBoolean("accepted",true);return o;}
}
