package com.lsv.virtualspace.process;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/** Small persistent state marker shared by the host and :guest process. */
public final class GuestProcessStateStore {
    private GuestProcessStateStore() { }

    public static void write(Context context, String packageName, int state, String detail) {
        if (context == null) return;
        try {
            File dir = new File(context.getFilesDir(), "virtual/diagnostics/process");
            if (!dir.exists()) dir.mkdirs();
            Properties p = new Properties();
            p.setProperty("package", packageName == null ? "" : packageName);
            p.setProperty("state", GuestProcessState.nameOf(state));
            p.setProperty("stateCode", String.valueOf(state));
            p.setProperty("time", String.valueOf(System.currentTimeMillis()));
            p.setProperty("detail", detail == null ? "" : detail);
            File tmp = new File(dir, "guest_state.tmp");
            File target = new File(dir, "guest_state.properties");
            FileOutputStream out = new FileOutputStream(tmp);
            p.store(out, "LSV guest process state");
            out.close();
            if (target.exists()) target.delete();
            tmp.renameTo(target);
        } catch (Throwable ignored) { }
    }

    public static String readState(Context context) {
        if (context == null) return null;
        try {
            File file = new File(new File(context.getFilesDir(), "virtual/diagnostics/process"), "guest_state.properties");
            if (!file.exists()) return null;
            Properties p = new Properties();
            FileInputStream in = new FileInputStream(file);
            p.load(in);
            in.close();
            return p.getProperty("state");
        } catch (Throwable ignored) { return null; }
    }
}
