package com.lsv.virtualspace.framework.resources;

import android.content.Context;
import android.content.res.Resources;

import com.lsv.virtualspace.guest.GuestResourceLocator;

import java.util.HashMap;
import java.util.Map;

/** Caches resource views without registering them in Android's PackageManager. */
public final class GuestResourceSessionManager {
    private final Context context;
    private final Map<String, GuestResourceSession> sessions =
        new HashMap<String, GuestResourceSession>();

    public GuestResourceSessionManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public synchronized GuestResourceSession open(String packageName, String apkPath) throws Exception {
        GuestResourceSession existing = sessions.get(packageName);
        if (existing != null) return existing;
        Resources resources = GuestResourceLocator.open(context, apkPath);
        GuestResourceSession session = new GuestResourceSession(packageName, resources);
        sessions.put(packageName, session);
        return session;
    }

    public synchronized void close(String packageName) {
        sessions.remove(packageName);
    }

    public synchronized void clear() {
        sessions.clear();
    }
}
