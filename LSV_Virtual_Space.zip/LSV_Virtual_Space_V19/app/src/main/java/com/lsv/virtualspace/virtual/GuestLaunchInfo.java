package com.lsv.virtualspace.virtual;

/**
 * Immutable description of the activity that a future guest backend must
 * launch.
 */
public class GuestLaunchInfo {
    private final String packageName;
    private final String activityName;
    private final String apkPath;
    private final String dataPath;

    public GuestLaunchInfo(
        String packageName,
        String activityName,
        String apkPath,
        String dataPath
    ) {
        this.packageName = packageName;
        this.activityName = activityName;
        this.apkPath = apkPath;
        this.dataPath = dataPath;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getActivityName() {
        return activityName;
    }

    public String getApkPath() {
        return apkPath;
    }

    public String getDataPath() {
        return dataPath;
    }
}
