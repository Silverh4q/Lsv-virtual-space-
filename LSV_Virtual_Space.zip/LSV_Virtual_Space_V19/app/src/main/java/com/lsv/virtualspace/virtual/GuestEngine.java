package com.lsv.virtualspace.virtual;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;

/** Boundary for a real application virtualization engine. */
public interface GuestEngine {
    void initialize(Context context, VirtualRuntimeController controller);
    PreparedGuest prepare(VirtualApp app);
    boolean start(PreparedGuest guest);
    void stop(VirtualApp app);
    void shutdown();
}
