package com.lsv.virtualspace.virtual;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;

import com.lsv.virtualspace.apps.VirtualApp;

import java.util.List;

/**
 * Activity resolution boundary.
 *
 * The current implementation only resolves metadata. Actual execution of an
 * arbitrary APK remains a separate runtime backend because Android does not
 * allow a normal application to install another application's process inside
 * itself without virtualization infrastructure.
 */
public class VirtualActivityManager {
    private final Context context;
    private final VirtualPackageManager packageManager;

    public VirtualActivityManager(Context context, VirtualPackageManager packageManager) {
        this.context = context.getApplicationContext();
        this.packageManager = packageManager;
    }

    public String findLaunchableActivity(String packageName) {
        if (packageName == null) {
            return null;
        }
        List<VirtualApp> apps = packageManager.getInstalledApps();
        for (VirtualApp app : apps) {
            if (packageName.equals(app.getPackageName())) {
                ActivityInfo info = findLaunchActivity(app);
                return info == null ? null : info.name;
            }
        }
        return null;
    }

    public ActivityInfo findLaunchActivity(VirtualApp app) {
        PackageInfo info = packageManager.getPackageInfo(app);
        if (info == null || info.activities == null) {
            return null;
        }

        for (ActivityInfo activity : info.activities) {
            if (activity.exported && activity.name != null) {
                return activity;
            }
        }

        return null;
    }

    /**
     * Safe host-side launch for activities that actually belong to this host.
     * Virtual application execution is intentionally not faked here.
     */
    public boolean canResolve(VirtualApp app) {
        return findLaunchActivity(app) != null;
    }
}
