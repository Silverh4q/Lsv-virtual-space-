package com.lsv.virtualspace.framework.system.adapters;

import android.os.Bundle;
import com.lsv.virtualspace.framework.system.*;

public final class GuestWindowManagerAdapter implements GuestSystemServiceAdapter {
    public static final String SERVICE = GuestSystemServiceName.WINDOW;
    public String getServiceName() { return SERVICE; }
    public boolean canHandle(String op) { return "create_session".equals(op) || "close_session".equals(op) || "set_visible".equals(op) || "overlay".equals(op); }
    public Bundle handle(String pkg, GuestSystemServiceRequest req, GuestSystemServiceState state) {
        Bundle out = new Bundle(); String op = req.getOperation();
        String id = req.getArguments() == null ? null : req.getArguments().getString("session");
        if (id == null) id = "window:" + pkg;
        if ("overlay".equals(op) && !"true".equals(state.get(pkg, SERVICE, "overlayAllowed"))) { out.putBoolean("accepted", false); out.putString("reason", "overlay_not_allowed"); return out; }
        String key = "window:" + id;
        if ("create_session".equals(op)) state.put(pkg, SERVICE, key, "created");
        else if ("close_session".equals(op)) state.remove(pkg, SERVICE, key);
        else if ("set_visible".equals(op)) state.put(pkg, SERVICE, key, String.valueOf(req.getArguments().getBoolean("visible", true)));
        else if ("overlay".equals(op)) state.put(pkg, SERVICE, "overlay", "requested");
        out.putBoolean("accepted", true); out.putString("session", id); return out;
    }
}
