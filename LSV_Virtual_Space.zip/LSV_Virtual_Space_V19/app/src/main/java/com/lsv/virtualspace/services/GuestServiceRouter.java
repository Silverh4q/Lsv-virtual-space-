package com.lsv.virtualspace.services;

import java.util.HashMap;
import java.util.Map;

/** Logical service-binding router. It does not inject or start guest code in the host. */
public final class GuestServiceRouter {
    private final Map<String, GuestServiceRecord> records = new HashMap<String, GuestServiceRecord>();

    public synchronized void register(GuestServiceRecord record) {
        if (record == null) return;
        records.put(key(record.getPackageName(), record.getClassName()), record);
    }

    public synchronized GuestServiceRecord resolve(String packageName, String className) {
        return records.get(key(packageName, className));
    }

    public synchronized void stopPackage(String packageName) {
        for (GuestServiceRecord record : records.values()) {
            if (packageName.equals(record.getPackageName())) record.setRunning(false);
        }
    }

    private String key(String p, String c) { return p + ":" + c; }
}
