package com.lsv.virtualspace.framework.packages;

import android.content.pm.PackageInfo;
import android.content.pm.ApplicationInfo;

import com.lsv.virtualspace.framework.identity.GuestIdentity;

/** Immutable virtual package record kept by the framework host. */
public final class GuestPackageRecord {
    private final String packageName;
    private final PackageInfo packageInfo;
    private final ApplicationInfo applicationInfo;
    private final GuestIdentity identity;
    private final String apkPath;

    public GuestPackageRecord(String packageName, PackageInfo packageInfo,
                              ApplicationInfo applicationInfo, GuestIdentity identity, String apkPath) {
        this.packageName = packageName;
        this.packageInfo = packageInfo;
        this.applicationInfo = applicationInfo;
        this.identity = identity;
        this.apkPath = apkPath;
    }

    public String getPackageName() { return packageName; }
    public PackageInfo getPackageInfo() { return packageInfo; }
    public ApplicationInfo getApplicationInfo() { return applicationInfo; }
    public GuestIdentity getIdentity() { return identity; }
    public String getApkPath() { return apkPath; }
}
