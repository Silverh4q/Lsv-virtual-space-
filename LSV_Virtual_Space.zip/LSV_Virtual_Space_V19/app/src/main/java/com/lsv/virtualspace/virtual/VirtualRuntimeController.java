package com.lsv.virtualspace.virtual;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.apps.VirtualAppRepository;
import com.lsv.virtualspace.engine.next.Stage70Runtime;

/**
 * Coordinates package metadata, storage, guest sessions and the selected
 * execution backend.
 */
public class VirtualRuntimeController {
    private final VirtualAppRepository repository;
    private final VirtualPackageManager packageManager;
    private final VirtualActivityManager activityManager;
    private final VirtualStorage storage;
    private final VirtualProcessManager processManager;
    private final GuestSessionManager sessionManager;
    private final MetadataGuestRuntime runtime;
    private final PreparationGuestEngine guestEngine;
    private final Stage20GuestRuntime stage20;
    private final Stage70Runtime stage70;

    public VirtualRuntimeController(Context context) {
        Context appContext = context.getApplicationContext();

        repository = new VirtualAppRepository(appContext);
        packageManager = new VirtualPackageManager(
            appContext,
            repository
        );
        activityManager = new VirtualActivityManager(
            appContext,
            packageManager
        );
        storage = new VirtualStorage(appContext);
        processManager = new VirtualProcessManager();
        sessionManager = new GuestSessionManager();

        runtime = new MetadataGuestRuntime();
        runtime.initialize(appContext);
        runtime.configure(packageManager, storage);

        guestEngine = new PreparationGuestEngine();
        guestEngine.initialize(appContext, this);
        stage20 = new Stage20GuestRuntime(appContext, activityManager);
        stage70 = new Stage70Runtime(appContext);
    }

    public VirtualAppRepository getRepository() {
        return repository;
    }

    public VirtualPackageManager getPackageManager() {
        return packageManager;
    }

    public VirtualActivityManager getActivityManager() {
        return activityManager;
    }

    public VirtualStorage getStorage() {
        return storage;
    }

    public VirtualProcessManager getProcessManager() {
        return processManager;
    }

    public GuestSessionManager getSessionManager() {
        return sessionManager;
    }

    public boolean isExecutionBackendAvailable() {
        return false;
    }

    public MetadataGuestRuntime getMetadataRuntime() {
        return runtime;
    }

    public PreparationGuestEngine getGuestEngine() {
        return guestEngine;
    }

    public Stage20GuestRuntime getStage20Runtime() {
        return stage20;
    }

    public Stage70Runtime getStage70Runtime() {
        return stage70;
    }

    public PreparedGuest prepareGuest(VirtualApp app) {
        return guestEngine.prepare(app);
    }

    public GuestLaunchInfo prepare(VirtualApp app) {
        if (app == null) {
            return null;
        }

        GuestSession session = sessionManager.getOrCreate(app);
        GuestLaunchInfo info = runtime.prepare(app);

        if (info == null) {
            session.failed("No launchable activity was found.");
            return null;
        }

        session.prepared(info.getActivityName());
        return info;
    }

    public boolean start(VirtualApp app) {
        GuestLaunchInfo info = prepare(app);

        if (info == null) {
            return false;
        }

        boolean started = runtime.start(info);

        GuestSession session = sessionManager.getOrCreate(app);

        if (started) {
            session.running();
            processManager.markStarted(app);
        } else {
            session.failed(
                "No guest execution backend is available on this build."
            );
        }

        return started;
    }

    public void stop(VirtualApp app) {
        if (app == null) {
            return;
        }

        guestEngine.stop(app);
        runtime.stop(app.getPackageName());
        processManager.markStopped(app);
        sessionManager.stop(app.getPackageName());
    }
}
