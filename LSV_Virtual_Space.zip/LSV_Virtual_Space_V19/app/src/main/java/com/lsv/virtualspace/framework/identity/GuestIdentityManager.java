package com.lsv.virtualspace.framework.identity;

import java.util.HashMap;
import java.util.Map;

/** Assigns deterministic virtual UIDs without claiming them from Android's kernel. */
public final class GuestIdentityManager {
    private static final int FIRST_UID = 10000;
    private final Map<String, GuestIdentity> identities = new HashMap<String, GuestIdentity>();

    public synchronized GuestIdentity getOrCreate(String packageName) {
        if (packageName == null) return null;
        GuestIdentity existing = identities.get(packageName);
        if (existing != null) return existing;
        int uid = FIRST_UID + (Math.abs(packageName.hashCode()) % 50000);
        while (containsUid(uid)) uid++;
        GuestIdentity identity = new GuestIdentity(packageName, uid, 0);
        identities.put(packageName, identity);
        return identity;
    }

    public synchronized GuestIdentity get(String packageName) { return identities.get(packageName); }

    private boolean containsUid(int uid) {
        for (GuestIdentity item : identities.values()) {
            if (item.getVirtualUid() == uid) return true;
        }
        return false;
    }
}
