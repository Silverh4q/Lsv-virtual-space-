package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ProviderRegistryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "PROVIDER_REGISTRY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && context.getContentResolver() != null;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
