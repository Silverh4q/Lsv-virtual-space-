package com.lsv.virtualspace.framework.identity;

/** Stable virtual identity assigned by LSV to an installed guest. */
public final class GuestIdentity {
    private final String packageName;
    private final int virtualUid;
    private final int userId;

    public GuestIdentity(String packageName, int virtualUid, int userId) {
        this.packageName = packageName;
        this.virtualUid = virtualUid;
        this.userId = userId;
    }

    public String getPackageName() { return packageName; }
    public int getVirtualUid() { return virtualUid; }
    public int getUserId() { return userId; }
}
