package com.lsv.virtualspace.framework.system;

import android.os.Bundle;

/** Immutable request passed through the system-service mediation boundary. */
public final class GuestSystemServiceRequest {
    private final String packageName;
    private final int uid;
    private final String serviceName;
    private final String operation;
    private final Bundle arguments;

    public GuestSystemServiceRequest(String packageName, int uid, String serviceName,
                                     String operation, Bundle arguments) {
        this.packageName = packageName;
        this.uid = uid;
        this.serviceName = serviceName;
        this.operation = operation;
        this.arguments = arguments == null ? new Bundle() : new Bundle(arguments);
    }
    public String getPackageName() { return packageName; }
    public int getUid() { return uid; }
    public String getServiceName() { return serviceName; }
    public String getOperation() { return operation; }
    public Bundle getArguments() { return new Bundle(arguments); }
}
