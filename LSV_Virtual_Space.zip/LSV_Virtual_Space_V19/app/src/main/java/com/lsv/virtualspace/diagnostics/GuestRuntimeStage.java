package com.lsv.virtualspace.diagnostics;

/** Stable lifecycle stages used by guest diagnostics. */
public final class GuestRuntimeStage {
    public static final String IDLE = "IDLE";
    public static final String LAUNCH_REQUESTED = "LAUNCH_REQUESTED";
    public static final String PROCESS_ATTACHED = "GUEST_PROCESS_ATTACHED";
    public static final String PROCESS_HANDSHAKE = "GUEST_PROCESS_HANDSHAKE";
    public static final String RUNTIME_VERIFICATION = "RUNTIME_VERIFICATION";
    public static final String APPLICATION_STARTUP = "APPLICATION_STARTUP";
    public static final String PROXY_ACTIVITY_CREATE = "PROXY_ACTIVITY_CREATE";
    public static final String GUEST_CONTEXT = "GUEST_CONTEXT";
    public static final String GUEST_RESOURCES = "GUEST_RESOURCES";
    public static final String GUEST_APPLICATION = "GUEST_APPLICATION";
    public static final String NATIVE_RUNTIME = "NATIVE_RUNTIME";
    public static final String FULL_LIFECYCLE = "FULL_LIFECYCLE";
    public static final String CRASH_RECOVERY = "CRASH_RECOVERY";
    public static final String INSTRUMENTATION_INSTALL = "INSTALL_GUEST_INSTRUMENTATION";
    public static final String PACKAGE_LOOKUP = "RESOLVE_VIRTUAL_PACKAGE";
    public static final String PACKAGE_METADATA = "READ_PACKAGE_METADATA";
    public static final String ACTIVITY_RESOLUTION = "RESOLVE_ACTIVITY_INFO";
    public static final String NATIVE_PREPARE = "PREPARE_NATIVE_LIBRARIES";
    public static final String CLASSLOADER = "CREATE_GUEST_CLASSLOADER";
    public static final String RESOURCES = "CREATE_GUEST_RESOURCES";
    public static final String APPLICATION_CREATE = "CREATE_GUEST_APPLICATION";
    public static final String APPLICATION_ATTACH = "ATTACH_GUEST_APPLICATION";
    public static final String APPLICATION_ON_CREATE = "APPLICATION_ON_CREATE";
    public static final String FRAMEWORK_REGISTER = "REGISTER_GUEST_FRAMEWORK";
    public static final String ACTIVITY_CREATE = "CREATE_GUEST_ACTIVITY";
    public static final String ACTIVITY_PREPARE = "PREPARE_ACTIVITY_CONTEXT";
    public static final String ACTIVITY_ON_CREATE = "ACTIVITY_ON_CREATE";
    public static final String ACTIVITY_ON_START = "ACTIVITY_ON_START";
    public static final String ACTIVITY_ON_RESUME = "ACTIVITY_ON_RESUME";
    public static final String ACTIVITY_ON_PAUSE = "ACTIVITY_ON_PAUSE";
    public static final String ACTIVITY_ON_STOP = "ACTIVITY_ON_STOP";
    public static final String ACTIVITY_ON_DESTROY = "ACTIVITY_ON_DESTROY";
    public static final String WINDOW_CREATE = "CREATE_WINDOW_SESSION";
    public static final String WINDOW_ATTACH = "ATTACH_WINDOW";
    public static final String SERVICE_REQUEST = "SYSTEM_SERVICE_REQUEST";
    public static final String CLEANUP = "GUEST_CLEANUP";
    public static final String COMPLETED = "GUEST_RUNNING";
    public static final String FAILED = "GUEST_FAILED";
    public static final String PREFLIGHT = "PREFLIGHT";
    public static final String APK_VALIDATE = "VALIDATE_APK";
    public static final String MANIFEST_VALIDATE = "VALIDATE_MANIFEST";
    public static final String DEX_VALIDATE = "VALIDATE_DEX";
    public static final String ABI_VALIDATE = "VALIDATE_ABI";
    public static final String DATA_VALIDATE = "VALIDATE_DATA";
    public static final String PACKAGE_MANAGER_READY = "PACKAGE_MANAGER_READY";
    public static final String PERMISSION_READY = "PERMISSION_BOUNDARY_READY";
    public static final String IDENTITY_READY = "GUEST_IDENTITY_READY";
    public static final String SERVICE_BOUNDARY_READY = "SERVICE_BOUNDARY_READY";
    public static final String RESOURCE_VALIDATE = "VALIDATE_RESOURCES";
    public static final String NATIVE_LOAD = "LOAD_NATIVE_LIBRARY";
    public static final String APPLICATION_READY = "APPLICATION_READY";
    public static final String ACTIVITY_READY = "ACTIVITY_READY";
    public static final String WINDOW_READY = "WINDOW_READY";
    public static final String PROCESS_HEARTBEAT = "PROCESS_HEARTBEAT";
    public static final String PROCESS_EXIT = "PROCESS_EXIT";
    public static final String REPORT_PERSIST = "REPORT_PERSIST";
    public static final String CLEANUP_BEGIN = "CLEANUP_BEGIN";
    public static final String CLEANUP_COMPLETE = "CLEANUP_COMPLETE";
    public static final String TEST_BEGIN = "SELF_TEST_BEGIN";
    public static final String TEST_PASS = "SELF_TEST_PASS";
    public static final String TEST_FAIL = "SELF_TEST_FAIL";

    private GuestRuntimeStage() { }
}
