package com.lsv.virtualspace.graphics;
public enum GuestGraphicsMode { AUTO, OPENGL_ES, VULKAN, COMPATIBILITY }
