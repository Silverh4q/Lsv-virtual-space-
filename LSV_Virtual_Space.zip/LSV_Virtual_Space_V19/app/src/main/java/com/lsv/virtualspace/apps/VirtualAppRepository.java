package com.lsv.virtualspace.apps;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Stores imported APKs and their private virtual-app data.
 *
 * Importing an APK here does not install it into Android's real PackageManager.
 * It registers the APK inside LSV's private virtual-app repository.
 */
public class VirtualAppRepository {
    private final Context context;
    private final File root;
    private final File apkDir;
    private final File dataDir;

    public VirtualAppRepository(Context context) {
        this.context = context.getApplicationContext();
        root = new File(this.context.getFilesDir(), "virtual");
        apkDir = new File(root, "apks");
        dataDir = new File(root, "data");
        apkDir.mkdirs();
        dataDir.mkdirs();
    }

    public synchronized VirtualApp importApk(Uri uri) throws Exception {
        if (uri == null) {
            throw new Exception("No APK selected");
        }

        File temporary = new File(
            apkDir,
            ".import_" + System.currentTimeMillis() + ".apk"
        );

        copyUri(uri, temporary);

        PackageInfo info = readPackageInfo(temporary);
        if (info == null || info.packageName == null) {
            temporary.delete();
            throw new Exception("The selected file is not a valid readable APK");
        }

        String packageName = info.packageName;
        File finalApk = new File(apkDir, safeName(packageName) + ".apk");

        if (finalApk.exists() && !finalApk.delete()) {
            temporary.delete();
            throw new Exception("An existing copy could not be replaced");
        }

        if (!temporary.renameTo(finalApk)) {
            copyFile(temporary, finalApk);
            temporary.delete();
        }

        File appData = getDataDirectory(packageName);
        appData.mkdirs();

        ApplicationInfo ai = info.applicationInfo;
        if (ai != null) {
            ai.sourceDir = finalApk.getAbsolutePath();
            ai.publicSourceDir = finalApk.getAbsolutePath();
        }

        CharSequence labelCs = ai == null
            ? null
            : context.getPackageManager().getApplicationLabel(ai);

        String label = labelCs == null
            ? packageName
            : labelCs.toString();

        return new VirtualApp(
            packageName,
            label,
            finalApk.getAbsolutePath(),
            appData.getAbsolutePath()
        );
    }

    /** Import an APK that is already installed on the host device.
     *  This copies the host APK into LSV; it does not uninstall or modify the host app.
     */
    public synchronized VirtualApp importInstalledPackage(String packageName) throws Exception {
        if (packageName == null || packageName.length() == 0) {
            throw new Exception("No installed package selected");
        }

        PackageManager pm = context.getPackageManager();
        ApplicationInfo hostInfo;
        try {
            hostInfo = pm.getApplicationInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            throw new Exception("Installed application was not found");
        }

        if (hostInfo.sourceDir == null) {
            throw new Exception("The installed application has no readable APK path");
        }

        File source = new File(hostInfo.sourceDir);
        if (!source.exists() || !source.isFile()) {
            throw new Exception("Android did not expose the installed APK for copying");
        }

        File temporary = new File(
            apkDir,
            ".installed_" + System.currentTimeMillis() + ".apk"
        );
        copyFile(source, temporary);

        PackageInfo info = readPackageInfo(temporary);
        if (info == null || info.packageName == null) {
            temporary.delete();
            throw new Exception("The installed APK could not be parsed");
        }

        File finalApk = new File(apkDir, safeName(info.packageName) + ".apk");
        if (finalApk.exists() && !finalApk.delete()) {
            temporary.delete();
            throw new Exception("An existing LSV copy could not be replaced");
        }
        if (!temporary.renameTo(finalApk)) {
            copyFile(temporary, finalApk);
            temporary.delete();
        }

        // Preserve split APKs for modern games/apps installed as a bundle.
        File splitDir = new File(apkDir, safeName(info.packageName) + ".apk.splits");
        deleteRecursive(splitDir);
        if (hostInfo.splitSourceDirs != null && hostInfo.splitSourceDirs.length > 0) {
            splitDir.mkdirs();
            for (String splitPath : hostInfo.splitSourceDirs) {
                if (splitPath == null) continue;
                File splitSource = new File(splitPath);
                if (!splitSource.exists() || !splitSource.isFile()) continue;
                File splitTarget = new File(splitDir, splitSource.getName());
                copyFile(splitSource, splitTarget);
            }
        }

        File appData = getDataDirectory(info.packageName);
        appData.mkdirs();

        ApplicationInfo ai = info.applicationInfo;
        if (ai != null) {
            ai.sourceDir = finalApk.getAbsolutePath();
            ai.publicSourceDir = finalApk.getAbsolutePath();
        }

        CharSequence labelCs = ai == null
            ? hostInfo.loadLabel(pm)
            : pm.getApplicationLabel(ai);
        String label = labelCs == null ? info.packageName : labelCs.toString();

        return new VirtualApp(
            info.packageName,
            label,
            finalApk.getAbsolutePath(),
            appData.getAbsolutePath()
        );
    }

    public synchronized boolean isInstalled(String packageName) {
        if (packageName == null) {
            return false;
        }

        return new File(
            apkDir,
            safeName(packageName) + ".apk"
        ).exists();
    }

    public synchronized boolean uninstall(String packageName) {
        if (packageName == null) {
            return false;
        }

        boolean apkDeleted = new File(
            apkDir,
            safeName(packageName) + ".apk"
        ).delete();

        deleteRecursive(getDataDirectory(packageName));

        return apkDeleted;
    }

    public synchronized List<VirtualApp> getApps() {
        List<VirtualApp> result = new ArrayList<VirtualApp>();
        File[] files = apkDir.listFiles();

        if (files == null) {
            return result;
        }

        for (File apk : files) {
            if (!apk.isFile() || !apk.getName().endsWith(".apk")) {
                continue;
            }

            PackageInfo info = readPackageInfo(apk);
            if (info == null || info.packageName == null) {
                continue;
            }

            ApplicationInfo ai = info.applicationInfo;
            if (ai != null) {
                ai.sourceDir = apk.getAbsolutePath();
                ai.publicSourceDir = apk.getAbsolutePath();
            }

            CharSequence labelCs = ai == null
                ? null
                : context.getPackageManager().getApplicationLabel(ai);

            String label = labelCs == null
                ? info.packageName
                : labelCs.toString();

            File appData = getDataDirectory(info.packageName);

            result.add(new VirtualApp(
                info.packageName,
                label,
                apk.getAbsolutePath(),
                appData.getAbsolutePath()
            ));
        }

        return result;
    }

    private PackageInfo readPackageInfo(File apk) {
        if (apk == null || !apk.exists()) {
            return null;
        }

        PackageManager pm = context.getPackageManager();

        return pm.getPackageArchiveInfo(
            apk.getAbsolutePath(),
            PackageManager.GET_ACTIVITIES |
            PackageManager.GET_SERVICES |
            PackageManager.GET_PROVIDERS |
            PackageManager.GET_RECEIVERS |
            PackageManager.GET_PERMISSIONS
        );
    }

    public synchronized String getDataDirectoryForPackage(String packageName) {
        return getDataDirectory(packageName).getAbsolutePath();
    }

    private File getDataDirectory(String packageName) {
        return new File(dataDir, safeName(packageName));
    }

    private String safeName(String packageName) {
        return packageName.replaceAll("[^A-Za-z0-9_.-]", "_");
    }

    private void copyUri(Uri uri, File destination) throws Exception {
        InputStream in = context.getContentResolver().openInputStream(uri);

        if (in == null) {
            throw new Exception("Android could not open the selected file");
        }

        FileOutputStream out = new FileOutputStream(destination);

        try {
            byte[] buffer = new byte[16384];
            int count;

            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
            }

            out.flush();
        } finally {
            in.close();
            out.close();
        }
    }

    private void copyFile(File source, File destination) throws Exception {
        FileInputStream in = new FileInputStream(source);
        FileOutputStream out = new FileOutputStream(destination);

        try {
            byte[] buffer = new byte[16384];
            int count;

            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
            }

            out.flush();
        } finally {
            in.close();
            out.close();
        }
    }

    private void deleteRecursive(File file) {
        if (file == null || !file.exists()) {
            return;
        }

        if (file.isDirectory()) {
            File[] children = file.listFiles();

            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }

        file.delete();
    }
}
