package com.lsv.virtualspace.diagnostics;

import com.lsv.virtualspace.apps.VirtualApp;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Lists native libraries packaged inside an APK for ABI diagnostics. */
public class GuestNativeLibraryInspector {
    public List<String> listLibraries(VirtualApp app) {
        List<String> result = new ArrayList<String>();
        ZipFile zip = null;
        try {
            zip = new ZipFile(app.getApkPath());
            java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                String name = entries.nextElement().getName();
                if (name.startsWith("lib/") && name.endsWith(".so")) {
                    result.add(name);
                }
            }
        } catch (Exception ignored) {
            // Diagnostics remain non-fatal.
        } finally {
            if (zip != null) {
                try { zip.close(); } catch (Exception ignored) { }
            }
        }
        return result;
    }
}
