package com.lsv.virtualspace.input;
public final class GuestInputProfile {
    private final boolean multiTouch, gamepad, mouse; private final int maxPointers;
    public GuestInputProfile(boolean m,boolean g,boolean ms,int p){multiTouch=m;gamepad=g;mouse=ms;maxPointers=p;}
    public boolean hasMultiTouch(){return multiTouch;} public boolean hasGamepad(){return gamepad;} public boolean hasMouse(){return mouse;} public int getMaxPointers(){return maxPointers;}
}
