package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ServiceRegistryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "SERVICE_REGISTRY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && context.getSystemService(Context.WINDOW_SERVICE) != null;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
