package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ApkPathCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "APK_PATH"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && app.getApkPath() != null && new java.io.File(app.getApkPath()).isFile();
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
