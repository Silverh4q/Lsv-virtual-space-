package com.lsv.virtualspace.framework.context;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;

/**
 * Host Context boundary for guest identity/resources. It does not install the
 * guest package and deliberately does not expose a real PackageManager identity.
 */
public final class GuestContextBoundary extends ContextWrapper {
    private final GuestContextSpec spec;
    private final Resources guestResources;
    private final ClassLoader guestClassLoader;

    public GuestContextBoundary(Context base, GuestContextSpec spec,
                                Resources resources, ClassLoader classLoader) {
        super(base);
        if (spec == null) throw new IllegalArgumentException("spec == null");
        this.spec = spec;
        this.guestResources = resources;
        this.guestClassLoader = classLoader;
    }

    public GuestContextSpec getGuestSpec() { return spec; }

    @Override
    public Resources getResources() {
        return guestResources == null ? super.getResources() : guestResources;
    }

    @Override
    public ClassLoader getClassLoader() {
        return guestClassLoader == null ? super.getClassLoader() : guestClassLoader;
    }
}
