package com.lsv.virtualspace.runtime;

/** Conservative restart policy for the LSV guest host process. */
public final class GuestCrashRestartPolicy {
    private final int maxAttempts;
    private int attempts;

    public GuestCrashRestartPolicy() { this(2); }
    public GuestCrashRestartPolicy(int maxAttempts) { this.maxAttempts = Math.max(0, maxAttempts); }

    public synchronized boolean canRestart() { return attempts < maxAttempts; }
    public synchronized int recordCrash() { attempts++; return attempts; }
    public synchronized void reset() { attempts = 0; }
    public synchronized int getAttempts() { return attempts; }
}
