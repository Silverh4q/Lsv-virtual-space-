package com.lsv.virtualspace.virtual;

import android.content.Context;
import android.content.pm.ActivityInfo;

import com.lsv.virtualspace.apps.VirtualApp;

/**
 * Metadata-only backend used until a real guest execution engine is attached.
 */
public class MetadataGuestRuntime implements GuestRuntime {
    private Context context;
    private VirtualPackageManager packageManager;
    private VirtualStorage storage;

    @Override
    public void initialize(Context context) {
        this.context = context.getApplicationContext();
    }

    public void configure(
        VirtualPackageManager packageManager,
        VirtualStorage storage
    ) {
        this.packageManager = packageManager;
        this.storage = storage;
    }

    @Override
    public boolean isAvailable() {
        return false;
    }

    @Override
    public GuestLaunchInfo prepare(VirtualApp app) {
        if (app == null || packageManager == null || storage == null) {
            return null;
        }

        ActivityInfo activity = findLaunchActivity(app);

        if (activity == null) {
            return null;
        }

        storage.getAppRoot(app);
        storage.getFilesDirectory(app);
        storage.getCacheDirectory(app);

        return new GuestLaunchInfo(
            app.getPackageName(),
            activity.name,
            app.getApkPath(),
            app.getDataPath()
        );
    }

    @Override
    public boolean start(GuestLaunchInfo info) {
        return false;
    }

    @Override
    public void stop(String packageName) {
        // No guest process exists in the metadata-only backend.
    }

    private ActivityInfo findLaunchActivity(VirtualApp app) {
        java.util.List<ActivityInfo> activities =
            packageManager.getLaunchableActivities(app);

        if (activities.isEmpty()) {
            return null;
        }

        return activities.get(0);
    }
}
