package com.lsv.virtualspace.framework;

import java.util.Locale;

/** Stable guest-facing configuration snapshot without mutating host-wide configuration. */
public final class GuestConfiguration {
    private final Locale locale;
    private final int apiLevel;

    public GuestConfiguration(Locale locale, int apiLevel) {
        this.locale = locale == null ? Locale.getDefault() : locale;
        this.apiLevel = apiLevel;
    }

    public Locale getLocale() { return locale; }
    public int getApiLevel() { return apiLevel; }
}
