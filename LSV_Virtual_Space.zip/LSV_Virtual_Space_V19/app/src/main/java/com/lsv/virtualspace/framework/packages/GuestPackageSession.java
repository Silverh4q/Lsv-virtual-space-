package com.lsv.virtualspace.framework.packages;

public final class GuestPackageSession {
    private final String packageName;
    private final long createdAt;
    private boolean active;
    public GuestPackageSession(String packageName) { this.packageName = packageName; this.createdAt = System.currentTimeMillis(); }
    public String getPackageName() { return packageName; }
    public long getCreatedAt() { return createdAt; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
