package com.lsv.virtualspace.virtual;

import com.lsv.virtualspace.apps.VirtualApp;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Keeps one logical guest session per virtual application.
 */
public class GuestSessionManager {
    private final Map<String, GuestSession> sessions =
        Collections.synchronizedMap(new HashMap<String, GuestSession>());

    public GuestSession getOrCreate(VirtualApp app) {
        if (app == null) {
            return null;
        }

        GuestSession session = sessions.get(app.getPackageName());

        if (session == null) {
            session = new GuestSession(app);
            sessions.put(app.getPackageName(), session);
        }

        return session;
    }

    public GuestSession get(String packageName) {
        return sessions.get(packageName);
    }

    public void stop(String packageName) {
        GuestSession session = sessions.get(packageName);

        if (session != null) {
            session.stopped();
        }
    }

    public void remove(String packageName) {
        sessions.remove(packageName);
    }

    public void clear() {
        sessions.clear();
    }
}
