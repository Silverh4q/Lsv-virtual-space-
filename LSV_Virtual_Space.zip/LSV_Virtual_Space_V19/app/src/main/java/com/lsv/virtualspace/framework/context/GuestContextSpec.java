package com.lsv.virtualspace.framework.context;

/** Paths and identity used when constructing a future guest Context boundary. */
public final class GuestContextSpec {
    private final String packageName;
    private final String dataPath;
    private final String filesPath;
    private final String cachePath;
    private final String apkPath;

    public GuestContextSpec(String packageName, String dataPath, String filesPath,
                            String cachePath, String apkPath) {
        this.packageName = packageName;
        this.dataPath = dataPath;
        this.filesPath = filesPath;
        this.cachePath = cachePath;
        this.apkPath = apkPath;
    }

    public String getPackageName() { return packageName; }
    public String getDataPath() { return dataPath; }
    public String getFilesPath() { return filesPath; }
    public String getCachePath() { return cachePath; }
    public String getApkPath() { return apkPath; }
}
