package com.lsv.virtualspace.components;
import java.util.*;
public final class GuestComponentRegistry {
    private final Map<String,List<GuestComponentRecord>> byPackage=new HashMap<String,List<GuestComponentRecord>>();
    public void put(String pkg,List<GuestComponentRecord> list){byPackage.put(pkg,list==null?new ArrayList<GuestComponentRecord>():list);}
    public List<GuestComponentRecord> get(String pkg){List<GuestComponentRecord> v=byPackage.get(pkg);return v==null?new ArrayList<GuestComponentRecord>():new ArrayList<GuestComponentRecord>(v);}
    public void clear(){byPackage.clear();}
}
