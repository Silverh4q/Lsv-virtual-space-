package com.lsv.virtualspace.policy;

import android.content.pm.PackageInfo;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.virtual.VirtualPackageManager;

import java.util.HashSet;
import java.util.Set;

/**
 * Records requested guest permissions. It does not grant host permissions and
 * never modifies Android's real permission state.
 */
public class GuestPermissionPolicy {
    private final VirtualPackageManager packages;
    private final Set<String> allowed = new HashSet<String>();

    public GuestPermissionPolicy(VirtualPackageManager packages) {
        this.packages = packages;
    }

    public String[] getRequestedPermissions(VirtualApp app) {
        PackageInfo info = packages.getPackageInfo(app);
        if (info == null || info.requestedPermissions == null) {
            return new String[0];
        }
        return info.requestedPermissions;
    }

    public void allow(String packageName, String permission) {
        allowed.add(packageName + "|" + permission);
    }

    public void deny(String packageName, String permission) {
        allowed.remove(packageName + "|" + permission);
    }

    public boolean isAllowed(String packageName, String permission) {
        return allowed.contains(packageName + "|" + permission);
    }
}
