package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ActivityManagerCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "ACTIVITY_MANAGER"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && context.getSystemService(Context.ACTIVITY_SERVICE) != null;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
