package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class DiagnosticsDirectoryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "DIAGNOSTICS_DIRECTORY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && ensureDirectory(new java.io.File(context.getFilesDir(), "virtual/diagnostics"));
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }

    private static boolean ensureDirectory(java.io.File file) {
        if (file == null) return false;
        return file.isDirectory() || file.mkdirs();
    }
}
