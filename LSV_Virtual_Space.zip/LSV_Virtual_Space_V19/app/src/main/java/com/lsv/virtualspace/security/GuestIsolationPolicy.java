package com.lsv.virtualspace.security;

public final class GuestIsolationPolicy {
    private final boolean privateStorage=true;
    private final boolean hostPackageInstall=false;
    private final boolean nativeInjection=false;
    private final boolean memoryModification=false;
    private final boolean integrityBypass=false;
    public boolean usesPrivateStorage(){return privateStorage;}
    public boolean allowsHostPackageInstall(){return hostPackageInstall;}
    public boolean allowsNativeInjection(){return nativeInjection;}
    public boolean allowsMemoryModification(){return memoryModification;}
    public boolean allowsIntegrityBypass(){return integrityBypass;}
}
