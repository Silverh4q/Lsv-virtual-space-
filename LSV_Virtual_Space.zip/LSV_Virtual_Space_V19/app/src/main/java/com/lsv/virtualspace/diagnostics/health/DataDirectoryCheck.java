package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class DataDirectoryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "DATA_DIRECTORY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && app.getDataPath() != null && new java.io.File(app.getDataPath()).isDirectory();
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
