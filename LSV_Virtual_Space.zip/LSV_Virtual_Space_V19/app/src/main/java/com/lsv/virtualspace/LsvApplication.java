package com.lsv.virtualspace;

import android.app.Application;
import android.content.Context;

import com.lsv.virtualspace.virtual.VirtualAppEngine;
import com.lsv.virtualspace.virtual.VirtualCore;
import com.lsv.virtualspace.diagnostics.GuestUncaughtExceptionHandler;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;

/** Main LSV application entry point. */
public class LsvApplication extends Application {
    private static LsvApplication instance;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        instance = this;
        // Instrumentation must only be installed in the dedicated guest process.
        // Installing it in the host process can replace Android's Instrumentation during normal LSV startup and crash the host app.
        String processName = getProcessNameCompat();
        if ((getPackageName() + ":guest").equals(processName)) {
            // ABSOLUTE MINIMUM guest-process bootstrap. Do not touch the
            // diagnostics singleton, VirtualCore, instrumentation, native
            // bridge, or any framework facade from attachBaseContext().
            // Android must finish creating the :guest process and Service
            // before LSV performs any heavy virtualization work.
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        boolean guestProcess = (getPackageName() + ":guest").equals(getProcessNameCompat());
        if (!guestProcess) {
            // Host startup must never depend on the entire virtualization graph.
            // MainActivity performs the guarded initialization and can present a
            // diagnostic screen if a framework dependency fails.
            try {
                VirtualCore.get().tryInitialize(this);
            } catch (Throwable ignored) {
            }
        } else {
            // The only guest-process operation allowed here is a tiny probe.
            // It uses SharedPreferences and has no dependency on the virtual
            // framework, Binder facades, native code, or instrumentation.
            com.lsv.virtualspace.process.GuestProcessProbe.mark(
                this, "APPLICATION_ON_CREATE", null, null);
        }
    }

    private String getProcessNameCompat() {
        String value = com.lsv.virtualspace.diagnostics.GuestApiCompatibility.processName();
        if (value == null || value.length() == 0 || value.startsWith("pid-")) {
            return getPackageName();
        }
        return value;
    }

    public static LsvApplication getInstance() {
        return instance;
    }
}
