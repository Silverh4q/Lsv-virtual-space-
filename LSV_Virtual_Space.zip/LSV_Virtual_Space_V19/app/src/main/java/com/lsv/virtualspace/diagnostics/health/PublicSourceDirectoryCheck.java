package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class PublicSourceDirectoryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "PUBLIC_SOURCE_DIRECTORY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && app.getApkPath() != null && new java.io.File(app.getApkPath()).canRead();
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
