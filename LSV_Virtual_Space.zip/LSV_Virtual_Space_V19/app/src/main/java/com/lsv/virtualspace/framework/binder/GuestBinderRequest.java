package com.lsv.virtualspace.framework.binder;

import android.os.Bundle;

public final class GuestBinderRequest {
    private final String packageName;
    private final GuestBinderCode code;
    private final String component;
    private final Bundle data;

    public GuestBinderRequest(String packageName, GuestBinderCode code, String component, Bundle data) {
        this.packageName = packageName;
        this.code = code;
        this.component = component;
        this.data = data == null ? new Bundle() : new Bundle(data);
    }
    public String getPackageName() { return packageName; }
    public GuestBinderCode getCode() { return code; }
    public String getComponent() { return component; }
    public Bundle getData() { return new Bundle(data); }
}
