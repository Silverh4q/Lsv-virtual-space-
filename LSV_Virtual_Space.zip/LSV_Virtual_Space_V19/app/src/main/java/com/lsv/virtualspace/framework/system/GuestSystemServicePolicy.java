package com.lsv.virtualspace.framework.system;

import android.Manifest;
import android.content.pm.PackageManager;

import com.lsv.virtualspace.framework.permissions.GuestPermissionManager;

/** Central policy gate for guest system-service operations. */
public final class GuestSystemServicePolicy {
    private final GuestPermissionManager permissions;

    public GuestSystemServicePolicy(GuestPermissionManager permissions) {
        this.permissions = permissions;
    }

    /** Service lookup itself remains available so framework clients can cast to Android types. */
    public boolean canAcquireService(String packageName, String serviceName) {
        return packageName != null && serviceName != null;
    }

    public boolean canUse(String packageName, String serviceName, String operation) {
        if (!canAcquireService(packageName, serviceName)) return false;
        String op = operation == null ? "" : operation;
        if (GuestSystemServiceName.WINDOW.equals(serviceName) && "overlay".equals(op)) {
            return permissions.isOverlayAllowed(packageName);
        }
        if (GuestSystemServiceName.LOCATION.equals(serviceName) && "location".equals(op)) {
            return hasLocation(packageName);
        }
        if (GuestSystemServiceName.ACCOUNT.equals(serviceName) && "accounts".equals(op)) {
            return permissions.check(packageName, Manifest.permission.GET_ACCOUNTS)
                == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    public boolean hasLocation(String packageName) {
        return permissions.check(packageName, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
            || permissions.check(packageName, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    public boolean canDrawOverlays(String packageName) {
        return permissions.isOverlayAllowed(packageName);
    }
}
