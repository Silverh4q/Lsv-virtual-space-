package com.lsv.virtualspace.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Binder;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/** LSV-owned overlay host for the virtual environment. */
public final class LsvOverlayService extends Service {
    private final LocalBinder binder = new LocalBinder();
    private WindowManager windowManager;
    private TextView statusView;

    public final class LocalBinder extends Binder {
        public boolean canDrawOverlays() { return Settings.canDrawOverlays(LsvOverlayService.this); }
        public void showStatus(String text) { LsvOverlayService.this.showStatus(text); }
        public void hideStatus() { LsvOverlayService.this.hideStatus(); }
    }

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getBooleanExtra("lsv_overlay_status", false)) {
            showStatus(intent.getStringExtra("lsv_overlay_text"));
        }
        return START_STICKY;
    }

    private void showStatus(String value) {
        if (!Settings.canDrawOverlays(this) || windowManager == null) return;
        if (statusView == null) {
            statusView = new TextView(this);
            statusView.setTextColor(0xffffffff);
            statusView.setTextSize(13f);
            statusView.setPadding(24, 14, 24, 14);
            statusView.setBackgroundResource(android.R.drawable.toast_frame);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = 80;
            try { windowManager.addView(statusView, lp); }
            catch (Throwable ignored) { statusView = null; return; }
        }
        statusView.setText(value == null ? "LSV overlay" : value);
    }

    private void hideStatus() {
        if (statusView != null && windowManager != null) {
            try { windowManager.removeView(statusView); } catch (Throwable ignored) { }
            statusView = null;
        }
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public void onDestroy() {
        hideStatus();
        super.onDestroy();
    }
}
