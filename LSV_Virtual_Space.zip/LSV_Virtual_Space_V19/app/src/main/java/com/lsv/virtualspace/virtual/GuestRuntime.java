package com.lsv.virtualspace.virtual;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;

/**
 * Backend interface for actual guest execution.
 *
 * A compliant implementation must provide a real execution mechanism. The
 * default backend deliberately refuses to claim that arbitrary APKs are
 * running when Android has not created an appropriate guest process.
 */
public interface GuestRuntime {
    void initialize(Context context);

    boolean isAvailable();

    GuestLaunchInfo prepare(VirtualApp app);

    boolean start(GuestLaunchInfo info);

    void stop(String packageName);
}
