package com.lsv.virtualspace.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

/** Opens Android's real "Display over other apps" page for LSV. */
public final class OverlayPermissionHelper {
    private OverlayPermissionHelper() { }

    public static boolean isGranted(Activity activity) {
        if (Build.VERSION.SDK_INT < 23) return true;
        return Settings.canDrawOverlays(activity);
    }

    public static void openSettings(Activity activity) {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        } catch (Throwable ignored) {
            try {
                activity.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            } catch (Throwable ignoredAgain) { }
        }
    }
}
