package com.lsv.virtualspace.framework.packages;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.framework.identity.GuestIdentityManager;
import com.lsv.virtualspace.virtual.VirtualPackageManager;
import com.lsv.virtualspace.framework.intent.GuestIntentResolver;

import android.content.pm.PackageInfo;
import android.content.pm.ApplicationInfo;

import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

/** Virtual package database for the framework boundary. */
public final class GuestPackageRegistry {
    private final VirtualPackageManager packages;
    private final GuestIdentityManager identities;
    private final Map<String, GuestPackageRecord> records = new HashMap<String, GuestPackageRecord>();
    private final GuestIntentResolver intentResolver = new GuestIntentResolver();
    private final Map<String, Map<String, Boolean>> componentEnabled = new HashMap<String, Map<String, Boolean>>();

    public GuestPackageRegistry(VirtualPackageManager packages, GuestIdentityManager identities) {
        this.packages = packages;
        this.identities = identities;
    }

    public synchronized GuestPackageRecord register(VirtualApp app) {
        if (app == null || app.getPackageName() == null) return null;
        PackageInfo info = packages.getPackageInfo(app);
        ApplicationInfo ai = packages.getApplicationInfo(app);
        if (info == null || ai == null) return null;
        GuestPackageRecord record = new GuestPackageRecord(
            app.getPackageName(), info, ai, identities.getOrCreate(app.getPackageName()), app.getApkPath());
        records.put(app.getPackageName(), record);
        intentResolver.register(app.getPackageName(), app.getApkPath());
        return record;
    }

    public synchronized GuestPackageRecord get(String packageName) { return records.get(packageName); }

    public synchronized GuestPackageRecord ensure(String packageName) {
        GuestPackageRecord existing = records.get(packageName);
        if (existing != null) return existing;
        for (VirtualApp app : packages.getInstalledApps()) {
            if (packageName.equals(app.getPackageName())) return register(app);
        }
        return null;
    }

    public synchronized GuestIntentResolver getIntentResolver() { return intentResolver; }

    public synchronized java.util.List<GuestPackageRecord> snapshot() {
        return new java.util.ArrayList<GuestPackageRecord>(records.values());
    }

    public synchronized boolean isComponentEnabled(String packageName, String component) {
        GuestPackageRecord r = ensure(packageName);
        if (r == null || component == null) return false;
        Map<String, Boolean> map = componentEnabled.get(packageName);
        if (map != null && map.containsKey(component)) return map.get(component).booleanValue();
        android.content.pm.ApplicationInfo ai = r.getApplicationInfo();
        if (ai != null && !ai.enabled) return false;
        android.content.pm.PackageInfo pi = r.getPackageInfo();
        if (pi != null) {
            if (pi.activities != null) for (android.content.pm.ActivityInfo x : pi.activities) if (x != null && component.equals(x.name)) return x.enabled;
            if (pi.receivers != null) for (android.content.pm.ActivityInfo x : pi.receivers) if (x != null && component.equals(x.name)) return x.enabled;
            if (pi.services != null) for (android.content.pm.ServiceInfo x : pi.services) if (x != null && component.equals(x.name)) return x.enabled;
            if (pi.providers != null) for (android.content.pm.ProviderInfo x : pi.providers) if (x != null && component.equals(x.name)) return x.enabled;
        }
        return false;
    }

    public synchronized void setComponentEnabled(String packageName, String component, boolean enabled) {
        if (packageName == null || component == null) return;
        Map<String, Boolean> map = componentEnabled.get(packageName);
        if (map == null) { map = new HashMap<String, Boolean>(); componentEnabled.put(packageName, map); }
        map.put(component, Boolean.valueOf(enabled));
    }

    public synchronized void remove(String packageName) {
        records.remove(packageName);
        componentEnabled.remove(packageName);
        intentResolver.remove(packageName);
    }
}
