package com.lsv.virtualspace.guest.runtime;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.PersistableBundle;

import com.lsv.virtualspace.framework.GuestActivityContract;
import com.lsv.virtualspace.hidden.HiddenApiBootstrap;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Client-side instrumentation bridge.
 *
 * Android still performs Activity.attach itself. LSV only substitutes the
 * class that ActivityThread asks Instrumentation to construct, then binds the
 * guest Context/Application/resource state before Instrumentation dispatches
 * onCreate. Android still owns the window/token lifecycle.
 */
public final class GuestInstrumentation extends Instrumentation {
    private static boolean installed;
    private static String lastInstallError;
    private final Instrumentation base;
    private final Class<?> proxyClass;

    private GuestInstrumentation(Instrumentation base) {
        this.base = base;
        try {
            proxyClass = Class.forName("com.lsv.virtualspace.proxy.GuestActivityProxy");
        } catch (Throwable error) {
            throw new IllegalStateException(error);
        }
    }

    public static boolean install(android.content.Context context) {
        lastInstallError = null;
        try {
            HiddenApiBootstrap.initialize(context);
            Class<?> threadClass = Class.forName("android.app.ActivityThread");
            Method current = threadClass.getDeclaredMethod("currentActivityThread");
            current.setAccessible(true);
            Object thread = current.invoke(null);
            if (thread == null) { lastInstallError = "ActivityThread.currentActivityThread() returned null"; return false; }
            Field field = threadClass.getDeclaredField("mInstrumentation");
            field.setAccessible(true);
            Object currentInstrumentation = field.get(thread);
            if (currentInstrumentation instanceof GuestInstrumentation) {
                installed = true;
                return true;
            }
            if (!(currentInstrumentation instanceof Instrumentation)) { lastInstallError = "Android returned no usable Instrumentation"; return false; }
            field.set(thread, new GuestInstrumentation((Instrumentation) currentInstrumentation));
            installed = true;
            return true;
        } catch (Throwable error) {
            lastInstallError = formatError(error);
            return false;
        }
    }

    public static boolean isInstalled() { return installed; }

    public static String getLastInstallError() {
        return lastInstallError == null ? "unknown instrumentation installation failure" : lastInstallError;
    }

    private static String formatError(Throwable error) {
        if (error == null) return "unknown";
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        String message = current.getMessage();
        return current.getClass().getName() +
            (message == null || message.length() == 0 ? "" : ": " + message);
    }

    private boolean isProxy(String className) {
        return proxyClass.getName().equals(className);
    }

    private GuestExecutionSession prepare(Intent proxyIntent) throws Exception {
        String packageName = proxyIntent.getStringExtra(GuestActivityContract.EXTRA_PACKAGE);
        String component = proxyIntent.getStringExtra(GuestActivityContract.EXTRA_COMPONENT);
        if (packageName == null || component == null) {
            throw new IllegalStateException("Guest proxy intent is missing package/component");
        }
        return GuestExecutionSession.prepare(
            com.lsv.virtualspace.LsvApplication.getInstance(),
            packageName,
            component,
            proxyIntent
        );
    }

    @Override
    public Activity newActivity(ClassLoader cl, String className, Intent intent)
            throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        if (!isProxy(className) || intent == null ||
            !intent.hasExtra(GuestActivityContract.EXTRA_PACKAGE)) {
            return base.newActivity(cl, className, intent);
        }
        try {
            GuestExecutionSession session = prepare(intent);
            GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance()).stage(GuestRuntimeStage.ACTIVITY_CREATE, session.getComponent());
            Class<?> guestType = session.getClassLoader().loadClass(session.getComponent());
            Activity activity = (Activity) guestType.newInstance();
            GuestExecutionSession.bindPending(activity, session);
            return activity;
        } catch (Throwable error) {
            InstantiationException failure = new InstantiationException(
                "LSV guest Activity creation failed: " + formatError(error));
            failure.initCause(error);
            throw failure;
        }
    }

    @Override
    public Activity newActivity(Class<?> clazz, android.content.Context context, android.os.IBinder token,
                                android.app.Application application, Intent intent, ActivityInfo info,
                                CharSequence title, Activity parent, String id,
                                Object lastNonConfigurationInstance)
            throws InstantiationException, IllegalAccessException {
        if (intent != null && intent.hasExtra(GuestActivityContract.EXTRA_PACKAGE)) {
            try {
                GuestExecutionSession session = prepare(intent);
                // Keep the ActivityInfo coherent for framework callbacks. The definitive
                // guest Context binding is performed immediately before onCreate by the
                // GuestActivityContextBridge.
                if (info != null) {
                    info.applicationInfo = session.getApplicationInfo();
                    info.packageName = session.getApplicationInfo().packageName;
                    info.name = session.getComponent();
                }
                Class<?> guestType = session.getClassLoader().loadClass(session.getComponent());
                Activity activity = (Activity) guestType.newInstance();
                GuestExecutionSession.bindPending(activity, session);
                return activity;
            } catch (Throwable error) {
                InstantiationException failure = new InstantiationException(
                    "LSV guest Activity creation failed: " + formatError(error));
                failure.initCause(error);
                throw failure;
            }
        }
        return base.newActivity(clazz, context, token, application, intent, info, title,
            parent, id, lastNonConfigurationInstance);
    }

    @Override
    public void callActivityOnCreate(Activity activity, Bundle state) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session == null) {
            base.callActivityOnCreate(activity, state);
            return;
        }
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        GuestDiagnosticController diagnostics = GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance());
        try {
            diagnostics.stage(GuestRuntimeStage.ACTIVITY_ON_CREATE, activity.getClass().getName());
            session.prepareActivity(activity);
            Thread.currentThread().setContextClassLoader(session.getClassLoader());
            base.callActivityOnCreate(activity, state);
            diagnostics.stage(GuestRuntimeStage.COMPLETED, "Activity.onCreate returned");
        } catch (Throwable error) {
            diagnostics.stage(GuestRuntimeStage.CRASH_RECOVERY, "capturing guest Activity failure");
            diagnostics.fail("GUEST_ACTIVITY_EXCEPTION", error);
            throw new RuntimeException("LSV guest Activity bootstrap failed: " + formatError(error), error);
        } finally {
            Thread.currentThread().setContextClassLoader(previous);
        }
    }

    @Override
    public void callActivityOnRestart(Activity activity) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) {
            GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance())
                .stage(GuestRuntimeStage.FULL_LIFECYCLE, "Activity.onRestart " + activity.getClass().getName());
        }
        base.callActivityOnRestart(activity);
    }

    @Override
    public void callActivityOnNewIntent(Activity activity, Intent intent) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) {
            GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance())
                .stage(GuestRuntimeStage.FULL_LIFECYCLE, "Activity.onNewIntent " + activity.getClass().getName());
        }
        base.callActivityOnNewIntent(activity, intent);
    }

    @Override
    public void callActivityOnSaveInstanceState(Activity activity, Bundle outState) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) {
            GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance())
                .stage(GuestRuntimeStage.FULL_LIFECYCLE, "Activity.onSaveInstanceState " + activity.getClass().getName());
        }
        base.callActivityOnSaveInstanceState(activity, outState);
    }

    @Override
    public void callActivityOnUserLeaving(Activity activity) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) {
            GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance())
                .stage(GuestRuntimeStage.FULL_LIFECYCLE, "Activity.onUserLeaving " + activity.getClass().getName());
        }
        base.callActivityOnUserLeaving(activity);
    }

    @Override
    public void callActivityOnCreate(Activity activity, Bundle state, PersistableBundle persistentState) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session == null) {
            base.callActivityOnCreate(activity, state, persistentState);
            return;
        }
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        GuestDiagnosticController diagnostics = GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance());
        try {
            diagnostics.stage(GuestRuntimeStage.ACTIVITY_ON_CREATE, activity.getClass().getName());
            session.prepareActivity(activity);
            Thread.currentThread().setContextClassLoader(session.getClassLoader());
            base.callActivityOnCreate(activity, state, persistentState);
            diagnostics.stage(GuestRuntimeStage.COMPLETED, "Activity.onCreate returned");
        } catch (Throwable error) {
            diagnostics.stage(GuestRuntimeStage.CRASH_RECOVERY, "capturing guest Activity failure");
            diagnostics.fail("GUEST_ACTIVITY_EXCEPTION", error);
            throw new RuntimeException("LSV guest Activity bootstrap failed: " + formatError(error), error);
        } finally {
            Thread.currentThread().setContextClassLoader(previous);
        }
    }

    @Override public void callActivityOnStart(Activity activity) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance()).stage(GuestRuntimeStage.ACTIVITY_ON_START, activity.getClass().getName());
        base.callActivityOnStart(activity);
    }
    @Override public void callActivityOnResume(Activity activity) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) {
            GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance()).stage(GuestRuntimeStage.ACTIVITY_ON_RESUME, activity.getClass().getName());
            GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance()).stage(GuestRuntimeStage.FULL_LIFECYCLE, "guest Activity resumed");
        }
        base.callActivityOnResume(activity);
    }
    @Override public void callActivityOnPause(Activity activity) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance()).stage(GuestRuntimeStage.ACTIVITY_ON_PAUSE, activity.getClass().getName());
        base.callActivityOnPause(activity);
    }
    @Override public void callActivityOnStop(Activity activity) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance()).stage(GuestRuntimeStage.ACTIVITY_ON_STOP, activity.getClass().getName());
        base.callActivityOnStop(activity);
    }

    @Override
    public void callActivityOnDestroy(Activity activity) {
        GuestExecutionSession session = GuestExecutionSession.get(activity);
        if (session != null) {
            GuestDiagnosticController.get(com.lsv.virtualspace.LsvApplication.getInstance()).stage(GuestRuntimeStage.ACTIVITY_ON_DESTROY, activity.getClass().getName());
            session.destroy(activity);
        }
        base.callActivityOnDestroy(activity);
    }

}
