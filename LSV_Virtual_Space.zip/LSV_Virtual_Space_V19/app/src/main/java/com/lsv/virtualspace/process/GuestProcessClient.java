package com.lsv.virtualspace.process;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Messenger;
import android.os.RemoteException;

import com.lsv.virtualspace.ipc.GuestIpcMessage;

/** Client for the dedicated :guest host process. */
public final class GuestProcessClient {
    private final Context context;
    private Messenger remote;
    private boolean bound;

    public GuestProcessClient(Context context) {
        this.context = context.getApplicationContext();
    }

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            remote = new Messenger(service);
            bound = true;
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            remote = null;
            bound = false;
        }
    };

    public boolean bind() {
        Intent intent = new Intent(context, GuestProcessService.class);
        return context.bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    public boolean prepare(String packageName, String component) {
        return send(GuestIpcMessage.create(GuestIpcMessage.PREPARE, packageName, component));
    }

    public boolean start(String packageName, String component) {
        return send(GuestIpcMessage.create(GuestIpcMessage.START, packageName, component));
    }

    public boolean stop(String packageName, String component) {
        return send(GuestIpcMessage.create(GuestIpcMessage.STOP, packageName, component));
    }

    private boolean send(android.os.Message message) {
        if (!bound || remote == null) return false;
        try {
            remote.send(message);
            return true;
        } catch (RemoteException ignored) {
            return false;
        }
    }

    public void unbind() {
        if (bound) {
            context.unbindService(connection);
            bound = false;
            remote = null;
        }
    }
}
