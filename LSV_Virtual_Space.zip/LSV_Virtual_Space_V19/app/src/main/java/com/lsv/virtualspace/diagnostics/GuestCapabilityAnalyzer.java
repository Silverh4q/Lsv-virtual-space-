package com.lsv.virtualspace.diagnostics;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.guest.GuestClassLoaderFactory;
import com.lsv.virtualspace.guest.GuestResourceLocator;

import java.io.File;

/** Performs non-invasive capability checks for an imported APK. */
public final class GuestCapabilityAnalyzer {
    private final Context context;

    public GuestCapabilityAnalyzer(Context context) {
        this.context = context.getApplicationContext();
    }

    public GuestCapabilityReport analyze(VirtualApp app) {
        if (app == null) return new GuestCapabilityReport(false, false, false, false, false, "No guest");
        boolean metadata = app.getPackageName() != null && app.getApkPath() != null;
        boolean resources = false; boolean dex = false;
        try {
            GuestResourceLocator.open(context, app.getApkPath()); resources = true;
        } catch (Throwable ignored) {}
        try {
            File data = new File(app.getDataPath());
            if (data != null) {
                GuestClassLoaderFactory.create(context, app.getApkPath(), data); dex = true;
            }
        } catch (Throwable ignored) {}
        boolean nativeCompatible = new GuestNativeLibraryInspector().listLibraries(app) != null;
        return new GuestCapabilityReport(metadata, resources, dex, nativeCompatible, false,
            "Process/Binder virtualization backend is not enabled by this build.");
    }
}
