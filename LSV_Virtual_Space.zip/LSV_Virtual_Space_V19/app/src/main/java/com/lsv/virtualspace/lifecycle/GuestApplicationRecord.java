package com.lsv.virtualspace.lifecycle;

public final class GuestApplicationRecord {
    public static final int NEW = 0;
    public static final int CREATED = 1;
    public static final int STOPPED = 2;
    public static final int FAILED = 3;

    private final String packageName;
    private int state;
    private String error;

    public GuestApplicationRecord(String packageName) {
        this.packageName = packageName;
        this.state = NEW;
    }

    public void created() { state = CREATED; error = null; }
    public void stopped() { state = STOPPED; }
    public void failed(String value) { state = FAILED; error = value; }
    public String getPackageName() { return packageName; }
    public int getState() { return state; }
    public String getError() { return error; }
}
