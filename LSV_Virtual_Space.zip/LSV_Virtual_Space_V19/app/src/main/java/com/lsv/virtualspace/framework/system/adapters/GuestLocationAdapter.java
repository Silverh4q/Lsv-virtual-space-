package com.lsv.virtualspace.framework.system.adapters;
import android.os.Bundle; import com.lsv.virtualspace.framework.system.*;
public final class GuestLocationAdapter implements GuestSystemServiceAdapter {
 public String getServiceName(){return GuestSystemServiceName.LOCATION;}
 public boolean canHandle(String op){return "request_updates".equals(op)||"remove_updates".equals(op)||"get_last".equals(op);}
 public Bundle handle(String pkg,GuestSystemServiceRequest r,GuestSystemServiceState s){Bundle o=new Bundle();if("request_updates".equals(r.getOperation()))s.put(pkg,getServiceName(),"updates","enabled");else if("remove_updates".equals(r.getOperation()))s.remove(pkg,getServiceName(),"updates");o.putBoolean("accepted",true);o.putBoolean("updates",s.get(pkg,getServiceName(),"updates")!=null);return o;}
}
