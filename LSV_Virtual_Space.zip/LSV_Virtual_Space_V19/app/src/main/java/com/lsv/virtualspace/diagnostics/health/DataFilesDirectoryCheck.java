package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class DataFilesDirectoryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "DATA_FILES_DIRECTORY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && context.getFilesDir() != null && context.getFilesDir().isDirectory();
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
