package com.lsv.virtualspace.virtual;

/** Immutable runtime feature flags. No arbitrary guest execution is enabled by default. */
public final class GuestRuntimeConfig {
    private final boolean processHostEnabled;
    private final boolean binderRoutingEnabled;
    private final boolean componentRoutingEnabled;
    private final boolean nativeLoadingEnabled;

    public GuestRuntimeConfig(boolean processHostEnabled, boolean binderRoutingEnabled,
                              boolean componentRoutingEnabled, boolean nativeLoadingEnabled) {
        this.processHostEnabled = processHostEnabled;
        this.binderRoutingEnabled = binderRoutingEnabled;
        this.componentRoutingEnabled = componentRoutingEnabled;
        this.nativeLoadingEnabled = nativeLoadingEnabled;
    }

    public static GuestRuntimeConfig safeDefault() {
        return new GuestRuntimeConfig(false, false, false, false);
    }

    public boolean isProcessHostEnabled() { return processHostEnabled; }
    public boolean isBinderRoutingEnabled() { return binderRoutingEnabled; }
    public boolean isComponentRoutingEnabled() { return componentRoutingEnabled; }
    public boolean isNativeLoadingEnabled() { return nativeLoadingEnabled; }
}
