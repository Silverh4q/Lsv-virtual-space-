package com.lsv.virtualspace.framework.runtime;

import android.content.Context;
import android.content.Intent;
import android.content.ComponentName;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.ProviderInfo;
import android.os.Bundle;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.framework.GuestActivityContract;
import com.lsv.virtualspace.virtual.VirtualCore;
import com.lsv.virtualspace.virtual.VirtualPackageManager;
import com.lsv.virtualspace.guest.GuestComponentResolver;
import com.lsv.virtualspace.framework.packages.GuestPackageRegistry;
import com.lsv.virtualspace.framework.intent.GuestIntentResolver;

import java.util.HashMap;
import java.util.Map;

/**
 * Central guest-framework dispatcher.  Guest code reaches this layer through
 * GuestContext instead of talking directly to LSV's host identity.
 *
 * This is deliberately an ordinary application-side virtualization boundary:
 * it does not hook Binder or patch Android's system_server.
 */
public final class GuestFrameworkRuntime {
    private static final Object LOCK = new Object();
    private static final Map<String, GuestEnvironment> ENVIRONMENTS =
        new HashMap<String, GuestEnvironment>();

    private GuestFrameworkRuntime() { }

    public static void register(GuestEnvironment environment) {
        if (environment == null || environment.getPackageName() == null) return;
        synchronized (LOCK) {
            ENVIRONMENTS.put(environment.getPackageName(), environment);
        }
    }

    public static void unregister(String packageName) {
        if (packageName == null) return;
        synchronized (LOCK) { ENVIRONMENTS.remove(packageName); }
    }

    public static GuestEnvironment get(String packageName) {
        synchronized (LOCK) { return ENVIRONMENTS.get(packageName); }
    }

    /** Routes an activity through the central ActivityManager-style owner. */
    public static Intent toProxyActivity(Context guestContext, Intent guestIntent) {
        if (guestContext == null || guestIntent == null) return null;
        try {
            return VirtualCore.get().getFrameworkHost().getActivityManager()
                .routeActivity(guestContext.getPackageName(), guestIntent);
        } catch (Throwable ignored) {
            return null;
        }
    }

    /** Routes a service through the same central resolver/session owner. */
    public static Intent toProxyService(Context guestContext, Intent guestIntent) {
        if (guestContext == null || guestIntent == null) return null;
        try {
            return VirtualCore.get().getFrameworkHost().getActivityManager()
                .routeService(guestContext.getPackageName(), guestIntent);
        } catch (Throwable ignored) {
            return null;
        }
    }

    /** Routes a broadcast to the first matching guest receiver. */
    public static Intent toProxyBroadcast(Context guestContext, Intent guestIntent) {
        if (guestContext == null || guestIntent == null) return null;
        try {
            return VirtualCore.get().getFrameworkHost().getActivityManager()
                .routeBroadcast(guestContext.getPackageName(), guestIntent);
        } catch (Throwable ignored) {
            return null;
        }
    }

    /** Returns every manifest receiver matching the guest broadcast. */
    public static java.util.List<Intent> toProxyBroadcasts(Context guestContext, Intent guestIntent) {
        java.util.List<Intent> result = new java.util.ArrayList<Intent>();
        if (guestContext == null || guestIntent == null) return result;
        try {
            com.lsv.virtualspace.framework.runtime.GuestActivityManager manager =
                VirtualCore.get().getFrameworkHost().getActivityManager();
            java.util.List<String> components = manager.resolveReceivers(
                guestContext.getPackageName(), guestIntent);
            for (String component : components) {
                result.add(manager.buildReceiverProxy(guestContext.getPackageName(), guestIntent, component));
            }
        } catch (Throwable ignored) { }
        return result;
    }

    private static final class GuestReceiverProxyExtra {
        static final String PACKAGE = "lsv.guest.receiver.package";
        static final String GUEST_INTENT = "lsv.guest.receiver.intent";
        static final String COMPONENT = "lsv.guest.receiver.component";
    }
}
