package com.lsv.virtualspace.framework.intent;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ServiceInfo;
import android.content.ComponentName;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Generic manifest-driven resolver for guest activities and services. */
public final class GuestIntentResolver {
    private static final Map<String, List<GuestIntentFilterRecord>> FILTERS = new HashMap<String, List<GuestIntentFilterRecord>>();

    public synchronized void register(String packageName, String apkPath) {
        if (packageName == null || apkPath == null) return;
        FILTERS.put(packageName, GuestManifestFilterParser.parse(apkPath, packageName));
    }

    public synchronized void remove(String packageName) { FILTERS.remove(packageName); }

    public synchronized String resolveActivity(String packageName, PackageInfo info, Intent intent) {
        return resolve(packageName, info, intent, "activity");
    }

    public synchronized String resolveService(String packageName, PackageInfo info, Intent intent) {
        return resolve(packageName, info, intent, "service");
    }

    public synchronized List<String> resolveReceivers(String packageName, PackageInfo info, Intent intent) {
        List<String> result = new ArrayList<String>();
        if (info == null || intent == null) return result;
        ComponentName explicit = intent.getComponent();
        if (explicit != null && explicit.getClassName() != null) {
            if (info.receivers != null) {
                for (ActivityInfo receiver : info.receivers) {
                    if (receiver != null && explicit.getClassName().equals(receiver.name)) {
                        result.add(receiver.name);
                        return result;
                    }
                }
            }
            return result;
        }
        List<GuestIntentFilterRecord> list = FILTERS.get(packageName);
        if (list == null) return result;
        for (GuestIntentFilterRecord record : list) {
            if (!"receiver".equals(record.getComponentType()) || !record.isExported()) continue;
            int match = record.getFilter().match(intent.getAction(), intent.getType(),
                intent.getScheme(), intent.getData(), intent.getCategories(), "LSV");
            if (match >= 0) result.add(record.getComponentName());
        }
        return result;
    }

    public synchronized List<GuestIntentFilterRecord> getFilters(String packageName) {
        List<GuestIntentFilterRecord> list = FILTERS.get(packageName);
        return list == null ? new ArrayList<GuestIntentFilterRecord>() : new ArrayList<GuestIntentFilterRecord>(list);
    }

    private String resolve(String packageName, PackageInfo info, Intent intent, String type) {
        if (info == null || intent == null) return null;
        ComponentName explicit = intent.getComponent();
        if (explicit != null && explicit.getClassName() != null) {
            if ("activity".equals(type) && info.activities != null) {
                for (ActivityInfo a : info.activities) if (a != null && explicit.getClassName().equals(a.name)) return canonicalActivity(a);
            }
            if ("service".equals(type) && info.services != null) {
                for (ServiceInfo s : info.services) if (s != null && explicit.getClassName().equals(s.name)) return s.name;
            }
            return null;
        }

        List<GuestIntentFilterRecord> list = FILTERS.get(packageName);
        if (list == null) return null;
        int best = -1;
        String winner = null;
        for (GuestIntentFilterRecord record : list) {
            if (!type.equals(record.getComponentType()) || !record.isExported()) continue;
            int match = record.getFilter().match(intent.getAction(), intent.getType(), intent.getScheme(), intent.getData(), intent.getCategories(), "LSV");
            if (match >= 0 && match > best) { best = match; winner = record.getComponentName(); }
        }
        if ("activity".equals(type) && winner != null && info.activities != null) {
            for (ActivityInfo a : info.activities) {
                if (a != null && winner.equals(a.name)) return canonicalActivity(a);
            }
        }
        return winner;
    }

    private String canonicalActivity(ActivityInfo info) {
        if (info == null) return null;
        if (info.targetActivity != null && info.targetActivity.length() > 0) return info.targetActivity;
        return info.name;
    }
}
