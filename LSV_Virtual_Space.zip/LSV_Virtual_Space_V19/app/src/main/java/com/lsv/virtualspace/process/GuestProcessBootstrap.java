package com.lsv.virtualspace.process;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;
import com.lsv.virtualspace.framework.GuestActivityContract;

/**
 * Deterministic :guest process bootstrap.
 *
 * Android must first create GuestProcessService, initialize the guest runtime,
 * and explicitly return READY over Binder. Only then is GuestActivityProxy
 * launched. This removes the previous race where the host launched the Activity
 * immediately after bindService() and merely hoped the guest process was ready.
 */
public final class GuestProcessBootstrap {
    public static final class Result {
        public final boolean started;
        public final String error;
        private Result(boolean started, String error) {
            this.started = started;
            this.error = error;
        }
        public static Result ok() { return new Result(true, null); }
        public static Result fail(String value) { return new Result(false, value); }
    }

    private GuestProcessBootstrap() { }

    public static Result startAndLaunch(final Context context, final VirtualApp app,
                                        final Intent launchIntent) {
        if (context == null || app == null || launchIntent == null) {
            return Result.fail("Guest bootstrap received a null argument.");
        }

        final Context host = context.getApplicationContext();
        final GuestDiagnosticController diagnostics = GuestDiagnosticController.get(host);
        GuestProcessProbe.clear(host);
        final Handler handler = new Handler(Looper.getMainLooper());
        final BootstrapConnection connection = new BootstrapConnection(
            host, app, launchIntent, diagnostics, handler);

        Intent serviceIntent = new Intent(host, GuestProcessService.class);
        serviceIntent.setAction(GuestProcessCommand.ACTION_PREPARE);
        serviceIntent.putExtra(GuestProcessCommand.EXTRA_PACKAGE, app.getPackageName());
        serviceIntent.putExtra(GuestProcessCommand.EXTRA_APK, app.getApkPath());
        serviceIntent.putExtra(GuestProcessCommand.EXTRA_COMPONENT,
            launchIntent.getStringExtra(GuestActivityContract.EXTRA_COMPONENT));

        try {
            diagnostics.stage(GuestRuntimeStage.PROCESS_ATTACHED,
                "requesting Android creation of :guest GuestProcessService");
            host.startService(serviceIntent);
        } catch (Throwable error) {
            diagnostics.fail("GUEST_PROCESS_START_FAILED", error);
            return Result.fail("Unable to start LSV guest process service: " + formatError(error));
        }

        boolean bound;
        try {
            Intent bindIntent = new Intent(host, GuestProcessService.class);
            bindIntent.setAction(GuestProcessCommand.ACTION_PREPARE);
            bindIntent.putExtra(GuestProcessCommand.EXTRA_PACKAGE, app.getPackageName());
            bindIntent.putExtra(GuestProcessCommand.EXTRA_APK, app.getApkPath());
            bindIntent.putExtra(GuestProcessCommand.EXTRA_COMPONENT,
                launchIntent.getStringExtra(GuestActivityContract.EXTRA_COMPONENT));
            bound = host.bindService(bindIntent, connection, Context.BIND_AUTO_CREATE);
        } catch (Throwable error) {
            diagnostics.fail("GUEST_PROCESS_BIND_FAILED", error);
            return Result.fail("Unable to bind LSV guest process service: " + formatError(error));
        }

        if (!bound) {
            diagnostics.fail("GUEST_PROCESS_BIND_FAILED", null);
            return Result.fail("Android rejected the LSV guest process service bind.");
        }

        connection.armTimeout();
        return Result.ok();
    }

    private static final class BootstrapConnection implements ServiceConnection {
        private final Context host;
        private final VirtualApp app;
        private final Intent launchIntent;
        private final GuestDiagnosticController diagnostics;
        private final Handler handler;
        private boolean connected;
        private boolean launched;
        private boolean unbound;
        private Messenger callback;

        private final Runnable timeout = new Runnable() {
            @Override public void run() {
                if (launched) return;
                cleanup();
                String probe = GuestProcessProbe.describe(host);
                diagnostics.stage(GuestRuntimeStage.PROCESS_EXIT,
                    "guest process handshake timed out; probe: " + probe);
                diagnostics.fail("GUEST_PROCESS_HANDSHAKE_TIMEOUT", null);
            }
        };

        BootstrapConnection(Context host, VirtualApp app, Intent launchIntent,
                            GuestDiagnosticController diagnostics, Handler handler) {
            this.host = host;
            this.app = app;
            this.launchIntent = new Intent(launchIntent);
            this.diagnostics = diagnostics;
            this.handler = handler;
        }

        void armTimeout() {
            handler.postDelayed(timeout, 45000L);
        }

        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            if (connected || binder == null) return;
            connected = true;
            diagnostics.stage(GuestRuntimeStage.PROCESS_HANDSHAKE,
                "Android confirmed :guest ServiceConnection: " + name.getClassName());
            callback = new Messenger(new Handler(Looper.getMainLooper()) {
                @Override public void handleMessage(Message message) {
                    if (message == null || message.what != com.lsv.virtualspace.ipc.GuestIpcMessage.RESULT) return;
                    String status = message.getData().getString(
                        com.lsv.virtualspace.ipc.GuestIpcMessage.KEY_STATUS, "UNKNOWN");
                    String detail = message.getData().getString(
                        com.lsv.virtualspace.ipc.GuestIpcMessage.KEY_DETAIL, "");
                    if ("READY".equals(status)) {
                        launchAfterReady();
                    } else {
                        diagnostics.fail("GUEST_PROCESS_RUNTIME_INIT_FAILED", null);
                        diagnostics.stage(GuestRuntimeStage.PROCESS_EXIT,
                            "guest process rejected PREPARE: " + detail);
                        cleanup();
                    }
                }
            });
            sendPrepare(binder);
        }

        private void sendPrepare(IBinder binder) {
            try {
                Messenger messenger = new Messenger(binder);
                Message message = com.lsv.virtualspace.ipc.GuestIpcMessage.create(
                    com.lsv.virtualspace.ipc.GuestIpcMessage.PREPARE,
                    app.getPackageName(),
                    launchIntent.getStringExtra(GuestActivityContract.EXTRA_COMPONENT));
                message.replyTo = callback;
                messenger.send(message);
                diagnostics.stage(GuestRuntimeStage.RUNTIME_VERIFICATION,
                    "PREPARE sent; waiting for guest runtime READY");
            } catch (RemoteException error) {
                diagnostics.fail("GUEST_PROCESS_HANDSHAKE_FAILED", error);
                cleanup();
            } catch (Throwable error) {
                diagnostics.fail("GUEST_PROCESS_HANDSHAKE_FAILED", error);
                cleanup();
            }
        }

        private void launchAfterReady() {
            if (launched) return;
            launched = true;
            handler.removeCallbacks(timeout);
            diagnostics.stage(GuestRuntimeStage.FRAMEWORK_REGISTER,
                "guest runtime READY; launching GuestActivityProxy");
            try {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                host.startActivity(launchIntent);
                diagnostics.stage(GuestRuntimeStage.PROXY_ACTIVITY_CREATE,
                    "GuestActivityProxy launch requested after READY handshake");
                diagnostics.stage(GuestRuntimeStage.ACTIVITY_CREATE,
                    "GuestActivityProxy launch requested after READY handshake");
            } catch (Throwable error) {
                diagnostics.fail("GUEST_ACTIVITY_START_FAILED", error);
            } finally {
                cleanup();
            }
        }

        @Override public void onServiceDisconnected(ComponentName name) {
            if (!launched) {
                diagnostics.stage(GuestRuntimeStage.PROCESS_EXIT,
                    "guest process service disconnected before Activity launch");
                diagnostics.fail("GUEST_PROCESS_DISCONNECTED", null);
            }
            cleanup();
        }

        private void cleanup() {
            if (unbound) return;
            unbound = true;
            handler.removeCallbacks(timeout);
            try { host.unbindService(this); } catch (Throwable ignored) { }
        }
    }

    private static String formatError(Throwable error) {
        if (error == null) return "unknown";
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        String message = current.getMessage();
        return current.getClass().getName() +
            (message == null || message.length() == 0 ? "" : ": " + message);
    }
}
