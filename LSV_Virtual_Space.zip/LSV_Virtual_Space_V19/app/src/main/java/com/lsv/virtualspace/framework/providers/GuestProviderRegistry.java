package com.lsv.virtualspace.framework.providers;

import android.content.pm.ProviderInfo;

import com.lsv.virtualspace.framework.packages.GuestPackageRecord;
import com.lsv.virtualspace.framework.packages.GuestPackageRegistry;

import java.util.HashMap;
import java.util.Map;

/** Maps guest content-provider authorities into an LSV-owned namespace. */
public final class GuestProviderRegistry {
    private final GuestPackageRegistry packages;
    private final Map<String, ProviderInfo> providers = new HashMap<String, ProviderInfo>();

    public GuestProviderRegistry(GuestPackageRegistry packages) { this.packages = packages; }

    public synchronized ProviderInfo resolve(String packageName, String authority) {
        if (packageName == null || authority == null) return null;
        String key = packageName + ":" + authority;
        ProviderInfo cached = providers.get(key);
        if (cached != null) return cached;
        GuestPackageRecord record = packages.ensure(packageName);
        if (record == null || record.getPackageInfo().providers == null) return null;
        for (ProviderInfo info : record.getPackageInfo().providers) {
            if (info == null || info.authority == null) continue;
            String[] values = info.authority.split(";");
            for (String value : values) {
                if (authority.equals(value)) {
                    providers.put(key, info);
                    return info;
                }
            }
        }
        return null;
    }

    public String virtualAuthority(String packageName, String authority) {
        return "com.lsv.virtualspace.provider." + Integer.toHexString(
            (packageName + ":" + authority).hashCode());
    }
}
