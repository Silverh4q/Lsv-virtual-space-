package com.lsv.virtualspace.framework.system.adapters;
import android.os.Bundle; import com.lsv.virtualspace.framework.system.*;
public final class GuestConnectivityAdapter implements GuestSystemServiceAdapter {
 public String getServiceName(){return GuestSystemServiceName.CONNECTIVITY;}
 public boolean canHandle(String op){return "get_state".equals(op)||"set_network_state".equals(op);}
 public Bundle handle(String pkg,GuestSystemServiceRequest r,GuestSystemServiceState s){Bundle o=new Bundle();if("set_network_state".equals(r.getOperation()))s.put(pkg,getServiceName(),"network",r.getArguments()==null?"unknown":r.getArguments().getString("state","unknown"));String v=s.get(pkg,getServiceName(),"network");if(v==null)v="unknown";o.putString("state",v);o.putBoolean("accepted",true);return o;}
}
