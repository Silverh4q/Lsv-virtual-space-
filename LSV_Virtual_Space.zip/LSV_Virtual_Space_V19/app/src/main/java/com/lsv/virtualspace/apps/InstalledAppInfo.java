package com.lsv.virtualspace.apps;

import android.graphics.drawable.Drawable;

/** Small immutable record used by the installed-app picker. */
public final class InstalledAppInfo {
    private final String packageName;
    private final String label;
    private final String sourcePath;
    private final Drawable icon;

    public InstalledAppInfo(String packageName, String label, String sourcePath, Drawable icon) {
        this.packageName = packageName;
        this.label = label;
        this.sourcePath = sourcePath;
        this.icon = icon;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getLabel() {
        return label;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public Drawable getIcon() {
        return icon;
    }
}
