package com.lsv.virtualspace.engine.next;

import java.util.ArrayList; import java.util.List;

public final class BackendRegistry {
    private final List<GuestBackendContract> backends=new ArrayList<GuestBackendContract>();
    public void register(GuestBackendContract b){if(b!=null)backends.add(b);}
    public GuestBackendContract getSupported(){
        for(GuestBackendContract b:backends)if(b.isSupported())return b; return null;
    }
    public List<GuestBackendContract> getAll(){return new ArrayList<GuestBackendContract>(backends);}
}
