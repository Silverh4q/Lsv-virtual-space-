package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class AbiCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "ABI"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = android.os.Build.SUPPORTED_ABIS != null && android.os.Build.SUPPORTED_ABIS.length > 0;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
