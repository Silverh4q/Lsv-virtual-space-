package com.lsv.virtualspace.engine;
import android.content.Context; import com.lsv.virtualspace.profiles.*; import com.lsv.virtualspace.virtual.*;
public final class Stage50Runtime {
    private final GuestExecutionPlanner planner; private final GameCompatibilityAnalyzer games;
    public Stage50Runtime(Context c){planner=new GuestExecutionPlanner(c);games=new GameCompatibilityAnalyzer(c);}
    public GuestExecutionPlan prepare(GuestLaunchInfo info){return planner.plan(info);}
    public GameCompatibilityReport analyzeGame(String pkg,GuestExecutionCapability cap){return games.analyze(pkg,cap);}
}
