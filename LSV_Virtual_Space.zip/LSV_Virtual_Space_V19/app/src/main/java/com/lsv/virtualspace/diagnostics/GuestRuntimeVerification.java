package com.lsv.virtualspace.diagnostics;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Build;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.virtual.VirtualCore;
import com.lsv.virtualspace.virtual.VirtualPackageManager;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * End-to-end pre-launch verification. It deliberately reports every boundary
 * instead of stopping at the first failure so one run gives a complete picture.
 */
public final class GuestRuntimeVerification {
    public static final class Result {
        public int passed;
        public int failed;
        public final StringBuilder text = new StringBuilder();
        public boolean isHealthy() { return failed == 0; }
    }

    private GuestRuntimeVerification() { }

    public static Result verify(Context context, VirtualApp app) {
        Result r = new Result();
        GuestDiagnosticController.get(context).stage(GuestRuntimeStage.PREFLIGHT, "begin complete guest preflight");
        check(r, "1 APK path", app != null && app.getApkPath() != null);
        File apk = app == null ? null : new File(app.getApkPath());
        check(r, "2 APK exists", apk != null && apk.isFile());
        check(r, "3 APK readable", apk != null && apk.canRead());
        check(r, "4 APK nonempty", apk != null && apk.length() > 0L);
        check(r, "5 APK ZIP structure", isZip(apk));
        check(r, "6 AndroidManifest entry", hasEntry(apk, "AndroidManifest.xml"));
        check(r, "7 classes.dex entry", hasDex(apk));
        check(r, "8 virtual data directory", app != null && new File(app.getDataPath()).isDirectory());

        VirtualPackageManager pm = null;
        PackageInfo info = null;
        try {
            pm = VirtualCore.get().getRuntimeController().getPackageManager();
            info = app == null ? null : pm.getPackageInfo(app);
        } catch (Throwable e) {
            r.text.append("FAIL 9 PackageManager: ").append(e).append('\n'); r.failed++;
        }
        check(r, "9 PackageInfo", info != null);
        ApplicationInfo ai = info == null ? null : info.applicationInfo;
        check(r, "10 ApplicationInfo", ai != null);
        check(r, "11 package identity", ai != null && app.getPackageName().equals(ai.packageName));
        check(r, "12 sourceDir", ai != null && ai.sourceDir != null);
        check(r, "13 publicSourceDir", ai != null && ai.publicSourceDir != null);
        check(r, "14 target SDK readable", ai != null && ai.targetSdkVersion >= 1 && ai.targetSdkVersion <= 10000);
        check(r, "15 launchable activity", info != null && info.activities != null && info.activities.length > 0);
        check(r, "16 application label", pm != null && app != null && pm.getApplicationInfo(app) != null);
        check(r, "17 ABI host available", Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0);
        check(r, "18 guest APK list", app != null && app.getApkPaths() != null && app.getApkPaths().size() > 0);
        check(r, "19 class cache directory", app != null && ensure(new File(app.getDataPath(), "code-cache")));
        check(r, "20 native directory", app != null && ensure(new File(app.getDataPath(), "native-libs")));
        check(r, "21 diagnostics directory", GuestDiagnosticController.get(context).getStore().getRoot().isDirectory());
        check(r, "22 Android API", Build.VERSION.SDK_INT >= 23);
        check(r, "23 guest process name", (context.getPackageName() + ":guest").length() > 0);
        check(r, "24 classloader base", context.getClassLoader() != null);
        check(r, "25 framework host", VirtualCore.get().getFrameworkHost() != null);
        check(r, "26 package manager facade", VirtualCore.get().getFrameworkHost().getGuestPackageManager() != null);
        check(r, "27 activity manager", VirtualCore.get().getFrameworkHost().getActivityManager() != null);
        check(r, "28 system service facade", VirtualCore.get().getFrameworkHost().getSystemServices() != null);
        check(r, "29 requested permissions readable", info != null && info.requestedPermissions != null || info != null);
        check(r, "30 activity class names", info != null && info.activities != null && allNames(info.activities));
        check(r, "31 service metadata readable", info != null);
        check(r, "32 provider metadata readable", info != null);
        check(r, "33 APK length stable", apk != null && apk.length() > 1024L);
        check(r, "34 data files directory", app != null && ensure(new File(app.getDataPath(), "files")));
        check(r, "35 data cache directory", app != null && ensure(new File(app.getDataPath(), "cache")));
        check(r, "36 native directory writable", app != null && ensure(new File(app.getDataPath(), "native-libs")));
        check(r, "37 code cache writable", app != null && ensure(new File(app.getDataPath(), "code-cache")));
        check(r, "38 source file readable", ai != null && new File(ai.sourceDir).canRead());
        check(r, "39 public source file readable", ai != null && new File(ai.publicSourceDir).canRead());
        check(r, "40 diagnostic checkpoint writable", GuestDiagnosticController.get(context).getStore().saveCheckpoint(GuestDiagnosticController.get(context).snapshot()) != null);
        GuestDiagnosticController.get(context).stage(GuestRuntimeStage.PREFLIGHT, "complete: " + r.passed + " passed, " + r.failed + " failed");
        return r;
    }

    private static boolean allNames(android.content.pm.ActivityInfo[] values) {
        if (values == null || values.length == 0) return false;
        for (android.content.pm.ActivityInfo value : values) if (value == null || value.name == null || value.name.length() == 0) return false;
        return true;
    }

    private static void check(Result r, String name, boolean ok) {
        if (ok) { r.passed++; r.text.append("PASS ").append(name).append('\n'); }
        else { r.failed++; r.text.append("FAIL ").append(name).append('\n'); }
    }

    private static boolean ensure(File file) { return file.exists() || file.mkdirs() || file.isDirectory(); }

    private static boolean isZip(File file) {
        if (file == null) return false;
        ZipFile zip = null;
        try { zip = new ZipFile(file); return zip.size() > 0; }
        catch (Throwable e) { return false; }
        finally { if (zip != null) try { zip.close(); } catch (Throwable ignored) { } }
    }

    private static boolean hasEntry(File file, String name) {
        if (file == null) return false;
        ZipFile zip = null;
        try { zip = new ZipFile(file); return zip.getEntry(name) != null; }
        catch (Throwable e) { return false; }
        finally { if (zip != null) try { zip.close(); } catch (Throwable ignored) { } }
    }

    private static boolean hasDex(File file) {
        if (file == null) return false;
        ZipFile zip = null;
        try {
            zip = new ZipFile(file);
            for (java.util.Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements();) {
                String name = e.nextElement().getName();
                if ("classes.dex".equals(name) || name.startsWith("classes") && name.endsWith(".dex")) return true;
            }
        } catch (Throwable ignored) { }
        finally { if (zip != null) try { zip.close(); } catch (Throwable ignored) { } }
        return false;
    }
}
