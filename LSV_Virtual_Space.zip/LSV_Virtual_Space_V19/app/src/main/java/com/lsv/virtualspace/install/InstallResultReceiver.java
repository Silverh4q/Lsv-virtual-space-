package com.lsv.virtualspace.install;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.widget.Toast;

/** Receives Android's package-install result and launches the installed app. */
public final class InstallResultReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        int status = intent.getIntExtra(
            PackageInstaller.EXTRA_STATUS,
            PackageInstaller.STATUS_FAILURE
        );
        String packageName = intent.getStringExtra("packageName");
        if (status == PackageInstaller.STATUS_SUCCESS) {
            boolean launched = SystemApkLauncher.launchInstalled(context, packageName);
            Toast.makeText(
                context,
                launched ? "Application installed and launched." : "Application installed; no launcher activity was found.",
                Toast.LENGTH_LONG
            ).show();
        } else {
            String message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
            Toast.makeText(
                context,
                "Android could not install the APK" +
                    (message == null ? "." : ": " + message),
                Toast.LENGTH_LONG
            ).show();
        }
    }
}
