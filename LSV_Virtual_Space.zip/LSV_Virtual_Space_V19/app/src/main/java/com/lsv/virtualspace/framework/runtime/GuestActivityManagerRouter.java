package com.lsv.virtualspace.framework.runtime;

import android.content.Intent;
import android.content.ComponentName;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ServiceInfo;

import com.lsv.virtualspace.framework.intent.GuestIntentResolver;
import com.lsv.virtualspace.framework.packages.GuestPackageRegistry;
import com.lsv.virtualspace.framework.packages.GuestPackageRecord;
import com.lsv.virtualspace.virtual.VirtualPackageManager;

/**
 * ActivityManager-style routing facade. It resolves guest components before an
 * Android host proxy is ever started. No system_server hooks are required.
 */
public final class GuestActivityManagerRouter {
    private final VirtualPackageManager packages;
    private final GuestPackageRegistry registry;

    public GuestActivityManagerRouter(VirtualPackageManager packages,
                                      GuestPackageRegistry registry) {
        this.packages = packages;
        this.registry = registry;
    }

    public String resolveActivity(String packageName, Intent intent) {
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null) return null;
        return registry.getIntentResolver().resolveActivity(packageName,
            record.getPackageInfo(), intent);
    }

    public String resolveService(String packageName, Intent intent) {
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null) return null;
        return registry.getIntentResolver().resolveService(packageName,
            record.getPackageInfo(), intent);
    }

    public boolean isExportedActivity(String packageName, String component) {
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null || record.getPackageInfo().activities == null) return false;
        for (ActivityInfo info : record.getPackageInfo().activities) {
            if (info != null && component.equals(info.name)) return info.exported;
        }
        return false;
    }

    public boolean isExportedService(String packageName, String component) {
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null || record.getPackageInfo().services == null) return false;
        for (ServiceInfo info : record.getPackageInfo().services) {
            if (info != null && component.equals(info.name)) return info.exported;
        }
        return false;
    }
}
