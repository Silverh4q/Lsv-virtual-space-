package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class PackageManagerCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "PACKAGE_MANAGER"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && context.getPackageManager() != null;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
