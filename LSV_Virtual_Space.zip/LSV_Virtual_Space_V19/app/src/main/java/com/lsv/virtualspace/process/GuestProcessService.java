package com.lsv.virtualspace.process;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;

import com.lsv.virtualspace.engine.NativeRuntimeBridge;
import com.lsv.virtualspace.guest.runtime.GuestInstrumentation;
import com.lsv.virtualspace.ipc.GuestIpcMessage;
import com.lsv.virtualspace.ipc.GuestProcessMessenger;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestHeartbeat;
import com.lsv.virtualspace.diagnostics.GuestProcessPresence;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;
import com.lsv.virtualspace.virtual.VirtualCore;

/**
 * Minimal guest-process bootstrap boundary.
 *
 * The :guest process deliberately does not initialize the heavy virtual engine
 * from LsvApplication.onCreate(). Android creates the Application before this
 * Service, so keeping Application startup lightweight lets this Service become
 * the first reliable process handshake point.
 */
public final class GuestProcessService extends Service {
    private final LocalBinder binder = new LocalBinder();
    private String activePackage;
    private String activeComponent;
    private int state = GuestProcessState.NEW;
    private String runtimeError;
    private boolean runtimeReady;
    private boolean initializationStarted;
    private Messenger ipc;
    private GuestHeartbeat heartbeat;
    private Handler mainHandler;
    private Message pendingPrepare;

    public final class LocalBinder extends android.os.Binder {
        public String getActivePackage() { return activePackage; }
        public String getActiveComponent() { return activeComponent; }
        public int getState() { return state; }
        public boolean isRunning() { return state == GuestProcessState.RUNNING; }
        public boolean isRuntimeReady() { return runtimeReady; }
        public String getRuntimeError() { return runtimeError; }
    }

    @Override public void onCreate() {
        super.onCreate();
        GuestProcessProbe.mark(this, "SERVICE_ON_CREATE", null, null);

        // IMPORTANT: keep Service.onCreate() extremely small. Android cannot
        // deliver ServiceConnection.onServiceConnected() until onCreate()/
        // onBind() return. Heavy VirtualCore/Instrumentation initialization
        // here previously caused the host to wait until the handshake timed
        // out when the guest process died or stalled during bootstrap.
        mainHandler = new Handler(Looper.getMainLooper());

        try {
            com.lsv.virtualspace.diagnostics.GuestUncaughtExceptionHandler.install(this);
        } catch (Throwable ignored) {
        }

        try {
            ipc = new GuestProcessMessenger(new GuestProcessMessenger.Listener() {
                @Override public void onCommand(Message message, int command,
                                                String packageName, String component) {
                    handle(message, command, packageName, component);
                }
            }).getMessenger();
        } catch (Throwable error) {
            runtimeError = formatError(error);
            ipc = null;
        }

        // Diagnostics are best-effort at this earliest boundary. A diagnostic
        // storage failure must never prevent Android from binding the service.
        try {
            GuestProcessProbe.mark(this, "DIAGNOSTICS_BEGIN", activePackage, activeComponent);
            GuestDiagnosticController diagnostics = GuestDiagnosticController.get(this);
            diagnostics.adoptPendingTransaction();
            diagnostics.stage(GuestRuntimeStage.PROCESS_ATTACHED,
                "GuestProcessService.onCreate pid=" + Process.myPid() + " (lightweight)");
            GuestProcessPresence.touch(this, diagnostics.getActivePackage());
        } catch (Throwable ignored) {
        }
    }

    private boolean initializeGuestRuntime(GuestDiagnosticController diagnostics) {
        try {
            diagnostics.stage(GuestRuntimeStage.RUNTIME_VERIFICATION,
                "guest process runtime initialization");
            VirtualCore.get().initialize(this);
            diagnostics.stage(GuestRuntimeStage.FRAMEWORK_REGISTER,
                "VirtualCore initialized in :guest");

            // Optional native bridge: failure is recorded but is not itself fatal.
            boolean nativeLoaded = NativeRuntimeBridge.tryLoad("lsvengine");
            diagnostics.stage(GuestRuntimeStage.NATIVE_PREPARE,
                "LSV native bridge loaded=" + nativeLoaded);

            diagnostics.stage(GuestRuntimeStage.INSTRUMENTATION_INSTALL,
                "installing GuestInstrumentation");
            boolean instrumentation = GuestInstrumentation.install(this);
            if (!instrumentation) {
                String detail = GuestInstrumentation.getLastInstallError();
                diagnostics.stage(GuestRuntimeStage.INSTRUMENTATION_INSTALL,
                    "GuestInstrumentation unavailable: " + detail);
                throw new IllegalStateException("GuestInstrumentation unavailable: " + detail);
            }
            diagnostics.stage(GuestRuntimeStage.FRAMEWORK_REGISTER,
                "GuestInstrumentation installed");
            return true;
        } catch (Throwable error) {
            runtimeError = formatError(error);
            diagnostics.fail("GUEST_PROCESS_RUNTIME_INIT_FAILED", error);
            return false;
        }
    }

    private void handle(Message request, int command, String packageName, String component) {
        if (command == GuestIpcMessage.PREPARE) {
            activePackage = packageName;
            activeComponent = component;
            try { GuestProcessPresence.touch(this, activePackage); } catch (Throwable ignored) { }

            if (runtimeReady) {
                state = GuestProcessState.READY;
                GuestProcessStateStore.write(this, activePackage, state, "READY");
                reply(request, state, "READY");
                return;
            }

            if (request != null && request.replyTo != null) {
                pendingPrepare = Message.obtain(request);
            }
            startInitialization();
            return;
        } else if (command == GuestIpcMessage.START) {
            activePackage = packageName;
            activeComponent = component;
            try { GuestProcessPresence.touch(this, activePackage); } catch (Throwable ignored) { }
            state = runtimeReady ? GuestProcessState.RUNNING : GuestProcessState.FAILED;
            GuestProcessStateStore.write(this, activePackage, state, runtimeReady ? "RUNNING" : runtimeError);
            reply(request, state, runtimeReady ? "RUNNING" : runtimeError);
        } else if (command == GuestIpcMessage.PING) {
            try { GuestProcessPresence.touch(this, activePackage); } catch (Throwable ignored) { }
            reply(request, state, runtimeReady ? "PONG" : (runtimeError == null ? "INITIALIZING" : runtimeError));
        } else if (command == GuestIpcMessage.STOP) {
            state = GuestProcessState.STOPPING;
            GuestProcessStateStore.write(this, activePackage, state, "STOPPING");
            reply(request, state, "STOPPING");
            activePackage = null;
            activeComponent = null;
            state = GuestProcessState.STOPPED;
            GuestProcessStateStore.write(this, null, state, "STOPPED");
            stopSelf();
        }
    }

    private void startInitialization() {
        if (initializationStarted || runtimeReady) return;
        initializationStarted = true;
        state = GuestProcessState.PREPARING;
        GuestProcessStateStore.write(this, activePackage, state, "initializing guest runtime");
        if (mainHandler == null) mainHandler = new Handler(Looper.getMainLooper());
        mainHandler.post(new Runnable() {
            @Override public void run() {
                GuestDiagnosticController diagnostics = null;
                try {
                    diagnostics = GuestDiagnosticController.get(GuestProcessService.this);
                    diagnostics.adoptPendingTransaction();
                    diagnostics.stage(GuestRuntimeStage.APPLICATION_STARTUP,
                        "starting guest runtime initialization after Binder handshake");
                    runtimeReady = initializeGuestRuntime(diagnostics);
                } catch (Throwable error) {
                    runtimeReady = false;
                    runtimeError = formatError(error);
                    if (diagnostics != null) diagnostics.fail("GUEST_PROCESS_RUNTIME_INIT_FAILED", error);
                }

                state = runtimeReady ? GuestProcessState.READY : GuestProcessState.FAILED;
                GuestProcessStateStore.write(GuestProcessService.this, activePackage, state,
                    runtimeReady ? "runtime ready" : runtimeError);

                if (runtimeReady) {
                    try {
                        heartbeat = new GuestHeartbeat(GuestProcessService.this);
                        heartbeat.start();
                        if (diagnostics != null) {
                            diagnostics.stage(GuestRuntimeStage.FRAMEWORK_REGISTER,
                                "guest process runtime ready; instrumentation=" + GuestInstrumentation.isInstalled());
                        }
                    } catch (Throwable error) {
                        runtimeReady = false;
                        state = GuestProcessState.FAILED;
                        runtimeError = formatError(error);
                        if (diagnostics != null) diagnostics.fail("GUEST_PROCESS_RUNTIME_INIT_FAILED", error);
                    }
                }

                if (pendingPrepare != null) {
                    Message request = pendingPrepare;
                    pendingPrepare = null;
                    reply(request, state, runtimeReady ? "READY" : runtimeError);
                }
            }
        });
    }

    private void reply(Message request, int stateValue, String detail) {
        if (request == null || request.replyTo == null) return;
        GuestProcessMessenger.send(request.replyTo,
            GuestProcessMessenger.result(activePackage, stateValue, detail));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (GuestProcessCommand.ACTION_PREPARE.equals(action)) {
                activePackage = intent.getStringExtra(GuestProcessCommand.EXTRA_PACKAGE);
                activeComponent = intent.getStringExtra(GuestProcessCommand.EXTRA_COMPONENT);
                // Do NOT initialize the heavy runtime from onStartCommand().
                // The host deliberately starts the service before binding it.
                // Starting VirtualCore/Instrumentation here recreates the exact
                // race this service exists to eliminate. Initialization begins
                // only after the Binder PREPARE message is received.
                GuestProcessProbe.mark(this, "SERVICE_START_REQUESTED", activePackage, activeComponent);
                if (runtimeReady) {
                    state = GuestProcessState.READY;
                    GuestProcessStateStore.write(this, activePackage, state, "READY");
                }
            } else if (GuestProcessCommand.ACTION_STOP.equals(action)) {
                state = GuestProcessState.STOPPING;
                stopSelfResult(startId);
            }
        }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) {
        // The Binder endpoint must be available even while runtime initialization
        // is still in progress. The host uses this callback as the process
        // existence handshake; READY is sent later after initialization.
        try {
            GuestDiagnosticController.get(this).stage(GuestRuntimeStage.PROCESS_HANDSHAKE,
                "GuestProcessService.onBind pid=" + Process.myPid());
        } catch (Throwable ignored) { }
        GuestProcessProbe.mark(this, "SERVICE_ON_BIND", activePackage, activeComponent);
        if (ipc != null) return ipc.getBinder();
        return binder;
    }

    @Override public void onDestroy() {
        try { GuestDiagnosticController.get(this).stage(GuestRuntimeStage.CLEANUP_BEGIN, "guest process service destroying"); } catch (Throwable ignored) { }
        if (heartbeat != null) heartbeat.stop();
        GuestProcessStateStore.write(this, activePackage, GuestProcessState.STOPPED, "service destroyed");
        GuestProcessPresence.clear(this);
        activePackage = null;
        activeComponent = null;
        state = GuestProcessState.STOPPED;
        try { GuestDiagnosticController.get(this).stage(GuestRuntimeStage.CLEANUP_COMPLETE, "guest process service destroyed"); } catch (Throwable ignored) { }
        super.onDestroy();
    }

    private static String formatError(Throwable error) {
        if (error == null) return "unknown";
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        String message = current.getMessage();
        return current.getClass().getName() +
            (message == null || message.length() == 0 ? "" : ": " + message);
    }
}
