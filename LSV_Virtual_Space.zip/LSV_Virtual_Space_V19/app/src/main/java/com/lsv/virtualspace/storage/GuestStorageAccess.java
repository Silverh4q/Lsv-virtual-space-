package com.lsv.virtualspace.storage;

import android.content.Context;
import android.net.Uri;
import java.io.File;

/** User-facing storage operations for one virtual app. */
public final class GuestStorageAccess {
    private final Context context;
    public GuestStorageAccess(Context context) { this.context = context.getApplicationContext(); }
    public File getGuestRoot(String dataPath) { return dataPath == null ? null : new File(dataPath); }
    public boolean exportApk(File apk, Uri destination) { return StorageExportManager.exportFile(context, apk, destination); }
}
