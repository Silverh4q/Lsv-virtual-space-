package com.lsv.virtualspace.diagnostics;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;

/** Small file-backed report store. It never depends on the guest Context. */
public final class GuestDiagnosticStore {
    private final File root;

    public GuestDiagnosticStore(Context host) {
        root = new File(host.getFilesDir(), "virtual/diagnostics");
        root.mkdirs();
    }

    public synchronized File save(GuestDiagnosticReport report) {
        if (report == null) return null;
        String pkg = safe(report.packageName);
        File dir = new File(root, pkg);
        dir.mkdirs();
        File latest = new File(dir, "latest.txt");
        File archive = new File(dir, safe(report.id) + ".txt");
        write(latest, report.toText());
        write(archive, report.toText());
        return latest;
    }

    public synchronized File saveCheckpoint(GuestDiagnosticReport report) {
        if (report == null) return null;
        String pkg = safe(report.packageName);
        File dir = new File(root, pkg);
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, "active.txt");
        write(file, report.toText());
        return file;
    }

    public synchronized String readActive(String packageName) {
        File file = new File(new File(root, safe(packageName)), "active.txt");
        return read(file);
    }

    public synchronized String readLatest(String packageName) {
        File file = new File(new File(root, safe(packageName)), "latest.txt");
        if (!file.exists()) return null;
        return read(file);
    }


    public synchronized void saveTransactionSeed(GuestDiagnosticReport report) {
        if (report == null) return;
        try {
            File seed = new File(root, "pending.properties");
            java.util.Properties props = new java.util.Properties();
            props.setProperty("id", report.id == null ? "" : report.id);
            props.setProperty("package", report.packageName == null ? "" : report.packageName);
            props.setProperty("component", report.component == null ? "" : report.component);
            props.setProperty("started", String.valueOf(report.startedAt));
            props.setProperty("apk", report.apkPath == null ? "" : report.apkPath);
            FileOutputStream out = new FileOutputStream(seed);
            props.store(out, "LSV guest diagnostic transaction");
            out.close();
        } catch (Throwable ignored) { }
    }

    public synchronized GuestDiagnosticReport readTransactionSeed() {
        try {
            File seed = new File(root, "pending.properties");
            if (!seed.exists()) return null;
            java.util.Properties props = new java.util.Properties();
            FileInputStream in = new FileInputStream(seed);
            props.load(in);
            in.close();
            GuestDiagnosticReport report = new GuestDiagnosticReport();
            report.id = emptyToNull(props.getProperty("id"));
            report.packageName = emptyToNull(props.getProperty("package"));
            report.component = emptyToNull(props.getProperty("component"));
            report.apkPath = emptyToNull(props.getProperty("apk"));
            try { report.startedAt = Long.parseLong(props.getProperty("started", "0")); }
            catch (Throwable ignored) { report.startedAt = System.currentTimeMillis(); }
            report.kind = "RUNNING";
            return report;
        } catch (Throwable ignored) { return null; }
    }

    public synchronized void clearTransactionSeed() {
        try {
            File seed = new File(root, "pending.properties");
            if (seed.exists()) seed.delete();
        } catch (Throwable ignored) { }
    }

    private static String emptyToNull(String value) {
        return value == null || value.length() == 0 ? null : value;
    }

    public synchronized File getRoot() { return root; }

    private static String read(File file) {
        if (file == null || !file.exists()) return null;
        StringBuilder out = new StringBuilder();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(file), Charset.forName("UTF-8")));
            String line;
            while ((line = br.readLine()) != null) out.append(line).append('\n');
            return out.toString();
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (br != null) try { br.close(); } catch (Throwable ignored) { }
        }
    }

    private static void write(File file, String text) {
        try {
            Writer writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
            writer.write(text == null ? "" : text);
            writer.close();
        } catch (Throwable ignored) { }
    }

    private static String safe(String value) {
        if (value == null || value.length() == 0) return "unknown";
        return value.replaceAll("[^A-Za-z0-9._-]", "_");
    }
}
