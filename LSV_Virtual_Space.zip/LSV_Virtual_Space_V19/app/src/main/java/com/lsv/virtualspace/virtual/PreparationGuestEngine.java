package com.lsv.virtualspace.virtual;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.diagnostics.GuestRuntimeDiagnostics;
import com.lsv.virtualspace.guest.GuestArtifactLoader;
import com.lsv.virtualspace.guest.GuestClassLoaderRegistry;
import com.lsv.virtualspace.guest.GuestComponentResolver;
import com.lsv.virtualspace.policy.GuestDataPolicy;
import com.lsv.virtualspace.policy.GuestPermissionPolicy;

/**
 * Stage 5-10 integration backend. It prepares all guest artifacts and policy
 * state but deliberately refuses to claim arbitrary APK execution.
 */
public class PreparationGuestEngine implements GuestEngine {
    private Context context;
    private VirtualRuntimeController controller;
    private GuestArtifactLoader artifacts;
    private GuestClassLoaderRegistry loaders;
    private GuestComponentResolver components;
    private GuestPermissionPolicy permissions;
    private GuestDataPolicy data;
    private GuestRuntimeDiagnostics diagnostics;

    @Override
    public void initialize(Context context, VirtualRuntimeController controller) {
        this.context = context.getApplicationContext();
        this.controller = controller;
        artifacts = new GuestArtifactLoader(this.context);
        loaders = new GuestClassLoaderRegistry();
        components = new GuestComponentResolver(controller.getPackageManager());
        permissions = new GuestPermissionPolicy(controller.getPackageManager());
        data = new GuestDataPolicy(controller.getStorage());
        diagnostics = new GuestRuntimeDiagnostics(controller.getPackageManager());
    }

    @Override
    public PreparedGuest prepare(VirtualApp app) {
        GuestLaunchInfo info = controller.getMetadataRuntime().prepare(app);
        if (info == null) {
            return new PreparedGuest(
                app,
                null,
                new GuestExecutionCapability(false, "No launchable guest activity.")
            );
        }

        data.root(app);
        data.files(app);
        data.cache(app);

        try {
            loaders.put(
                app,
                artifacts.createClassLoader(info.getApkPath(), info.getDataPath())
            );
        } catch (Exception e) {
            return new PreparedGuest(
                app,
                info,
                new GuestExecutionCapability(false, "Guest dex preparation failed: " + e.getMessage())
            );
        }

        return new PreparedGuest(
            app,
            info,
            new GuestExecutionCapability(
                false,
                "Virtual process/Binder/ActivityManager backend is not attached. Guest artifacts are prepared only."
            )
        );
    }

    @Override
    public boolean start(PreparedGuest guest) {
        return false;
    }

    @Override
    public void stop(VirtualApp app) {
        if (app != null) {
            loaders.remove(app.getPackageName());
        }
    }

    @Override
    public void shutdown() {
        loaders.clear();
    }

    public GuestComponentResolver getComponents() { return components; }
    public GuestPermissionPolicy getPermissions() { return permissions; }
    public GuestDataPolicy getData() { return data; }
    public GuestRuntimeDiagnostics getDiagnostics() { return diagnostics; }
}
