package com.lsv.virtualspace.framework.components;

/** Validated component construction request. No class is instantiated here. */
public final class GuestComponentFactoryPlan {
    private final String packageName;
    private final String className;
    private final String componentType;
    private final boolean exported;

    public GuestComponentFactoryPlan(String packageName, String className,
                                     String componentType, boolean exported) {
        this.packageName = packageName;
        this.className = className;
        this.componentType = componentType;
        this.exported = exported;
    }

    public String getPackageName() { return packageName; }
    public String getClassName() { return className; }
    public String getComponentType() { return componentType; }
    public boolean isExported() { return exported; }
}
