package com.lsv.virtualspace.diagnostics;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.Charset;

/** Persistent host-startup failure report. It is deliberately independent of VirtualCore. */
public final class HostStartupDiagnostics {
    private static final String FILE_NAME = "host_startup_failure.txt";

    private HostStartupDiagnostics() { }

    public static void record(Context context, Throwable error) {
        if (context == null) return;
        try {
            File dir = new File(context.getFilesDir(), "virtual/diagnostics/host");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, FILE_NAME);
            StringBuilder out = new StringBuilder();
            out.append("LSV HOST STARTUP FAILURE\n");
            out.append("========================\n");
            out.append("Time: ").append(System.currentTimeMillis()).append('\n');
            out.append("Android: ").append(android.os.Build.VERSION.SDK_INT).append('\n');
            out.append("Message: ").append(describe(error)).append("\n\n");
            if (error != null) {
                java.io.StringWriter sw = new java.io.StringWriter();
                error.printStackTrace(new java.io.PrintWriter(sw));
                out.append(sw.toString());
            }
            FileOutputStream fos = new FileOutputStream(file, false);
            fos.write(out.toString().getBytes(Charset.forName("UTF-8")));
            fos.close();
        } catch (Throwable ignored) {
        }
    }

    public static String latest(Context context) {
        if (context == null) return "";
        try {
            File file = new File(context.getFilesDir(), "virtual/diagnostics/host/" + FILE_NAME);
            if (!file.exists()) return "";
            java.io.FileInputStream in = new java.io.FileInputStream(file);
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int read;
            while ((read = in.read(buffer)) >= 0) {
                if (read == 0) continue;
                out.write(buffer, 0, read);
            }
            in.close();
            return new String(out.toByteArray(), Charset.forName("UTF-8"));
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static String describe(Throwable error) {
        if (error == null) return "Unknown error";
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        String message = current.getMessage();
        return current.getClass().getName() + (message == null ? "" : ": " + message);
    }
}
