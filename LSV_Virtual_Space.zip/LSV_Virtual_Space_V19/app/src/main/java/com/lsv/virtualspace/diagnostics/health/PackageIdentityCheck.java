package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class PackageIdentityCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "PACKAGE_IDENTITY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = app != null && app.getPackageName() != null && app.getPackageName().length() > 0;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
