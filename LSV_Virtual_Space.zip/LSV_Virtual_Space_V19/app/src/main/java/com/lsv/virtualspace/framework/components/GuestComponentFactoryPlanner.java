package com.lsv.virtualspace.framework.components;

import android.content.pm.ActivityInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;

/** Produces component plans from already parsed Android component metadata. */
public final class GuestComponentFactoryPlanner {
    private GuestComponentFactoryPlanner() {}

    public static GuestComponentFactoryPlan activity(ActivityInfo info) {
        if (info == null || info.name == null) return null;
        return new GuestComponentFactoryPlan(
            info.packageName, info.name, "activity", info.exported
        );
    }

    public static GuestComponentFactoryPlan service(ServiceInfo info) {
        if (info == null || info.name == null) return null;
        return new GuestComponentFactoryPlan(
            info.packageName, info.name, "service", info.exported
        );
    }

    public static GuestComponentFactoryPlan provider(ProviderInfo info) {
        if (info == null || info.name == null) return null;
        return new GuestComponentFactoryPlan(
            info.packageName, info.name, "provider", info.exported
        );
    }
}
