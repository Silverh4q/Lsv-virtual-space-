package com.lsv.virtualspace.guest.runtime;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.IntentFilter;
import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.content.res.Resources;

import java.io.File;

import com.lsv.virtualspace.framework.runtime.GuestEnvironment;
import com.lsv.virtualspace.framework.binder.GuestBinderCode;
import com.lsv.virtualspace.framework.binder.GuestBinderReply;
import com.lsv.virtualspace.framework.ipc.GuestFrameworkClient;
import android.content.pm.PackageManager;
import com.lsv.virtualspace.framework.runtime.GuestFrameworkRuntime;
import com.lsv.virtualspace.virtual.VirtualCore;
import com.lsv.virtualspace.framework.system.GuestSystemServiceFacade;
import com.lsv.virtualspace.framework.packages.GuestPackageManagerFacade;
import com.lsv.virtualspace.framework.window.GuestWindowManagerProxy;
import android.view.WindowManager;
import android.content.pm.ResolveInfo;
import java.util.List;

/**
 * Guest-facing Context facade. It keeps the guest package identity and private
 * data directories while delegating system services to the host process.
 */
public final class GuestContext extends ContextWrapper {
    private final String packageName;
    private final ApplicationInfo applicationInfo;
    private final Resources resources;
    private final AssetManager assets;
    private final ClassLoader classLoader;
    private final File dataDir;
    private final File filesDir;
    private final File cacheDir;
    private final File codeCacheDir;
    private Resources.Theme theme;
    private Application guestApplication;
    private final int themeResId;
    private GuestFrameworkClient frameworkClient;

    public GuestContext(Context base, String packageName, ApplicationInfo applicationInfo,
                        Resources resources, AssetManager assets, ClassLoader classLoader,
                        File dataDir, int themeResId) {
        super(base);
        this.packageName = packageName;
        this.applicationInfo = applicationInfo;
        this.resources = resources;
        this.assets = assets;
        this.classLoader = classLoader;
        this.dataDir = dataDir;
        this.filesDir = new File(dataDir, "files");
        this.cacheDir = new File(dataDir, "cache");
        this.codeCacheDir = new File(dataDir, "code_cache");
        this.themeResId = themeResId;
        this.filesDir.mkdirs();
        this.cacheDir.mkdirs();
        this.codeCacheDir.mkdirs();
    }

    public void setGuestApplication(Application application) { guestApplication = application; }
    @Override public Context getApplicationContext() { return guestApplication == null ? this : guestApplication; }

    @Override public String getPackageName() { return packageName; }
    @Override public String getOpPackageName() { return packageName; }
    @Override public ApplicationInfo getApplicationInfo() { return applicationInfo; }
    @Override public Resources getResources() { return resources; }
    @Override public AssetManager getAssets() { return assets; }
    @Override public ClassLoader getClassLoader() { return classLoader; }
    @Override public File getDataDir() { return dataDir; }
    @Override public File getFilesDir() { return filesDir; }
    @Override public File getCacheDir() { return cacheDir; }
    @Override public File getCodeCacheDir() { return codeCacheDir; }
    @Override public String getPackageCodePath() { return applicationInfo.sourceDir; }
    @Override public String getPackageResourcePath() { return applicationInfo.publicSourceDir; }
    @Override public File getDir(String name, int mode) {
        File dir = new File(dataDir, name == null ? "files" : name);
        dir.mkdirs();
        return dir;
    }
    @Override public File getNoBackupFilesDir() { return new File(dataDir, "no_backup"); }
    @Override public File getExternalFilesDir(String type) {
        File root = new File(dataDir, "external_files");
        if (type != null) root = new File(root, type);
        root.mkdirs();
        return root;
    }
    @Override public File getExternalCacheDir() {
        File root = new File(dataDir, "external_cache");
        root.mkdirs();
        return root;
    }

    private GuestFrameworkClient frameworkClient() {
        if (frameworkClient == null) frameworkClient = new GuestFrameworkClient(this, packageName);
        return frameworkClient;
    }

    @Override public int checkSelfPermission(String permission) {
        try {
            android.os.Bundle data = new android.os.Bundle();
            data.putString("permission", permission);
            GuestBinderReply reply = frameworkClient().dispatch(GuestBinderCode.CHECK_PERMISSION, permission, data);
            if (reply.isSuccess()) return reply.getData().getInt("result", PackageManager.PERMISSION_DENIED);
        } catch (Throwable ignored) { }
        return PackageManager.PERMISSION_DENIED;
    }

    public void registerFrameworkEnvironment() {
        GuestFrameworkRuntime.register(new GuestEnvironment(packageName, applicationInfo,
            resources, classLoader, dataDir, guestApplication));
    }

    @Override public Object getSystemService(String name) {
        try {
            GuestSystemServiceFacade facade = VirtualCore.get().getFrameworkHost().getSystemServices();
            com.lsv.virtualspace.diagnostics.GuestDiagnosticController.get(this).stage(
                com.lsv.virtualspace.diagnostics.GuestRuntimeStage.SERVICE_BOUNDARY_READY, name);
            Object service = facade.getService(packageName, name);
            if (Context.WINDOW_SERVICE.equals(name) && service instanceof WindowManager) {
                return GuestWindowManagerProxy.create(this, (WindowManager) service, packageName, facade);
            }
            if (service != null) return service;
        } catch (Throwable ignored) { }
        return super.getSystemService(name);
    }

    /** Returns the virtual PackageManager facade used by guest-aware framework code. */
    public GuestPackageManagerFacade getGuestPackageManager() {
        try { return VirtualCore.get().getFrameworkHost().getGuestPackageManager(); }
        catch (Throwable ignored) { return null; }
    }

    public android.content.pm.PackageInfo getGuestPackageInfo(int flags) {
        GuestPackageManagerFacade pm = getGuestPackageManager();
        return pm == null ? null : pm.getPackageInfo(packageName, flags);
    }

    public android.content.pm.ApplicationInfo getGuestApplicationInfo(int flags) {
        GuestPackageManagerFacade pm = getGuestPackageManager();
        return pm == null ? null : pm.getApplicationInfo(packageName, flags);
    }

    public String getGuestApplicationLabel() {
        GuestPackageManagerFacade pm = getGuestPackageManager();
        return pm == null ? packageName : pm.getApplicationLabel(packageName);
    }

    public List<ResolveInfo> queryGuestActivities(Intent intent) {
        GuestPackageManagerFacade pm = getGuestPackageManager();
        return pm == null ? new java.util.ArrayList<ResolveInfo>() : pm.queryIntentActivities(packageName, intent);
    }

    public List<ResolveInfo> queryGuestServices(Intent intent) {
        GuestPackageManagerFacade pm = getGuestPackageManager();
        return pm == null ? new java.util.ArrayList<ResolveInfo>() : pm.queryIntentServices(packageName, intent);
    }

    public android.os.Bundle setGuestClipboardText(String text) {
        android.os.Bundle b = new android.os.Bundle(); b.putString("text", text == null ? "" : text);
        return requestSystemService(com.lsv.virtualspace.framework.system.GuestSystemServiceName.CLIPBOARD, "set_primary", b);
    }

    public android.os.Bundle getGuestClipboardText() {
        return requestSystemService(com.lsv.virtualspace.framework.system.GuestSystemServiceName.CLIPBOARD, "get_primary", null);
    }

    public android.os.Bundle postGuestNotification(String id, String title, String text) {
        android.os.Bundle b = new android.os.Bundle();
        b.putString("id", id); b.putString("title", title); b.putString("text", text);
        return requestSystemService(com.lsv.virtualspace.framework.system.GuestSystemServiceName.NOTIFICATION, "post", b);
    }

    public android.os.Bundle cancelGuestNotification(String id) {
        android.os.Bundle b = new android.os.Bundle(); b.putString("id", id);
        return requestSystemService(com.lsv.virtualspace.framework.system.GuestSystemServiceName.NOTIFICATION, "cancel", b);
    }

    /** Explicit guest-aware entry point for operations requiring mediation. */
    public android.os.Bundle requestSystemService(String service, String operation, android.os.Bundle args) {
        try {
            com.lsv.virtualspace.diagnostics.GuestDiagnosticController.get(this).stage(
                com.lsv.virtualspace.diagnostics.GuestRuntimeStage.SERVICE_REQUEST,
                service + "/" + operation);
            android.os.Bundle data = args == null ? new android.os.Bundle() : new android.os.Bundle(args);
            data.putString("service", service);
            data.putString("operation", operation);
            GuestBinderReply reply = frameworkClient().dispatch(GuestBinderCode.SYSTEM_SERVICE_REQUEST, service, data);
            return reply.isSuccess() ? reply.getData() : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    @Override public void startActivity(Intent intent) {
        Intent proxy = GuestFrameworkRuntime.toProxyActivity(this, intent);
        if (proxy != null) { super.startActivity(proxy); return; }
        super.startActivity(intent);
    }

    @Override public ComponentName startService(Intent service) {
        if (isHostFrameworkIntent(service)) return super.startService(service);
        Intent proxy = GuestFrameworkRuntime.toProxyService(this, service);
        if (proxy != null) return super.startService(proxy);
        return super.startService(service);
    }

    @Override public ComponentName startForegroundService(Intent service) {
        if (isHostFrameworkIntent(service)) return invokeForegroundService(service);
        Intent proxy = GuestFrameworkRuntime.toProxyService(this, service);
        return invokeForegroundService(proxy == null ? service : proxy);
    }

    private ComponentName invokeForegroundService(Intent service) {
        if (android.os.Build.VERSION.SDK_INT < 26) return startService(service);
        try {
            java.lang.reflect.Method method = Context.class.getMethod("startForegroundService", Intent.class);
            Object value = method.invoke(this, service);
            return value instanceof ComponentName ? (ComponentName) value : null;
        } catch (Throwable error) {
            return startService(service);
        }
    }

    @Override public boolean stopService(Intent service) {
        if (isHostFrameworkIntent(service)) return super.stopService(service);
        Intent proxy = GuestFrameworkRuntime.toProxyService(this, service);
        return super.stopService(proxy == null ? service : proxy);
    }

    @Override public boolean bindService(Intent service, ServiceConnection conn, int flags) {
        if (isHostFrameworkIntent(service)) return super.bindService(service, conn, flags);
        Intent proxy = GuestFrameworkRuntime.toProxyService(this, service);
        if (proxy == null) return super.bindService(service, conn, flags);
        return super.bindService(proxy, conn, flags);
    }

    @Override public void sendBroadcast(Intent intent) {
        if (intent == null) return;
        java.util.List<Intent> proxies = GuestFrameworkRuntime.toProxyBroadcasts(this, intent);
        if (proxies.size() == 0) return;
        for (Intent proxy : proxies) super.sendBroadcast(proxy);
    }

    @Override public void sendBroadcast(Intent intent, String receiverPermission) {
        if (intent == null) return;
        java.util.List<Intent> proxies = GuestFrameworkRuntime.toProxyBroadcasts(this, intent);
        if (proxies.size() == 0) return;
        for (Intent proxy : proxies) super.sendBroadcast(proxy, receiverPermission);
    }

    private boolean isHostFrameworkIntent(Intent intent) {
        if (intent == null) return false;
        ComponentName component = intent.getComponent();
        return component != null && "com.lsv.virtualspace".equals(component.getPackageName());
    }

    @Override public Resources.Theme getTheme() {
        if (theme == null) {
            theme = resources.newTheme();
            if (themeResId != 0) {
                try { theme.applyStyle(themeResId, true); } catch (Throwable ignored) { }
            }
        }
        return theme;
    }

    @Override public void setTheme(int resid) {
        try {
            getTheme().applyStyle(resid, true);
        } catch (Throwable ignored) { }
    }
}
