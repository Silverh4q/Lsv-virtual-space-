package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ApkZipCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "APK_ZIP"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = isZipReadable(app);
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }

    private static boolean isZipReadable(VirtualApp app) {
        if (app == null || app.getApkPath() == null) return false;
        java.util.zip.ZipFile zip = null;
        try {
            zip = new java.util.zip.ZipFile(app.getApkPath());
            return zip.size() > 0;
        } catch (Throwable ignored) {
            return false;
        } finally {
            if (zip != null) try { zip.close(); } catch (Throwable ignored) { }
        }
    }
}
