package com.lsv.virtualspace.virtual;

import com.lsv.virtualspace.apps.VirtualApp;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Tracks virtual runtime sessions at the LSV layer.
 *
 * This is a lifecycle registry, not a process-injection mechanism.
 */
public class VirtualProcessManager {
    private final Set<String> runningPackages =
        Collections.synchronizedSet(new HashSet<String>());

    public boolean markStarted(VirtualApp app) {
        if (app == null) {
            return false;
        }
        return runningPackages.add(app.getPackageName());
    }

    public boolean markStopped(VirtualApp app) {
        if (app == null) {
            return false;
        }
        return runningPackages.remove(app.getPackageName());
    }

    public boolean isRunning(VirtualApp app) {
        return app != null && runningPackages.contains(app.getPackageName());
    }

    public void stopAll() {
        runningPackages.clear();
    }
}
