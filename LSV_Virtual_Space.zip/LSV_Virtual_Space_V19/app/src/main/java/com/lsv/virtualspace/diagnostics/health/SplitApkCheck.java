package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class SplitApkCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "SPLIT_APKS"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = true;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
