package com.lsv.virtualspace.guest.runtime;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.res.Resources;
import dalvik.system.DexClassLoader;

import com.lsv.virtualspace.apps.VirtualApp;

import com.lsv.virtualspace.virtual.VirtualCore;
import com.lsv.virtualspace.virtual.VirtualPackageManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

/** Shared package-agnostic loader for non-Activity guest components. */
public final class GuestComponentEnvironment {
    private final VirtualApp app;
    private final PackageInfo packageInfo;
    private final ApplicationInfo applicationInfo;
    private final DexClassLoader classLoader;
    private final GuestContext context;

    private GuestComponentEnvironment(VirtualApp app, PackageInfo info,
            ApplicationInfo ai, DexClassLoader loader, GuestContext guestContext) {
        this.app = app;
        this.packageInfo = info;
        this.applicationInfo = ai;
        this.classLoader = loader;
        this.context = guestContext;
    }

    public static GuestComponentEnvironment open(Context host, String packageName) throws Exception {
        VirtualCore core = VirtualCore.get();
        VirtualApp app = com.lsv.virtualspace.virtual.VirtualAppLookup.find(
            core.getAppRepository(), packageName);
        if (app == null) throw new IllegalStateException("Virtual app not found: " + packageName);

        VirtualPackageManager pm = core.getRuntimeController().getPackageManager();
        PackageInfo info = pm.getPackageInfo(app);
        if (info == null || info.applicationInfo == null) {
            throw new IllegalStateException("Guest package metadata unavailable");
        }

        ApplicationInfo ai = info.applicationInfo;
        ai.sourceDir = app.getApkPath();
        ai.publicSourceDir = app.getApkPath();
        ai.dataDir = app.getDataPath();

        File data = new File(app.getDataPath());
        data.mkdirs();
        File nativeDir = new File(data, "native-libs");
        try {
            GuestNativeLibraryExtractor.extract(app.getApkPaths(), nativeDir);
            ai.nativeLibraryDir = nativeDir.getAbsolutePath();
        } catch (Throwable ignored) { }

        File codeDir = new File(data, "code-cache");
        File apkDir = new File(codeDir, "apk");
        codeDir.mkdirs();
        apkDir.mkdirs();
        StringBuilder dexPath = new StringBuilder();
        List<String> paths = app.getApkPaths();
        for (String path : paths) {
            File source = new File(path);
            File target = new File(apkDir, source.getName());
            if (!target.exists() || target.length() != source.length()) copy(source, target);
            if (dexPath.length() > 0) dexPath.append(File.pathSeparator);
            dexPath.append(target.getAbsolutePath());
        }
        DexClassLoader loader = new DexClassLoader(dexPath.toString(),
            codeDir.getAbsolutePath(), nativeDir.getAbsolutePath(), host.getClassLoader());
        Resources resources = GuestResourceLoader.create(host, paths);
        GuestContext guestContext = new GuestContext(host, packageName, ai, resources,
            resources.getAssets(), loader, data, ai.theme);
        return new GuestComponentEnvironment(app, info, ai, loader, guestContext);
    }

    private static void copy(File source, File target) throws Exception {
        FileInputStream in = new FileInputStream(source);
        FileOutputStream out = new FileOutputStream(target);
        try {
            byte[] buffer = new byte[32768];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        } finally {
            in.close();
            out.close();
        }
    }

    public VirtualApp getApp() { return app; }
    public PackageInfo getPackageInfo() { return packageInfo; }
    public ApplicationInfo getApplicationInfo() { return applicationInfo; }
    public DexClassLoader getClassLoader() { return classLoader; }
    public GuestContext getContext() { return context; }
}
