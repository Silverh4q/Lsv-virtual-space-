package com.lsv.virtualspace.engine;
import android.content.Context;
import com.lsv.virtualspace.virtual.GuestExecutionCapability;
import com.lsv.virtualspace.virtual.GuestLaunchInfo;
/** Converts prepared guest metadata into a capability-gated execution plan. */
public final class GuestExecutionPlanner {
    private final Context context;
    public GuestExecutionPlanner(Context c){context=c.getApplicationContext();}
    public GuestExecutionPlan plan(GuestLaunchInfo info){
        if(info==null)return new GuestExecutionPlan("","","","",false,"No guest launch information");
        // The current project intentionally has no process/Binder virtualization backend.
        GuestExecutionCapability cap=new GuestExecutionCapability(false,"Real guest process/Binder backend is not enabled in this build.");
        return new GuestExecutionPlan(info.getPackageName(),info.getActivityName(),info.getApkPath(),info.getDataPath(),cap.isSupported(),cap.getReason());
    }
}
