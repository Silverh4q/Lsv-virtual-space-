package com.lsv.virtualspace.security;
public final class GuestSecurityPolicy {
    public boolean allowNetwork(String packageName){return true;}
    public boolean allowExternalStorage(String packageName){return false;}
    public boolean allowUnknownSources(String packageName){return false;}
    public boolean allowDebuggableGuest(String packageName){return false;}
    public boolean allows(String packageName,String capability){
        if("network".equals(capability))return allowNetwork(packageName);
        if("external_storage".equals(capability))return allowExternalStorage(packageName);
        if("unknown_sources".equals(capability))return allowUnknownSources(packageName);
        if("debuggable".equals(capability))return allowDebuggableGuest(packageName);
        return false;
    }
}
