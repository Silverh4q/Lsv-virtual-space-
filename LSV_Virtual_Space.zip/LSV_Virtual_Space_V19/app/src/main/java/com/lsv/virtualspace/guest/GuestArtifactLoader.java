package com.lsv.virtualspace.guest;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;

import dalvik.system.DexClassLoader;

import java.lang.reflect.Method;

/**
 * Loads an imported APK's dex/resources as guest artifacts. This class does
 * not start the guest or install anything into Android's real PackageManager.
 */
public class GuestArtifactLoader {
    private final Context hostContext;

    public GuestArtifactLoader(Context context) {
        hostContext = context.getApplicationContext();
    }

    public DexClassLoader createClassLoader(String apkPath, String dataPath) {
        String optimized = dataPath + "/dex";
        java.io.File dir = new java.io.File(optimized);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        java.io.File codeDir = new java.io.File(dataPath, "readonly-code");
        if (!codeDir.exists()) codeDir.mkdirs();
        java.io.File source = new java.io.File(apkPath);
        java.io.File staged = new java.io.File(codeDir, source.getName());
        try {
            if (!staged.exists() || staged.length() != source.length()) {
                java.io.FileInputStream in = new java.io.FileInputStream(source);
                java.io.FileOutputStream out = new java.io.FileOutputStream(staged);
                try {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                } finally { in.close(); out.close(); }
            }
            staged.setWritable(false, false);
            staged.setReadable(true, false);
        } catch (Exception ignored) {
            staged = source;
        }
        return new DexClassLoader(
            staged.getAbsolutePath(),
            optimized,
            null,
            hostContext.getClassLoader()
        );
    }

    public Resources createResources(String apkPath) throws Exception {
        AssetManager assets = AssetManager.class.newInstance();
        Method addAssetPath = AssetManager.class.getMethod(
            "addAssetPath",
            String.class
        );
        addAssetPath.invoke(assets, apkPath);
        Resources host = hostContext.getResources();
        return new Resources(
            assets,
            host.getDisplayMetrics(),
            host.getConfiguration()
        );
    }
}
