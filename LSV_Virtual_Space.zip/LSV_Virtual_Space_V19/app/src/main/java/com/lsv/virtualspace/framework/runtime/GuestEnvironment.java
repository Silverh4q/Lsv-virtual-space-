package com.lsv.virtualspace.framework.runtime;

import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;

import java.io.File;

/** Immutable description of one virtual guest environment. */
public final class GuestEnvironment {
    private final String packageName;
    private final ApplicationInfo applicationInfo;
    private final Resources resources;
    private final ClassLoader classLoader;
    private final File dataDir;
    private final Application application;

    public GuestEnvironment(String packageName, ApplicationInfo applicationInfo,
                            Resources resources, ClassLoader classLoader,
                            File dataDir, Application application) {
        this.packageName = packageName;
        this.applicationInfo = applicationInfo;
        this.resources = resources;
        this.classLoader = classLoader;
        this.dataDir = dataDir;
        this.application = application;
    }

    public String getPackageName() { return packageName; }
    public ApplicationInfo getApplicationInfo() { return applicationInfo; }
    public Resources getResources() { return resources; }
    public ClassLoader getClassLoader() { return classLoader; }
    public File getDataDir() { return dataDir; }
    public Application getApplication() { return application; }
}
