package com.lsv.virtualspace.framework.bootstrap;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.framework.context.GuestContextSpec;

/** Stage 111-130 preparation coordinator for guest code/resources/context boundaries. */
public final class GuestRuntimePreparer {
    private final Context context;
    private final GuestBootstrapCoordinator coordinator;

    public GuestRuntimePreparer(Context context) {
        this.context = context.getApplicationContext();
        this.coordinator = new GuestBootstrapCoordinator(this.context);
    }

    public GuestRuntimePreparation prepare(VirtualApp app) {
        GuestBootstrapPlan plan = coordinator.prepare(app);
        GuestContextSpec spec = coordinator.prepareContext(app);
        if (plan == null || spec == null) return null;
        return new GuestRuntimePreparation(plan, spec);
    }
}
