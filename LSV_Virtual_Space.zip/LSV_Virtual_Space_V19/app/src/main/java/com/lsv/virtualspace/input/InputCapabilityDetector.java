package com.lsv.virtualspace.input;
import android.content.Context; import android.view.InputDevice;
public final class InputCapabilityDetector {
    public GuestInputProfile detect(Context c){
        boolean pad=false,mouse=false; int max=1; int[] ids=InputDevice.getDeviceIds();
        for(int i=0;i<ids.length;i++){InputDevice d=InputDevice.getDevice(ids[i]); if(d==null)continue; int s=d.getSources(); if((s&InputDevice.SOURCE_GAMEPAD)!=0)pad=true; if((s&InputDevice.SOURCE_MOUSE)!=0)mouse=true;}
        return new GuestInputProfile(true,pad,mouse,max);
    }
}
