package com.lsv.virtualspace.diagnostics;

import android.content.Context;

/** Captures guest Java crashes and preserves the original handler afterwards. */
public final class GuestUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
    private final GuestDiagnosticController diagnostics;
    private final Thread.UncaughtExceptionHandler previous;

    private GuestUncaughtExceptionHandler(Context context, Thread.UncaughtExceptionHandler previous) {
        diagnostics = GuestDiagnosticController.get(context);
        this.previous = previous;
    }

    public static void install(Context context) {
        Thread thread = Thread.currentThread();
        Thread.UncaughtExceptionHandler current = thread.getUncaughtExceptionHandler();
        if (current instanceof GuestUncaughtExceptionHandler) return;
        thread.setUncaughtExceptionHandler(new GuestUncaughtExceptionHandler(context, current));
    }

    @Override public void uncaughtException(Thread thread, Throwable error) {
        try {
            diagnostics.fail("JAVA_EXCEPTION", error);
        } catch (Throwable ignored) { }
        if (previous != null) previous.uncaughtException(thread, error);
    }
}
