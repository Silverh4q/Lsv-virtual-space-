package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public interface GuestHealthCheck {
    String getName();
    boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception;
}
