package com.lsv.virtualspace.nativecode;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;

import java.io.File;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Stages guest .so files by ABI without loading them into the host process. */
public final class GuestNativeStage {
    private final Context context;

    public GuestNativeStage(Context context) { this.context = context.getApplicationContext(); }

    public File stage(VirtualApp app, String abi) throws Exception {
        if (app == null || abi == null) throw new Exception("Missing guest or ABI");
        File root = new File(app.getDataPath(), "native/" + abi);
        root.mkdirs();
        ZipFile zip = new ZipFile(app.getApkPath());
        try {
            String prefix = "lib/" + abi + "/";
            java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.isDirectory() || !entry.getName().startsWith(prefix)) continue;
                String name = entry.getName().substring(prefix.length());
                if (name.length() == 0 || name.indexOf('/') >= 0) continue;
                File out = new File(root, name);
                copy(zip.getInputStream(entry), new FileOutputStream(out));
            }
        } finally {
            zip.close();
        }
        return root;
    }

    private void copy(java.io.InputStream in, FileOutputStream out) throws Exception {
        try {
            byte[] buffer = new byte[16384];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            out.flush();
        } finally {
            in.close();
            out.close();
        }
    }
}
