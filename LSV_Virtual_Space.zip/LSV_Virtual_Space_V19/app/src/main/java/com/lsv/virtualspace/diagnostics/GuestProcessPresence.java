package com.lsv.virtualspace.diagnostics;

import android.content.Context;
import android.os.Process;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/** File-backed guest-process presence marker used when process enumeration is restricted. */
public final class GuestProcessPresence {
    private GuestProcessPresence() { }

    public static void touch(Context context, String packageName) {
        if (context == null) return;
        try {
            File dir = new File(context.getFilesDir(), "virtual/diagnostics/process");
            if (!dir.exists()) dir.mkdirs();
            Properties p = new Properties();
            p.setProperty("pid", String.valueOf(Process.myPid()));
            p.setProperty("process", processName(context));
            p.setProperty("time", String.valueOf(System.currentTimeMillis()));
            if (packageName != null) p.setProperty("package", packageName);
            File file = new File(dir, "guest_presence.properties");
            File tmp = new File(dir, "guest_presence.tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            p.store(out, "LSV guest process presence");
            out.close();
            if (file.exists()) file.delete();
            tmp.renameTo(file);
        } catch (Throwable ignored) { }
    }

    public static boolean isFresh(Context context, String expectedProcess, long maxAgeMs) {
        Properties p = read(context);
        if (p == null) return false;
        String process = p.getProperty("process", "");
        long time;
        try { time = Long.parseLong(p.getProperty("time", "0")); }
        catch (Throwable ignored) { return false; }
        if (expectedProcess != null && expectedProcess.length() > 0 && !expectedProcess.equals(process)) return false;
        return time > 0L && System.currentTimeMillis() - time <= maxAgeMs;
    }

    public static void clear(Context context) {
        if (context == null) return;
        try {
            File file = new File(new File(context.getFilesDir(), "virtual/diagnostics/process"), "guest_presence.properties");
            if (file.exists()) file.delete();
        } catch (Throwable ignored) { }
    }

    private static Properties read(Context context) {
        if (context == null) return null;
        File file = new File(new File(context.getFilesDir(), "virtual/diagnostics/process"), "guest_presence.properties");
        if (!file.exists()) return null;
        try {
            Properties p = new Properties();
            FileInputStream in = new FileInputStream(file);
            p.load(in);
            in.close();
            return p;
        } catch (Throwable ignored) { return null; }
    }

    private static String processName(Context context) {
        String value = GuestApiCompatibility.processName();
        return value == null || value.length() == 0 ? context.getPackageName() : value;
    }
}
