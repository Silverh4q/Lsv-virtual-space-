package com.lsv.virtualspace.runtime;

import android.content.res.Configuration;

/** Captures host configuration changes that a future guest runtime may consume. */
public final class GuestConfigurationBridge {
    private Configuration last;

    public synchronized void update(Configuration configuration) {
        if (configuration == null) return;
        last = new Configuration(configuration);
    }

    public synchronized Configuration snapshot() {
        return last == null ? null : new Configuration(last);
    }
}
