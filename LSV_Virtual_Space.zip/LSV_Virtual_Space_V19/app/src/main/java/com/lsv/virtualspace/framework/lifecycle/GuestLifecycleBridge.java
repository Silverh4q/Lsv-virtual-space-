package com.lsv.virtualspace.framework.lifecycle;

import com.lsv.virtualspace.framework.packages.GuestPackageSessionManager;

public final class GuestLifecycleBridge {
    private final GuestPackageSessionManager sessions;
    public GuestLifecycleBridge(GuestPackageSessionManager sessions) { this.sessions = sessions; }
    public void onCreate(String packageName) { sessions.open(packageName); }
    public void onStop(String packageName) { sessions.close(packageName); }
    public boolean isActive(String packageName) { return sessions.get(packageName) != null && sessions.get(packageName).isActive(); }
}
