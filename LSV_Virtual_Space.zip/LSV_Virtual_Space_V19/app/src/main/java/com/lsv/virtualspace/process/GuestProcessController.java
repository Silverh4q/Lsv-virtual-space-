package com.lsv.virtualspace.process;

import android.content.Context;
import android.content.Intent;

/** Starts/stops the dedicated LSV guest host process boundary. */
public final class GuestProcessController {
    private final Context context;
    public GuestProcessController(Context context) { this.context = context.getApplicationContext(); }

    public boolean prepare(String packageName, String apkPath) {
        return prepare(packageName, apkPath, null);
    }

    public boolean prepare(String packageName, String apkPath, String component) {
        if (packageName == null || apkPath == null) return false;
        Intent i = new Intent(context, GuestProcessService.class);
        i.setAction(GuestProcessCommand.ACTION_PREPARE);
        i.putExtra(GuestProcessCommand.EXTRA_PACKAGE, packageName);
        i.putExtra(GuestProcessCommand.EXTRA_APK, apkPath);
        if (component != null) i.putExtra(GuestProcessCommand.EXTRA_COMPONENT, component);
        try {
            context.startService(i);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public void stop() {
        Intent i = new Intent(context, GuestProcessService.class);
        i.setAction(GuestProcessCommand.ACTION_STOP);
        context.startService(i);
    }
}
