package com.lsv.virtualspace.framework.compat;

import android.os.Build;

/** Android-version capabilities used to choose safe virtualization fallbacks. */
public final class GuestApiCompatibility {
    private GuestApiCompatibility() {}

    public static int sdk() { return Build.VERSION.SDK_INT; }
    public static boolean hasScopedStorage() { return Build.VERSION.SDK_INT >= 29; }
    public static boolean hasBackgroundActivityLimits() { return Build.VERSION.SDK_INT >= 29; }
    public static boolean hasNotificationRuntimePermission() { return Build.VERSION.SDK_INT >= 33; }
    public static boolean hasForegroundServiceTypeRules() { return Build.VERSION.SDK_INT >= 28; }
    public static boolean hasHiddenApiRestrictions() { return Build.VERSION.SDK_INT >= 28; }

    public static String summary() {
        return "API " + Build.VERSION.SDK_INT +
            ": scopedStorage=" + hasScopedStorage() +
            ", backgroundActivityLimits=" + hasBackgroundActivityLimits() +
            ", notificationRuntimePermission=" + hasNotificationRuntimePermission() +
            ", hiddenApiRestrictions=" + hasHiddenApiRestrictions();
    }
}
