package com.lsv.virtualspace.framework.system;

import android.content.Context;

/** Stable names for system-service mediation. */
public final class GuestSystemServiceName {
    public static final String PACKAGE = "package";
    public static final String ACTIVITY = Context.ACTIVITY_SERVICE;
    public static final String WINDOW = Context.WINDOW_SERVICE;
    public static final String NOTIFICATION = Context.NOTIFICATION_SERVICE;
    public static final String CLIPBOARD = Context.CLIPBOARD_SERVICE;
    public static final String LOCATION = Context.LOCATION_SERVICE;
    public static final String CONNECTIVITY = Context.CONNECTIVITY_SERVICE;
    public static final String POWER = Context.POWER_SERVICE;
    public static final String ACCOUNT = Context.ACCOUNT_SERVICE;
    public static final String ALARM = Context.ALARM_SERVICE;
    public static final String VIBRATOR = Context.VIBRATOR_SERVICE;
    public static final String SENSOR = Context.SENSOR_SERVICE;
    public static final String TELEPHONY = Context.TELEPHONY_SERVICE;
    public static final String AUDIO = Context.AUDIO_SERVICE;
    public static final String INPUT = Context.INPUT_METHOD_SERVICE;
    private GuestSystemServiceName() { }
}
