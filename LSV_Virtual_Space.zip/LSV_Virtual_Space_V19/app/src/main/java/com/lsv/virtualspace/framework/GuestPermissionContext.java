package com.lsv.virtualspace.framework;

import java.util.HashSet;
import java.util.Set;

/** Per-guest permission decision context. Host permissions are never granted implicitly. */
public final class GuestPermissionContext {
    private final Set<String> allowed = new HashSet<String>();

    public void allow(String permission) { if (permission != null) allowed.add(permission); }
    public boolean isAllowed(String permission) { return permission != null && allowed.contains(permission); }
    public void clear() { allowed.clear(); }
}
