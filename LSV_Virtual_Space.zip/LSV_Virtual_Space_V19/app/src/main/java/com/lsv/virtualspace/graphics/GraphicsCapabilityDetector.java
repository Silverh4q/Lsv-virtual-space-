package com.lsv.virtualspace.graphics;
import android.app.ActivityManager; import android.content.Context; import android.content.pm.ConfigurationInfo;
public final class GraphicsCapabilityDetector {
    public GuestGraphicsProfile detect(Context c){
        ActivityManager am=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE); ConfigurationInfo i=am==null?null:am.getDeviceConfigurationInfo();
        int g=0; boolean vk=false; if(i!=null){g=i.reqGlEsVersion>=0x20000?2:1; vk=i.reqGlEsVersion>=0x30000;}
        return new GuestGraphicsProfile(vk?GuestGraphicsMode.AUTO:GuestGraphicsMode.COMPATIBILITY,g,vk);
    }
}
