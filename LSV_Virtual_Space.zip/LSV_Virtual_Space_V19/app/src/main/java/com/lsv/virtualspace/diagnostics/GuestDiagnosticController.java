package com.lsv.virtualspace.diagnostics;

import android.content.Context;
import android.os.Build;
import android.os.Process;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Central guest diagnostic transaction. Thread-safe and package-agnostic. */
public final class GuestDiagnosticController {
    private static GuestDiagnosticController instance;
    private final GuestDiagnosticStore store;
    private GuestDiagnosticReport active;
    private final List<GuestDiagnosticEvent> pending = new ArrayList<GuestDiagnosticEvent>();
    private long lastCheckpoint;
    private String virtualUid;
    private String apkPath;

    private GuestDiagnosticController(Context context) {
        store = new GuestDiagnosticStore(context.getApplicationContext());
    }

    public static synchronized GuestDiagnosticController get(Context context) {
        if (instance == null) instance = new GuestDiagnosticController(context);
        return instance;
    }

    /** Starts a transaction only when this process does not already own the same guest transaction.
     * This preserves the host preflight timeline after the :guest process adopts its seed.
     */
    public synchronized void beginIfNeeded(String packageName, String component) {
        if (active != null && packageName != null && packageName.equals(active.packageName)) {
            if (component != null && (active.component == null || component.equals(active.component))) {
                return;
            }
        }
        begin(packageName, component);
    }

    public synchronized void begin(String packageName, String component) {
        active = new GuestDiagnosticReport();
        active.id = UUID.randomUUID().toString();
        active.packageName = packageName;
        active.component = component;
        active.pid = Process.myPid();
        active.processName = processName();
        active.androidVersion = android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")";
        active.device = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
        active.abis = joinAbis();
        active.startedAt = System.currentTimeMillis();
        active.stage = GuestRuntimeStage.LAUNCH_REQUESTED;
        active.kind = "RUNNING";
        active.finishedAt = 0L;
        virtualUid = null;
        apkPath = null;
        pending.clear();
        store.saveTransactionSeed(active);
        eventLocked(GuestRuntimeStage.LAUNCH_REQUESTED, "transaction started");
        checkpointLocked();
    }

    public synchronized void stage(String stage, String detail) {
        if (active == null) return;
        active.stage = stage;
        eventLocked(stage, detail == null ? "" : detail);
        checkpointLocked();
    }

    public synchronized void success(String detail) {
        if (active == null) return;
        stage(GuestRuntimeStage.COMPLETED, detail);
        active.finishedAt = System.currentTimeMillis();
        active.kind = "RUNNING";
        checkpointLocked();
        store.save(active);
        store.clearTransactionSeed();
    }

    public synchronized void fail(String kind, Throwable error) {
        if (active == null) {
            active = new GuestDiagnosticReport();
            active.id = UUID.randomUUID().toString();
            active.pid = Process.myPid();
            active.processName = processName();
            active.androidVersion = android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")";
            active.device = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
            active.abis = joinAbis();
            active.startedAt = System.currentTimeMillis();
        }
        active.kind = kind == null ? "UNKNOWN_FAILURE" : kind;
        active.exceptionClass = error == null ? null : error.getClass().getName();
        active.message = error == null ? null : GuestDiagnosticReport.stack(error);
        active.stage = GuestRuntimeStage.FAILED;
        eventLocked(GuestRuntimeStage.FAILED, error == null ? "unknown failure" : describe(error));
        active.finishedAt = System.currentTimeMillis();
        checkpointLocked();
        store.save(active);
        store.clearTransactionSeed();
    }

    public synchronized void adoptPendingTransaction() {
        if (active != null) return;
        GuestDiagnosticReport seed = store.readTransactionSeed();
        if (seed == null || seed.packageName == null) return;
        active = seed;
        active.pid = android.os.Process.myPid();
        active.processName = processName();
        active.androidVersion = android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")";
        active.device = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
        active.abis = joinAbis();
        active.stage = GuestRuntimeStage.PROCESS_ATTACHED;
        active.kind = "RUNNING";
        eventLocked(GuestRuntimeStage.PROCESS_ATTACHED, "guest process adopted transaction");
        checkpointLocked();
    }

    public synchronized void setRuntimeMetadata(String apkPathValue, String virtualUidValue) {
        apkPath = apkPathValue;
        virtualUid = virtualUidValue;
        if (active != null) {
            active.apkPath = apkPathValue;
            active.virtualUid = virtualUidValue;
            checkpointLocked();
        }
    }

    public synchronized void heartbeat(String detail) {
        if (active == null) return;
        active.lastHeartbeat = System.currentTimeMillis();
        eventLocked(GuestRuntimeStage.PROCESS_HEARTBEAT, detail == null ? "alive" : detail);
        checkpointLocked();
    }

    public synchronized String getActivePackage() {
        return active == null ? null : active.packageName;
    }

    public synchronized String getActiveProcessName() {
        return active == null ? null : active.processName;
    }

    public synchronized long getLastCheckpoint() { return lastCheckpoint; }

    private void checkpointLocked() {
        if (active == null) return;
        lastCheckpoint = System.currentTimeMillis();
        active.lastCheckpoint = lastCheckpoint;
        active.virtualUid = virtualUid;
        active.apkPath = apkPath;
        try { store.saveCheckpoint(active); } catch (Throwable ignored) { }
    }

    public synchronized String getLastReport(String packageName) {
        return store.readLatest(packageName);
    }

    public synchronized GuestDiagnosticReport snapshot() {
        if (active == null) return null;
        GuestDiagnosticReport copy = new GuestDiagnosticReport();
        copy.id = active.id; copy.packageName = active.packageName;
        copy.component = active.component; copy.pid = active.pid;
        copy.processName = active.processName; copy.stage = active.stage;
        copy.kind = active.kind; copy.exceptionClass = active.exceptionClass;
        copy.message = active.message; copy.startedAt = active.startedAt;
        copy.finishedAt = active.finishedAt;
        copy.androidVersion = active.androidVersion;
        copy.device = active.device;
        copy.abis = active.abis;
        copy.lastHeartbeat = active.lastHeartbeat;
        copy.lastCheckpoint = active.lastCheckpoint;
        copy.virtualUid = active.virtualUid;
        copy.apkPath = active.apkPath;
        copy.events.addAll(active.events);
        return copy;
    }

    public synchronized GuestDiagnosticStore getStore() { return store; }

    private void eventLocked(String stage, String detail) {
        if (active == null) return;
        active.events.add(new GuestDiagnosticEvent(System.currentTimeMillis(), stage,
            detail, Thread.currentThread().getName()));
        while (active.events.size() > 160) active.events.remove(0);
    }

    private static String describe(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        String message = current.getMessage();
        return current.getClass().getName() + (message == null ? "" : ": " + message);
    }

    private static String joinAbis() {
        String[] values = android.os.Build.SUPPORTED_ABIS;
        if (values == null) return "";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) out.append(", ");
            out.append(values[i]);
        }
        return out.toString();
    }

    private static String processName() {
        return GuestApiCompatibility.processName();
    }
}
