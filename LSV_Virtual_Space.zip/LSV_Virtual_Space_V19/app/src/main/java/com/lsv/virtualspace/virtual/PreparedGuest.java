package com.lsv.virtualspace.virtual;

import com.lsv.virtualspace.apps.VirtualApp;

/** Complete preparation result used by the future execution backend. */
public class PreparedGuest {
    private final VirtualApp app;
    private final GuestLaunchInfo launchInfo;
    private final GuestExecutionCapability capability;

    public PreparedGuest(
        VirtualApp app,
        GuestLaunchInfo launchInfo,
        GuestExecutionCapability capability
    ) {
        this.app = app;
        this.launchInfo = launchInfo;
        this.capability = capability;
    }

    public VirtualApp getApp() { return app; }
    public GuestLaunchInfo getLaunchInfo() { return launchInfo; }
    public GuestExecutionCapability getCapability() { return capability; }
}
