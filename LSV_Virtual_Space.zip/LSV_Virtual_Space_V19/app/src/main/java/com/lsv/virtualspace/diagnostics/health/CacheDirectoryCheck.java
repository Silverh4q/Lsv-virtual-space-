package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class CacheDirectoryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "CACHE_DIRECTORY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = context != null && context.getCacheDir() != null && context.getCacheDir().isDirectory();
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
