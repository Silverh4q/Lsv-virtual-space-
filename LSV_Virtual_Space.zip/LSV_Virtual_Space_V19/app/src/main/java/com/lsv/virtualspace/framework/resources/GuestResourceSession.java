package com.lsv.virtualspace.framework.resources;

import android.content.res.Resources;

/** Holds guest Resources associated with one virtual package session. */
public final class GuestResourceSession {
    private final String packageName;
    private final Resources resources;

    public GuestResourceSession(String packageName, Resources resources) {
        this.packageName = packageName;
        this.resources = resources;
    }

    public String getPackageName() { return packageName; }
    public Resources getResources() { return resources; }
}
