package com.lsv.virtualspace.profiles;
import com.lsv.virtualspace.graphics.GuestGraphicsProfile; import com.lsv.virtualspace.performance.GuestPerformanceProfile;
public final class GameProfile {
    private final String id,name; private final GuestGraphicsProfile graphics; private final GuestPerformanceProfile performance;
    public GameProfile(String i,String n,GuestGraphicsProfile g,GuestPerformanceProfile p){id=i;name=n;graphics=g;performance=p;}
    public String getId(){return id;} public String getName(){return name;} public GuestGraphicsProfile getGraphics(){return graphics;} public GuestPerformanceProfile getPerformance(){return performance;}
}
