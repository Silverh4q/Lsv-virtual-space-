package com.lsv.virtualspace.virtual;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.apps.VirtualAppRepository;

import java.util.List;

public final class VirtualAppLookup {
    private VirtualAppLookup() { }

    public static VirtualApp find(VirtualAppRepository repository, String packageName) {
        if (repository == null || packageName == null) return null;
        List<VirtualApp> apps = repository.getApps();
        for (VirtualApp app : apps) {
            if (packageName.equals(app.getPackageName())) return app;
        }
        return null;
    }
}
