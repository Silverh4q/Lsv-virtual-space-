package com.lsv.virtualspace.google;

import android.content.Context;

/**
 * Google component compatibility report. It never bundles or copies
 * proprietary Google APKs and never claims that host GMS is guest GMS.
 */
public class GoogleGuestCompatibility {
    private final Context context;

    public GoogleGuestCompatibility(Context context) {
        this.context = context.getApplicationContext();
    }

    public String report() {
        boolean gms = installed("com.google.android.gms");
        boolean store = installed("com.android.vending");
        return "Host Google Play services: " + gms + "\n" +
               "Host Play Store: " + store + "\n" +
               "Guest Play integration: requires a compatible virtualization backend.\n" +
               "Google APKs are not copied into the guest by LSV.";
    }

    private boolean installed(String packageName) {
        try {
            context.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
