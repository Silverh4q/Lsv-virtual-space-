package com.lsv.virtualspace.framework;

public final class GuestTaskRecord {
    private final String packageName;
    private final String componentName;
    private final long createdAt;
    private boolean foreground;

    public GuestTaskRecord(String packageName, String componentName) {
        this.packageName = packageName;
        this.componentName = componentName;
        this.createdAt = System.currentTimeMillis();
    }

    public String getPackageName() { return packageName; }
    public String getComponentName() { return componentName; }
    public long getCreatedAt() { return createdAt; }
    public boolean isForeground() { return foreground; }
    public void setForeground(boolean value) { foreground = value; }
}
