package com.lsv.virtualspace.framework.window;

import android.content.Context;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import com.lsv.virtualspace.framework.system.GuestSystemServiceName;
import com.lsv.virtualspace.framework.system.GuestSystemServiceFacade;

/**
 * Runtime WindowManager facade. WindowManager is an interface, so a dynamic
 * proxy lets us remain source-compatible across Android API levels while the
 * framework records guest ownership for every window operation.
 */
public final class GuestWindowManagerProxy implements InvocationHandler {
    private final Context hostContext;
    private final WindowManager delegate;
    private final String packageName;
    private final GuestSystemServiceFacade services;
    private static final GuestWindowSessionRegistry REGISTRY = new GuestWindowSessionRegistry();

    private GuestWindowManagerProxy(Context hostContext, WindowManager delegate,
                                    String packageName, GuestSystemServiceFacade services) {
        this.hostContext = hostContext;
        this.delegate = delegate;
        this.packageName = packageName;
        this.services = services;
    }

    public static WindowManager create(Context hostContext, WindowManager delegate,
                                       String packageName, GuestSystemServiceFacade services) {
        if (delegate == null) return null;
        if (packageName == null || services == null) return delegate;
        return (WindowManager) Proxy.newProxyInstance(
            WindowManager.class.getClassLoader(),
            new Class<?>[] { WindowManager.class },
            new GuestWindowManagerProxy(hostContext, delegate, packageName, services));
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String name = method.getName();
        if ("addView".equals(name) && args != null && args.length >= 2 && args[0] instanceof View) {
            return addView((View) args[0], (LayoutParams) args[1]);
        }
        if ("updateViewLayout".equals(name) && args != null && args.length >= 2 && args[0] instanceof View) {
            Object result = method.invoke(delegate, args);
            record("update", (View) args[0]);
            return result;
        }
        if ("removeView".equals(name) && args != null && args.length >= 1 && args[0] instanceof View) {
            Object result = method.invoke(delegate, args);
            record("remove", (View) args[0]);
            REGISTRY.close(packageName, "view:" + Integer.toHexString(System.identityHashCode(args[0])));
            return result;
        }
        if ("removeViewImmediate".equals(name) && args != null && args.length >= 1 && args[0] instanceof View) {
            Object result = method.invoke(delegate, args);
            record("remove_immediate", (View) args[0]);
            REGISTRY.close(packageName, "view:" + Integer.toHexString(System.identityHashCode(args[0])));
            return result;
        }
        return method.invoke(delegate, args);
    }

    private boolean isOverlayType(int type) {
        // TYPE_APPLICATION_OVERLAY is 2038 on API 26+. Keep the numeric value
        // here so older AIDE Android stubs do not need the newer constant.
        return type == 2038;
    }

    private Object addView(View view, LayoutParams original) throws Throwable {
        LayoutParams lp = original;
        if (lp != null && isOverlayType(lp.type)) {
            String allowed = services.getState().get(packageName, GuestSystemServiceName.WINDOW, "overlayAllowed");
            if (!"true".equals(allowed)) {
                throw new SecurityException("LSV virtual overlay permission denied for " + packageName);
            }
        }
        if (lp != null) {
            lp = new LayoutParams();
            lp.copyFrom(original);
            // The kernel/window system sees LSV as the caller. Never claim a
            // different package at the Binder boundary; guest ownership is
            // maintained by the virtual framework state instead.
            lp.packageName = hostContext.getPackageName();
        }
        delegate.addView(view, lp);
        record("add", view, lp);
        return null;
    }

    private void record(String operation, View view) { record(operation, view, null); }

    private void record(String operation, View view, LayoutParams params) {
        try {
            com.lsv.virtualspace.diagnostics.GuestDiagnosticController.get(hostContext).stage(
                com.lsv.virtualspace.diagnostics.GuestRuntimeStage.WINDOW_CREATE,
                operation + "/" + packageName);
            android.os.Bundle b = new android.os.Bundle();
            b.putString("session", "view:" + Integer.toHexString(System.identityHashCode(view)));
            b.putString("operation", operation);
            b.putString("package", packageName);
            android.view.WindowManager.LayoutParams lp = params;
            if (lp == null) lp = new android.view.WindowManager.LayoutParams();
            b.putInt("width", view.getWidth());
            b.putInt("height", view.getHeight());
            b.putInt("type", lp.type);
            android.os.IBinder token = view.getWindowToken();
            b.putString("token", token == null ? null : token.toString());
            REGISTRY.open(packageName, b.getString("session"), token == null ? null : token.toString(), view.getWidth(), view.getHeight(), lp.type);
            services.dispatch(packageName, GuestSystemServiceName.WINDOW, "create_session", b);
            b.putBoolean("visible", true);
            services.dispatch(packageName, GuestSystemServiceName.WINDOW, "set_visible", b);
            REGISTRY.setVisible(packageName, b.getString("session"), true);
        } catch (Throwable ignored) { }
    }
}
