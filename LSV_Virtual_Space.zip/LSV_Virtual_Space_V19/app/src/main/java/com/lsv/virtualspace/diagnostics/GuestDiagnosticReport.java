package com.lsv.virtualspace.diagnostics;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

/** Crash/runtime report persisted independently from the guest process. */
public final class GuestDiagnosticReport {
    public String id;
    public String packageName;
    public String component;
    public int pid;
    public String processName;
    public String stage;
    public String kind;
    public String exceptionClass;
    public String message;
    public long startedAt;
    public long finishedAt;
    public String androidVersion;
    public String device;
    public String abis;
    public String virtualUid;
    public String apkPath;
    public long lastHeartbeat;
    public long lastCheckpoint;
    public final List<GuestDiagnosticEvent> events = new ArrayList<GuestDiagnosticEvent>();

    public String toText() {
        StringBuilder out = new StringBuilder();
        out.append("LSV GUEST RUNTIME REPORT\n");
        out.append("========================\n");
        line(out, "Report ID", id);
        line(out, "Package", packageName);
        line(out, "Component", component);
        line(out, "Process", processName);
        line(out, "PID", String.valueOf(pid));
        line(out, "Kind", kind);
        line(out, "Stage", stage);
        line(out, "Exception", exceptionClass);
        line(out, "Message", message);
        line(out, "Started", String.valueOf(startedAt));
        line(out, "Finished", String.valueOf(finishedAt));
        line(out, "Android", androidVersion);
        line(out, "Device", device);
        line(out, "ABIs", abis);
        line(out, "Virtual UID", virtualUid);
        line(out, "APK", apkPath);
        line(out, "Last heartbeat", String.valueOf(lastHeartbeat));
        line(out, "Last checkpoint", String.valueOf(lastCheckpoint));
        out.append("\nTIMELINE\n--------\n");
        for (GuestDiagnosticEvent e : events) {
            out.append(e.time).append(" | ").append(e.stage).append(" | ")
                .append(e.thread).append(" | ").append(e.detail).append("\n");
        }
        return out.toString();
    }

    private static void line(StringBuilder out, String key, String value) {
        out.append(key).append(": ").append(value == null ? "<none>" : value).append("\n");
    }

    public static String stack(Throwable error) {
        if (error == null) return "";
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        error.printStackTrace(pw);
        pw.flush();
        return sw.toString();
    }
}
