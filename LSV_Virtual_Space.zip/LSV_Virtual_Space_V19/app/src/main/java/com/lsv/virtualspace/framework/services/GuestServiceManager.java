package com.lsv.virtualspace.framework.services;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import com.lsv.virtualspace.framework.binder.GuestBinderReply;
import com.lsv.virtualspace.guest.runtime.GuestComponentEnvironment;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;

import java.util.HashMap;
import java.util.Map;

/** Executes guest Service classes and owns their virtual lifecycle records. */
public final class GuestServiceManager {
    private static final String TAG = "LSV-GuestServiceMgr";
    private final android.content.Context hostContext;
    private final Map<String, Service> running = new HashMap<String, Service>();
    private final Map<String, Integer> bindings = new HashMap<String, Integer>();

    public GuestServiceManager(android.content.Context context) {
        hostContext = context.getApplicationContext();
    }

    public synchronized GuestBinderReply start(String packageName, String component, Intent guestIntent) {
        if (component == null) return GuestBinderReply.fail("Missing service component");
        String key = packageName + ":" + component;
        try {
            GuestDiagnosticController.get(hostContext).stage(GuestRuntimeStage.SERVICE_REQUEST, "start " + key);
            Service service = running.get(key);
            if (service == null) {
                GuestComponentEnvironment env = GuestComponentEnvironment.open(hostContext, packageName);
                Class<?> type = env.getClassLoader().loadClass(component);
                Object value = type.newInstance();
                if (!(value instanceof Service)) return GuestBinderReply.fail("Guest component is not a Service");
                service = (Service) value;
                service.onCreate();
                running.put(key, service);
            }
            int startId = nextStartId(key);
            GuestDiagnosticController.get(hostContext).stage(GuestRuntimeStage.SERVICE_REQUEST, "onStartCommand " + key);
            int result = service.onStartCommand(guestIntent == null ? new Intent() : new Intent(guestIntent), 0, startId);
            Bundle b = new Bundle();
            b.putInt("startId", startId);
            b.putInt("startResult", result);
            b.putBoolean("running", true);
            return GuestBinderReply.ok(b);
        } catch (Throwable error) {
            GuestDiagnosticController.get(hostContext).fail("GUEST_SERVICE_FAILURE", error);
            Log.e(TAG, "guest service start failed: " + key, error);
            return GuestBinderReply.fail(describe(error));
        }
    }

    public synchronized GuestBinderReply bind(String packageName, String component) {
        if (component == null) return GuestBinderReply.fail("Missing service component");
        String key = packageName + ":" + component;
        try {
            GuestDiagnosticController.get(hostContext).stage(GuestRuntimeStage.SERVICE_REQUEST, "start " + key);
            Service service = running.get(key);
            if (service == null) {
                GuestBinderReply started = start(packageName, component, new Intent());
                if (!started.isSuccess()) return started;
                service = running.get(key);
            }
            IBinder binder = service.onBind(new Intent().setClassName(packageName, component));
            Integer count = bindings.get(key);
            int next = count == null ? 1 : count + 1;
            bindings.put(key, next);
            Bundle b = new Bundle();
            b.putInt("bindingCount", next);
            b.putString("component", component);
            b.putBinder("binder", binder);
            return GuestBinderReply.ok(b);
        } catch (Throwable error) {
            Log.e(TAG, "guest service bind failed: " + key, error);
            return GuestBinderReply.fail(describe(error));
        }
    }

    public synchronized GuestBinderReply unbind(String packageName, String component) {
        String key = packageName + ":" + component;
        Integer count = bindings.get(key);
        if (count == null) return GuestBinderReply.fail("Service was not bound");
        int next = Math.max(0, count - 1);
        if (next == 0) bindings.remove(key); else bindings.put(key, next);
        Service service = running.get(key);
        if (next == 0 && service != null) {
            try { service.onUnbind(new Intent().setClassName(packageName, component)); } catch (Throwable ignored) { }
        }
        Bundle b = new Bundle();
        b.putInt("bindingCount", next);
        return GuestBinderReply.ok(b);
    }

    public synchronized void stop(String packageName, String component) {
        String key = packageName + ":" + component;
        Service service = running.remove(key);
        bindings.remove(key);
        if (service != null) {
            try { service.onDestroy(); } catch (Throwable error) { Log.e(TAG, "guest service destroy failed", error); }
        }
    }

    public synchronized int getBindingCount(String packageName, String component) {
        Integer value = bindings.get(packageName + ":" + component);
        return value == null ? 0 : value;
    }

    private int nextStartId(String key) {
        Integer value = bindings.get(key + ":start");
        int next = value == null ? 1 : value + 1;
        bindings.put(key + ":start", next);
        return next;
    }

    private String describe(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        String message = current.getMessage();
        return message == null || message.length() == 0 ? current.getClass().getSimpleName() : message;
    }
}
