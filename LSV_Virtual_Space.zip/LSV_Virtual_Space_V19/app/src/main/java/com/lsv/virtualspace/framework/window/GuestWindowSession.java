package com.lsv.virtualspace.framework.window;

/** Immutable snapshot of one guest-owned logical window session. */
public final class GuestWindowSession {
    private final String packageName;
    private final String id;
    private final String token;
    private final int width;
    private final int height;
    private final int type;
    private final long createdAt;
    private boolean visible;

    public GuestWindowSession(String packageName, String id, String token, int width, int height, int type) {
        this.packageName = packageName;
        this.id = id;
        this.token = token;
        this.width = width;
        this.height = height;
        this.type = type;
        this.createdAt = System.currentTimeMillis();
    }
    public String getPackageName() { return packageName; }
    public String getId() { return id; }
    public String getToken() { return token; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getType() { return type; }
    public long getCreatedAt() { return createdAt; }
    public boolean isVisible() { return visible; }
    public void setVisible(boolean value) { visible = value; }
}
