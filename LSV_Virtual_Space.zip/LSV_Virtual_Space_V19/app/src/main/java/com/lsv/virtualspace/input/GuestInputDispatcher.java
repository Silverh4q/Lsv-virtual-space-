package com.lsv.virtualspace.input;

import android.view.InputEvent;

/** Input boundary for a future guest renderer/runtime. It never synthesizes privileged input. */
public final class GuestInputDispatcher {
    private long dispatched;

    public synchronized boolean dispatch(InputEvent event) {
        if (event == null) return false;
        dispatched++;
        return true;
    }

    public synchronized long getDispatchedCount() { return dispatched; }
    public synchronized void reset() { dispatched = 0L; }
}
