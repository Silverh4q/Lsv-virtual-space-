package com.lsv.virtualspace.guest;

import android.content.Context;
import dalvik.system.DexClassLoader;

import java.io.File;

/** Builds a class loader for inspection/preparation. It does not execute guest code. */
public final class GuestClassLoaderFactory {
    private GuestClassLoaderFactory() {}

    public static DexClassLoader create(Context context, String apkPath, File dataDir) {
        File optimized = new File(dataDir, "dex");
        if (!optimized.exists()) { optimized.mkdirs(); }
        File nativeDir = new File(dataDir, "native");
        if (!nativeDir.exists()) { nativeDir.mkdirs(); }
        ClassLoader parent = context.getClassLoader();
        return new DexClassLoader(apkPath, optimized.getAbsolutePath(),
            nativeDir.getAbsolutePath(), parent);
    }
}
