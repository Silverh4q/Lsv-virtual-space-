package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class ApiLevelCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "API_LEVEL"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = android.os.Build.VERSION.SDK_INT >= 23;
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
