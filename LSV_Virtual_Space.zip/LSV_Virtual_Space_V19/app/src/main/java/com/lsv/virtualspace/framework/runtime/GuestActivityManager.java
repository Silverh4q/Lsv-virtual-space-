package com.lsv.virtualspace.framework.runtime;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import com.lsv.virtualspace.framework.GuestActivityContract;
import com.lsv.virtualspace.framework.intent.GuestIntentResolver;
import com.lsv.virtualspace.framework.packages.GuestPackageRegistry;
import com.lsv.virtualspace.framework.packages.GuestPackageRecord;
import com.lsv.virtualspace.virtual.VirtualPackageManager;
import com.lsv.virtualspace.framework.system.GuestSystemServiceFacade;
import com.lsv.virtualspace.framework.system.GuestSystemServiceName;

import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 * Central ActivityManager-style owner for guest component routing.
 * All guest start/bind/broadcast decisions pass through the same manifest resolver.
 */
public final class GuestActivityManager {
    private final Context hostContext;
    private final VirtualPackageManager packages;
    private final GuestPackageRegistry registry;
    private final Map<String, GuestComponentSession> sessions = new HashMap<String, GuestComponentSession>();
    private GuestSystemServiceFacade systemServices;

    public GuestActivityManager(Context context, VirtualPackageManager packages,
                                GuestPackageRegistry registry) {
        hostContext = context.getApplicationContext();
        this.packages = packages;
        this.registry = registry;
    }

    public void attachSystemServices(GuestSystemServiceFacade facade) { this.systemServices = facade; }

    public Intent routeActivity(String packageName, Intent guestIntent) {
        if (packageName == null || guestIntent == null) return null;
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null) return null;
        String component = registry.getIntentResolver().resolveActivity(
            packageName, record.getPackageInfo(), guestIntent);
        if (component == null) return null;
        Intent proxy = new Intent(hostContext, com.lsv.virtualspace.proxy.GuestActivityProxy.class);
        proxy.putExtra(GuestActivityContract.EXTRA_PACKAGE, packageName);
        proxy.putExtra(GuestActivityContract.EXTRA_COMPONENT, component);
        proxy.putExtra(GuestActivityContract.EXTRA_GUEST_INTENT, new Intent(guestIntent));
        remember(packageName, component, "activity", "STARTING");
        if (systemServices != null) {
            android.os.Bundle b = new android.os.Bundle();
            b.putString("session", packageName + ":" + component);
            systemServices.dispatch(packageName, GuestSystemServiceName.WINDOW, "create_session", b);
        }
        String action = guestIntent.getAction();
        if (action != null) proxy.putExtra(GuestActivityContract.EXTRA_ACTION, action);
        proxy.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return proxy;
    }

    public Intent routeService(String packageName, Intent guestIntent) {
        if (packageName == null || guestIntent == null) return null;
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null) return null;
        String component = registry.getIntentResolver().resolveService(
            packageName, record.getPackageInfo(), guestIntent);
        if (component == null) return null;
        Intent proxy = new Intent(hostContext, com.lsv.virtualspace.proxy.GuestServiceProxy.class);
        proxy.putExtra(GuestActivityContract.EXTRA_PACKAGE, packageName);
        proxy.putExtra(GuestActivityContract.EXTRA_COMPONENT, component);
        proxy.putExtra(GuestActivityContract.EXTRA_GUEST_INTENT, new Intent(guestIntent));
        remember(packageName, component, "service", "ROUTED");
        return proxy;
    }

    public Intent routeBroadcast(String packageName, Intent guestIntent) {
        List<String> receivers = resolveReceivers(packageName, guestIntent);
        if (receivers.size() == 0) return null;
        return buildReceiverProxy(packageName, guestIntent, receivers.get(0));
    }

    public List<String> resolveReceivers(String packageName, Intent guestIntent) {
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null || guestIntent == null) {
            return new java.util.ArrayList<String>();
        }
        return registry.getIntentResolver().resolveReceivers(
            packageName, record.getPackageInfo(), guestIntent);
    }

    public Intent buildReceiverProxy(String packageName, Intent guestIntent, String component) {
        Intent proxy = new Intent(hostContext, com.lsv.virtualspace.proxy.GuestReceiverProxy.class);
        proxy.putExtra("lsv.guest.receiver.package", packageName);
        proxy.putExtra("lsv.guest.receiver.component", component);
        proxy.putExtra("lsv.guest.receiver.intent", new Intent(guestIntent));
        return proxy;
    }

    public ComponentName resolveActivityComponent(String packageName, Intent intent) {
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null) return null;
        String component = registry.getIntentResolver().resolveActivity(
            packageName, record.getPackageInfo(), intent);
        return component == null ? null : new ComponentName(packageName, component);
    }

    public ComponentName resolveServiceComponent(String packageName, Intent intent) {
        GuestPackageRecord record = registry.ensure(packageName);
        if (record == null) return null;
        String component = registry.getIntentResolver().resolveService(
            packageName, record.getPackageInfo(), intent);
        return component == null ? null : new ComponentName(packageName, component);
    }
    public synchronized void markActivityStarted(String packageName, String component) {
        update(packageName, component, "activity", "RUNNING");
        if (systemServices != null) {
            android.os.Bundle b = new android.os.Bundle(); b.putString("session", packageName + ":" + component); b.putBoolean("visible", true);
            systemServices.dispatch(packageName, GuestSystemServiceName.WINDOW, "set_visible", b);
        }
    }

    public synchronized void markActivityStopped(String packageName, String component) {
        update(packageName, component, "activity", "STOPPED");
        if (systemServices != null) {
            android.os.Bundle b = new android.os.Bundle(); b.putString("session", packageName + ":" + component);
            systemServices.dispatch(packageName, GuestSystemServiceName.WINDOW, "close_session", b);
        }
    }

    public synchronized GuestComponentSession getSession(String packageName, String component) {
        return sessions.get(key(packageName, component));
    }

    public synchronized java.util.List<GuestComponentSession> getSessions(String packageName) {
        java.util.List<GuestComponentSession> result = new java.util.ArrayList<GuestComponentSession>();
        for (GuestComponentSession session : sessions.values()) {
            if (packageName == null || packageName.equals(session.getPackageName())) result.add(session);
        }
        return result;
    }

    private void remember(String packageName, String component, String type, String state) {
        sessions.put(key(packageName, component), new GuestComponentSession(packageName, component, type, state));
    }

    private void update(String packageName, String component, String type, String state) {
        String k = key(packageName, component);
        GuestComponentSession current = sessions.get(k);
        if (current == null) {
            remember(packageName, component, type, state);
        } else {
            current.setState(state);
        }
    }

    private String key(String packageName, String component) {
        return String.valueOf(packageName) + ":" + String.valueOf(component);
    }

}
