package com.lsv.virtualspace.guest.runtime;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.guest.GuestClassLoaderFactory;
import com.lsv.virtualspace.guest.GuestComponentResolver;
import com.lsv.virtualspace.virtual.VirtualCore;
import com.lsv.virtualspace.virtual.VirtualPackageManager;
import com.lsv.virtualspace.framework.runtime.GuestFrameworkRuntime;
import com.lsv.virtualspace.framework.runtime.GuestEnvironment;
import com.lsv.virtualspace.diagnostics.GuestDiagnosticController;
import com.lsv.virtualspace.diagnostics.GuestRuntimeStage;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dalvik.system.DexClassLoader;

/** Per-Activity guest state used by the LSV instrumentation bridge. */
public final class GuestExecutionSession {
    private static final Map<Activity, GuestExecutionSession> ACTIVE = new HashMap<Activity, GuestExecutionSession>();

    private final VirtualApp app;
    private final ActivityInfo activityInfo;
    private final ApplicationInfo applicationInfo;
    private final GuestContext context;
    private final DexClassLoader classLoader;
    private final Application application;
    private final Intent intent;

    private GuestExecutionSession(VirtualApp app, ActivityInfo activityInfo,
                                  ApplicationInfo applicationInfo, GuestContext context,
                                  DexClassLoader classLoader, Application application,
                                  Intent intent) {
        this.app = app;
        this.activityInfo = activityInfo;
        this.applicationInfo = applicationInfo;
        this.context = context;
        this.classLoader = classLoader;
        this.application = application;
        this.intent = intent;
    }

    public static synchronized GuestExecutionSession prepare(Context host, String packageName,
                                                              String component, Intent proxyIntent) throws Exception {
        GuestDiagnosticController diagnostics = GuestDiagnosticController.get(host);
        diagnostics.beginIfNeeded(packageName, component);
        diagnostics.stage(GuestRuntimeStage.PACKAGE_LOOKUP, "lookup " + packageName);
        VirtualCore core = VirtualCore.get();
        VirtualApp app = com.lsv.virtualspace.virtual.VirtualAppLookup.find(
            core.getAppRepository(), packageName);
        if (app == null) {
            IllegalStateException error = new IllegalStateException("Virtual app not found: " + packageName);
            diagnostics.fail("PACKAGE_LOOKUP_FAILURE", error);
            throw error;
        }

        diagnostics.stage(GuestRuntimeStage.PACKAGE_METADATA, "read package metadata");
        String virtualUid = null;
        try {
            com.lsv.virtualspace.framework.identity.GuestIdentity identity =
                core.getFrameworkHost().getSystemServices().getIdentity(packageName);
            if (identity != null) virtualUid = String.valueOf(identity.getVirtualUid());
        } catch (Throwable ignored) { }
        diagnostics.setRuntimeMetadata(app.getApkPath(), virtualUid);
        VirtualPackageManager pm = core.getRuntimeController().getPackageManager();
        android.content.pm.PackageInfo packageInfo = pm.getPackageInfo(app);
        if (packageInfo == null || packageInfo.applicationInfo == null) {
            IllegalStateException error = new IllegalStateException("Guest package metadata unavailable");
            diagnostics.fail("PACKAGE_METADATA_FAILURE", error);
            throw error;
        }

        diagnostics.stage(GuestRuntimeStage.ACTIVITY_RESOLUTION, component);
        ActivityInfo guestActivity = findActivity(packageInfo, component);
        if (guestActivity == null) {
            IllegalStateException error = new IllegalStateException("Guest activity not found: " + component);
            diagnostics.fail("ACTIVITY_RESOLUTION_FAILURE", error);
            throw error;
        }

        ApplicationInfo ai = packageInfo.applicationInfo;
        ai.sourceDir = app.getApkPath();
        ai.publicSourceDir = app.getApkPath();
        ai.dataDir = app.getDataPath();
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            setOptionalField(ai, "deviceProtectedDataDir",
                new File(app.getDataPath(), "device_protected").getAbsolutePath());
            setOptionalField(ai, "credentialProtectedDataDir", app.getDataPath());
        }

        diagnostics.stage(GuestRuntimeStage.NATIVE_PREPARE, app.getDataPath());
        diagnostics.stage(GuestRuntimeStage.NATIVE_RUNTIME, "prepare guest native runtime");
        File nativeDir = new File(app.getDataPath(), "native-libs");
        try {
            GuestNativeLibraryExtractor.extract(app.getApkPaths(), nativeDir);
            ai.nativeLibraryDir = nativeDir.getAbsolutePath();
        } catch (Throwable ignored) {
            // Java-only guests can still run without native extraction.
        }

        diagnostics.stage(GuestRuntimeStage.CLASSLOADER, "create DexClassLoader");
        DexClassLoader loader = createLoader(host, app);
        diagnostics.stage(GuestRuntimeStage.CLASSLOADER, "DexClassLoader ready");
        List<String> paths = app.getApkPaths();
        diagnostics.stage(GuestRuntimeStage.RESOURCES, "create guest Resources");
        diagnostics.stage(GuestRuntimeStage.GUEST_RESOURCES, "guest resource session starting");
        Resources resources;
        try {
            resources = GuestResourceLoader.create(host, paths);
        } catch (Throwable error) {
            diagnostics.fail("RESOURCE_BOOTSTRAP_FAILURE", error);
            throw new IllegalStateException("Guest resources failed: " + describe(error), error);
        }
        diagnostics.stage(GuestRuntimeStage.RESOURCE_VALIDATE, "guest Resources ready");
        int themeId = guestActivity.theme;
        if (resources.getAssets() == null) {
            IllegalStateException error = new IllegalStateException("Guest AssetManager unavailable");
            diagnostics.fail("RESOURCE_ASSET_FAILURE", error);
            throw error;
        }
        GuestContext guestContext = new GuestContext(host, packageName, ai, resources,
            resources.getAssets(), loader, new File(app.getDataPath()), themeId);
        diagnostics.stage(GuestRuntimeStage.GUEST_CONTEXT, "guest Context created");

        diagnostics.stage(GuestRuntimeStage.APPLICATION_STARTUP, "guest Application startup");
        diagnostics.stage(GuestRuntimeStage.APPLICATION_CREATE, ai.className == null ? "android.app.Application" : ai.className);
        Application guestApplication = null;
        try {
            guestApplication = createApplication(loader, ai.className, guestContext);
            diagnostics.stage(GuestRuntimeStage.APPLICATION_ATTACH, "attach Application context");
            GuestActivityContextBridge.attachApplication(guestApplication, guestContext);
            diagnostics.stage(GuestRuntimeStage.APPLICATION_ON_CREATE, "Application.onCreate");
            guestApplication.onCreate();
            diagnostics.stage(GuestRuntimeStage.FRAMEWORK_REGISTER, "register guest environment");
            guestContext.registerFrameworkEnvironment();
            diagnostics.stage(GuestRuntimeStage.GUEST_APPLICATION, guestApplication.getClass().getName());
            diagnostics.stage(GuestRuntimeStage.APPLICATION_READY, guestApplication.getClass().getName());
        } catch (Throwable error) {
            diagnostics.fail("APPLICATION_BOOTSTRAP_FAILURE", error);
            throw new IllegalStateException("Guest Application bootstrap failed: "
                + describe(error), error);
        }

        guestActivity.applicationInfo = ai;
        guestActivity.packageName = packageName;
        guestActivity.name = component;
        guestActivity.applicationInfo.sourceDir = app.getApkPath();
        guestActivity.applicationInfo.publicSourceDir = app.getApkPath();

        Intent guestIntent = new Intent(proxyIntent);
        guestIntent.setComponent(new android.content.ComponentName(packageName, component));
        guestIntent.setPackage(packageName);
        guestIntent.removeExtra(com.lsv.virtualspace.framework.GuestActivityContract.EXTRA_PACKAGE);
        guestIntent.removeExtra(com.lsv.virtualspace.framework.GuestActivityContract.EXTRA_COMPONENT);
        guestIntent.removeExtra(com.lsv.virtualspace.framework.GuestActivityContract.EXTRA_ACTION);

        diagnostics.stage(GuestRuntimeStage.ACTIVITY_CREATE, component);
        diagnostics.stage(GuestRuntimeStage.PROXY_ACTIVITY_CREATE, "proxy activity replaced by guest " + component);
        diagnostics.stage(GuestRuntimeStage.ACTIVITY_READY, component);
        GuestExecutionSession session = new GuestExecutionSession(app, guestActivity, ai,
            guestContext, loader, guestApplication, guestIntent);
        return session;
    }

    private static ActivityInfo findActivity(android.content.pm.PackageInfo info, String name) {
        if (info.activities == null) return null;
        for (ActivityInfo item : info.activities) {
            if (item != null && name.equals(item.name)) return item;
        }
        return null;
    }

    private static DexClassLoader createLoader(Context host, VirtualApp app) throws Exception {
        File codeDir = new File(app.getDataPath(), "code-cache");
        if (!codeDir.exists() && !codeDir.mkdirs()) throw new IllegalStateException("Cannot create guest code cache");
        File readOnly = new File(codeDir, "apk");
        if (!readOnly.exists() && !readOnly.mkdirs()) throw new IllegalStateException("Cannot create guest APK cache");
        StringBuilder dexPath = new StringBuilder();
        List<String> paths = app.getApkPaths();
        for (String sourcePath : paths) {
            File source = new File(sourcePath);
            File target = new File(readOnly, source.getName());
            if (!target.exists() || target.length() != source.length()) copy(source, target);
            target.setReadable(true, false);
            target.setWritable(false, false);
            if (dexPath.length() > 0) dexPath.append(File.pathSeparator);
            dexPath.append(target.getAbsolutePath());
        }
        File nativeDir = new File(app.getDataPath(), "native-libs");
        return new DexClassLoader(dexPath.toString(), codeDir.getAbsolutePath(),
            nativeDir.getAbsolutePath(), host.getClassLoader());
    }

    private static void copy(File source, File target) throws Exception {
        java.io.FileInputStream in = new java.io.FileInputStream(source);
        java.io.FileOutputStream out = new java.io.FileOutputStream(target);
        try {
            byte[] buffer = new byte[32768];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        } finally {
            in.close();
            out.close();
        }
    }

    private static Application createApplication(ClassLoader loader, String name, Context context) throws Exception {
        String className = name;
        if (className == null || className.length() == 0) className = Application.class.getName();
        Class<?> type = loader.loadClass(className);
        Object value = type.newInstance();
        if (!(value instanceof Application)) throw new IllegalStateException("Guest application is not android.app.Application");
        return (Application) value;
    }

    public void prepareActivity(Activity activity) throws Exception {
        if (activity == null) throw new IllegalArgumentException("Guest Activity is null");
        GuestDiagnosticController.get(activity).stage(GuestRuntimeStage.ACTIVITY_PREPARE, activity.getClass().getName());
        // ActivityThread owns the real window/token. LSV now binds the guest
        // application/context/resource state immediately before guest onCreate.
        GuestActivityContextBridge.bind(activity, context, context.getResources(),
            application, activityInfo, intent, activityInfo.theme);
        GuestDiagnosticController.get(activity).stage(GuestRuntimeStage.WINDOW_READY, "Activity window owned by Android ActivityThread");
        synchronized (GuestExecutionSession.class) { ACTIVE.put(activity, this); }
    }

    public void destroy(Activity activity) {
        synchronized (GuestExecutionSession.class) { ACTIVE.remove(activity); }
        try { GuestDiagnosticController.get(activity).stage(GuestRuntimeStage.CLEANUP, "guest Activity session released"); } catch (Throwable ignored) { }
        GuestFrameworkRuntime.unregister(app.getPackageName());
    }

    public static synchronized GuestExecutionSession get(Activity activity) {
        return ACTIVE.get(activity);
    }

    public static synchronized void bindPending(Activity activity, GuestExecutionSession session) {
        if (activity != null && session != null) ACTIVE.put(activity, session);
    }

    public ClassLoader getClassLoader() { return classLoader; }
    public ApplicationInfo getApplicationInfo() { return applicationInfo; }
    public ActivityInfo getActivityInfo() { return activityInfo; }

    public VirtualApp getApp() { return app; }
    public String getComponent() { return activityInfo.name; }
    public Application getApplication() { return application; }

    private static String describe(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        String message = current.getMessage();
        return message == null || message.length() == 0
            ? current.getClass().getSimpleName() : message;
    }

    /** Sets optional framework fields without requiring them in the AIDE compile SDK. */
    private static void setOptionalField(Object target, String name, Object value) {
        try {
            Field field = target.getClass().getDeclaredField(name);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Throwable ignored) {
            // The field is hidden/absent on this Android release.
        }
    }
}
