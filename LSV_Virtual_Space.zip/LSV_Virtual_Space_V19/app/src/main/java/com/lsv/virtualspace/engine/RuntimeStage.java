package com.lsv.virtualspace.engine;
public final class RuntimeStage {
    public static final int STEP_10=10, STEP_20=20, STEP_30=30, STEP_40=40, STEP_50=50;
    private RuntimeStage() {}
}
