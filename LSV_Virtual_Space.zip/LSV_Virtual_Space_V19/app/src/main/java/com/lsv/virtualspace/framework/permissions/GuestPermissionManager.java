package com.lsv.virtualspace.framework.permissions;

import android.Manifest;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.lsv.virtualspace.virtual.VirtualPackageManager;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Per-guest permission policy. Host permission state is never copied into a guest. */
public final class GuestPermissionManager {
    private final VirtualPackageManager packages;
    private final Map<String, Set<String>> grants = new HashMap<String, Set<String>>();
    private final Set<String> overlayAllowed = new HashSet<String>();

    public GuestPermissionManager(VirtualPackageManager packages) { this.packages = packages; }

    public synchronized void grant(String packageName, String permission) {
        if (packageName == null || permission == null) return;
        Set<String> set = grants.get(packageName);
        if (set == null) { set = new HashSet<String>(); grants.put(packageName, set); }
        set.add(permission);
    }

    public synchronized void revoke(String packageName, String permission) {
        Set<String> set = grants.get(packageName);
        if (set != null) set.remove(permission);
    }

    public synchronized boolean isGranted(String packageName, String permission) {
        if (packageName == null || permission == null) return false;
        if (permission.equals(Manifest.permission.SYSTEM_ALERT_WINDOW)) {
            return false; // Overlay is mediated by LSV's overlay service.
        }
        Set<String> set = grants.get(packageName);
        return set != null && set.contains(permission);
    }

    public synchronized int check(String packageName, String permission) {
        if (isGranted(packageName, permission)) return PackageManager.PERMISSION_GRANTED;
        return PackageManager.PERMISSION_DENIED;
    }

    public synchronized void setOverlayAllowed(String packageName, boolean allowed) {
        if (packageName == null) return;
        if (allowed) overlayAllowed.add(packageName); else overlayAllowed.remove(packageName);
    }

    public synchronized boolean isOverlayAllowed(String packageName) {
        return packageName != null && overlayAllowed.contains(packageName);
    }

    public synchronized String[] requested(String packageName) {
        PackageInfo info = packages.getPackageInfo(packageName);
        return info == null || info.requestedPermissions == null
            ? new String[0] : info.requestedPermissions.clone();
    }
}
