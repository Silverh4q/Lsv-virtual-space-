package com.lsv.virtualspace.profiles;
import android.content.Context; import com.lsv.virtualspace.virtual.GuestExecutionCapability;
public final class GameCompatibilityAnalyzer {
    private final GameProfileManager manager;
    public GameCompatibilityAnalyzer(Context c){manager=new GameProfileManager(c);}
    public GameCompatibilityReport analyze(String pkg,GuestExecutionCapability cap){
        boolean known=manager.isKnownGame(pkg); String n=manager.getCatalog().getName(pkg); if(n==null)n="Generic Android Game";
        boolean ready=cap!=null&&cap.isSupported(); String note=ready?"Guest runtime capability checks passed":"Guest execution backend is not available on this build";
        if(known)note += ". Game profile enables compatibility diagnostics only.";
        return new GameCompatibilityReport(pkg,n,known,ready,note);
    }
}
