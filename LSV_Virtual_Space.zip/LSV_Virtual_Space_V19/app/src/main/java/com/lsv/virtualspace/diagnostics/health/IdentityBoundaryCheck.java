package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;

public final class IdentityBoundaryCheck implements GuestHealthCheck {
    @Override
    public String getName() { return "IDENTITY_BOUNDARY"; }

    @Override
    public boolean run(Context context, VirtualApp app, StringBuilder detail) throws Exception {
        boolean ok = com.lsv.virtualspace.virtual.VirtualCore.get().isInitialized();
        if (detail != null) detail.append(ok ? "available" : "unavailable");
        return ok;
    }
}
