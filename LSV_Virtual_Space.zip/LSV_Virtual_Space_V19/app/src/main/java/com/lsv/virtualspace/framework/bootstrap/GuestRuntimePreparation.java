package com.lsv.virtualspace.framework.bootstrap;

import com.lsv.virtualspace.framework.context.GuestContextSpec;
import com.lsv.virtualspace.framework.compat.GuestApiCompatibility;

/** Result of framework preparation. It never claims that guest code is executing. */
public final class GuestRuntimePreparation {
    private final GuestBootstrapPlan bootstrap;
    private final GuestContextSpec contextSpec;
    private final String compatibility;

    public GuestRuntimePreparation(GuestBootstrapPlan bootstrap,
                                   GuestContextSpec contextSpec) {
        this.bootstrap = bootstrap;
        this.contextSpec = contextSpec;
        this.compatibility = GuestApiCompatibility.summary();
    }

    public GuestBootstrapPlan getBootstrap() { return bootstrap; }
    public GuestContextSpec getContextSpec() { return contextSpec; }
    public String getCompatibility() { return compatibility; }
}
