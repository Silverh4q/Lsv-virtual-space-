package com.lsv.virtualspace.storage;

import android.content.Context;
import android.net.Uri;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

/** Copies an LSV-owned APK to a user-selected document using SAF. */
public final class StorageExportManager {
    private StorageExportManager() { }

    public static boolean exportFile(Context context, File source, Uri destination) {
        if (source == null || destination == null || !source.isFile()) return false;
        byte[] buffer = new byte[32768];
        FileInputStream in = null;
        OutputStream out = null;
        try {
            in = new FileInputStream(source);
            out = context.getContentResolver().openOutputStream(destination);
            if (out == null) return false;
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            out.flush();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
            try { if (out != null) out.close(); } catch (Exception ignored) { }
        }
    }
}
