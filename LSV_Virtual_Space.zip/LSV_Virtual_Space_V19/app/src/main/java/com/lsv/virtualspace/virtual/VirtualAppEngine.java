package com.lsv.virtualspace.virtual;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;

/**
 * LSV's AIDE-safe execution coordinator.
 *
 * This class intentionally depends only on public Android APIs and LSV's own
 * virtualization classes. It does not reference hidden Android services or a
 * copied third-party VirtualApp implementation.
 */
public final class VirtualAppEngine {
    private static final Object LOCK = new Object();
    private static boolean started;
    private static String lastError;

    private VirtualAppEngine() { }

    public static boolean ensureStarted(Context context) {
        synchronized (LOCK) {
            if (started) return true;
            if (context == null) {
                lastError = "Context is null.";
                return false;
            }
            try {
                VirtualCore.get().initialize(context.getApplicationContext());
                started = true;
                lastError = null;
                return true;
            } catch (Throwable error) {
                lastError = describe(error);
                return false;
            }
        }
    }

    /**
     * Starts the LSV guest process and its real in-process guest bootstrapper.
     * The Android PackageInstaller path remains available from the UI as an
     * explicit compatibility fallback, but is not the primary launch route.
     */
    public static LaunchResult installAndLaunch(Context context, VirtualApp app) {
        if (app == null) return LaunchResult.failure("No virtual app was selected.");
        if (!ensureStarted(context)) {
            return LaunchResult.failure(lastError);
        }
        try {
            GuestLaunchInfo info = VirtualCore.get().getRuntimeController().prepare(app);
            if (info == null) {
                return LaunchResult.failure("The guest has no launchable Activity.");
            }

            android.content.Intent intent = VirtualCore.get().getFrameworkHost()
                .createProxyIntent(app, new android.content.Intent(android.content.Intent.ACTION_MAIN));
            if (intent == null) {
                return LaunchResult.failure("LSV could not create the guest Activity route.");
            }
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            com.lsv.virtualspace.process.GuestProcessBootstrap.Result bootstrap =
                com.lsv.virtualspace.process.GuestProcessBootstrap.startAndLaunch(
                    context, app, intent);
            if (!bootstrap.started) {
                lastError = bootstrap.error == null ? "Guest process bootstrap failed." : bootstrap.error;
                return LaunchResult.failure(lastError);
            }
            return LaunchResult.success("LSV guest process bootstrap started.");
        } catch (Throwable error) {
            lastError = describe(error);
            return LaunchResult.failure("Guest launch failed: " + lastError);
        }
    }

    public static boolean isAvailable(Context context) {
        return ensureStarted(context);
    }

    public static String getLastError() {
        return lastError;
    }

    private static String describe(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        String message = current.getMessage();
        return message == null || message.length() == 0
            ? current.getClass().getSimpleName()
            : message;
    }

    public static final class LaunchResult {
        private final boolean success;
        private final String message;

        private LaunchResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }

        public static LaunchResult success(String message) {
            return new LaunchResult(true, message);
        }

        public static LaunchResult failure(String message) {
            return new LaunchResult(false, message);
        }

        public boolean isSuccess() { return success; }
        public String getError() { return message; }
    }
}
