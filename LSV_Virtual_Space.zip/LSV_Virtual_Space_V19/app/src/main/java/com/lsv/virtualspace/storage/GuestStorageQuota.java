package com.lsv.virtualspace.storage;
public final class GuestStorageQuota { private final long bytes; public GuestStorageQuota(long b){bytes=b;} public long getBytes(){return bytes;} public boolean fits(long current,long additional){return current+additional<=bytes;} }
