package com.lsv.virtualspace.google;

import android.content.Context;
import android.content.pm.PackageManager;

/**
 * Detects whether Google components are present on the host.
 *
 * Detection is intentionally separate from virtualization. Presence on the
 * host does not mean the component can simply be moved into the sandbox.
 */
public final class GoogleCompatibility {
    private GoogleCompatibility() {
    }

    public static boolean hasPlayServices(Context context) {
        return packageExists(context, "com.google.android.gms");
    }

    public static boolean hasPlayStore(Context context) {
        return packageExists(context, "com.android.vending");
    }

    private static boolean packageExists(Context context, String packageName) {
        try {
            context.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
            return false;
        }
    }
}
