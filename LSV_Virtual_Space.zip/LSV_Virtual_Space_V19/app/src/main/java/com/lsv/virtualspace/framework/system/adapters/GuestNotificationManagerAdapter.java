package com.lsv.virtualspace.framework.system.adapters;

import android.os.Bundle;
import com.lsv.virtualspace.framework.system.*;

/** Guest-scoped notification registry. Android notification posting is mediated later by LSV UI policy. */
public final class GuestNotificationManagerAdapter implements GuestSystemServiceAdapter {
    public String getServiceName() { return GuestSystemServiceName.NOTIFICATION; }
    public boolean canHandle(String op) {
        return "post".equals(op) || "cancel".equals(op) || "channel_create".equals(op) || "channel_delete".equals(op);
    }
    public Bundle handle(String pkg, GuestSystemServiceRequest r, GuestSystemServiceState s) {
        Bundle out = new Bundle();
        Bundle a = r.getArguments();
        String id = a == null ? null : a.getString("id");
        if (id == null || id.length() == 0) id = "default";
        String key = ("channel_create".equals(r.getOperation()) || "channel_delete".equals(r.getOperation()))
                ? "channel:" + id : "notification:" + id;
        if ("cancel".equals(r.getOperation()) || "channel_delete".equals(r.getOperation())) {
            s.remove(pkg, getServiceName(), key);
        } else {
            s.put(pkg, getServiceName(), key, "active");
            if (a != null) {
                String title = a.getString("title");
                String text = a.getString("text");
                if (title != null) s.put(pkg, getServiceName(), key + ":title", title);
                if (text != null) s.put(pkg, getServiceName(), key + ":text", text);
            }
        }
        out.putBoolean("accepted", true);
        out.putString("id", id);
        out.putString("package", pkg);
        return out;
    }
}
