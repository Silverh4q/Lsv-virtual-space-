package com.lsv.virtualspace.process;

import java.util.HashMap;
import java.util.Map;

public final class GuestProcessSupervisor {
    private final Map<String,GuestProcessState> states=new HashMap<String,GuestProcessState>();
    public synchronized GuestProcessState getOrCreate(String pkg){
        GuestProcessState s=states.get(pkg);
        if(s==null){s=new GuestProcessState(pkg);states.put(pkg,s);} return s;
    }
    public synchronized void prepare(String pkg){getOrCreate(pkg).set(GuestProcessState.PREPARING,"Preparing guest process");}
    public synchronized void ready(String pkg){getOrCreate(pkg).set(GuestProcessState.READY,"Guest process is ready for a supported backend");}
    public synchronized void running(String pkg){getOrCreate(pkg).set(GuestProcessState.RUNNING,"Guest process running");}
    public synchronized void stop(String pkg){getOrCreate(pkg).set(GuestProcessState.STOPPED,"Guest process stopped");}
    public synchronized void fail(String pkg,String reason){getOrCreate(pkg).set(GuestProcessState.FAILED,reason);}
}
