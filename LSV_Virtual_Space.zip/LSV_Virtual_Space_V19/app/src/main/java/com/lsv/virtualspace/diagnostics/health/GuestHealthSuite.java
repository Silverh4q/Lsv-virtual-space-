package com.lsv.virtualspace.diagnostics.health;

import android.content.Context;
import com.lsv.virtualspace.apps.VirtualApp;
import java.util.ArrayList;
import java.util.List;

public final class GuestHealthSuite {
    private GuestHealthSuite() { }
    public static Result run(Context context, VirtualApp app) {
        List<GuestHealthCheck> checks = new ArrayList<GuestHealthCheck>();
        checks.add(new ApkPathCheck()); checks.add(new DataDirectoryCheck()); checks.add(new PackageIdentityCheck());
        checks.add(new ClassLoaderCheck()); checks.add(new DiagnosticsDirectoryCheck()); checks.add(new ApiLevelCheck());
        checks.add(new AbiCheck()); checks.add(new PackageManagerCheck()); checks.add(new ActivityManagerCheck());
        checks.add(new FrameworkHostCheck()); checks.add(new ApplicationInfoCheck()); checks.add(new SourceDirectoryCheck());
        checks.add(new PublicSourceDirectoryCheck()); checks.add(new CodeCacheCheck()); checks.add(new NativeDirectoryCheck());
        checks.add(new CacheDirectoryCheck()); checks.add(new DataFilesDirectoryCheck()); checks.add(new ApkReadableCheck());
        checks.add(new ApkZipCheck()); checks.add(new ManifestCheck()); checks.add(new DexCheck());
        checks.add(new SplitApkCheck()); checks.add(new RequestedPermissionsCheck()); checks.add(new ActivityMetadataCheck());
        checks.add(new ServiceMetadataCheck()); checks.add(new ProviderMetadataCheck()); checks.add(new IdentityBoundaryCheck());
        checks.add(new LifecycleBoundaryCheck()); checks.add(new ServiceRegistryCheck()); checks.add(new ProviderRegistryCheck());
        checks.add(new DiagnosticStoreCheck());
        StringBuilder out = new StringBuilder(); int passed=0, failed=0;
        for (GuestHealthCheck check : checks) {
            StringBuilder d = new StringBuilder(); boolean ok=false;
            try { ok=check.run(context,app,d); } catch(Throwable t) { d.append(t.getClass().getSimpleName()).append(": " ).append(t.getMessage()); }
            if(ok) passed++; else failed++;
            out.append(ok ? "PASS " : "FAIL " ).append(check.getName());
            if(d.length()>0) out.append(" | " ).append(d); out.append('\n');
        }
        return new Result(passed,failed,out.toString());
    }
    public static final class Result {
        public final int passed; public final int failed; public final String text;
        public Result(int passed,int failed,String text){this.passed=passed;this.failed=failed;this.text=text;}
        public boolean isHealthy(){return failed==0;}
    }
}
