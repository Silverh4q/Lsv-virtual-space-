package com.lsv.virtualspace.framework;

/** Boundary used to convert guest-backend failures into session-safe errors. */
public final class GuestCrashBoundary {
    private String lastError;

    public synchronized void record(Throwable error) {
        lastError = error == null ? "Unknown guest failure" : error.toString();
    }

    public synchronized String getLastError() { return lastError; }
    public synchronized void clear() { lastError = null; }
}
