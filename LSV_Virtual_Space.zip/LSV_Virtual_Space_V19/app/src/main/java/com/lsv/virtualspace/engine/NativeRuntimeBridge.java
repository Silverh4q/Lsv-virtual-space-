package com.lsv.virtualspace.engine;

/**
 * Optional native boundary. The application remains fully buildable in AIDE
 * without an NDK. If a future device-specific native backend is packaged, it
 * can be loaded here without making the Java project depend on hidden APIs.
 */
public final class NativeRuntimeBridge {
    private static boolean attempted;
    private static boolean loaded;

    private NativeRuntimeBridge() { }

    public static synchronized boolean tryLoad(String libraryName) {
        if (attempted) return loaded;
        attempted = true;
        if (libraryName == null || libraryName.length() == 0) return false;
        try {
            System.loadLibrary(libraryName);
            loaded = true;
        } catch (UnsatisfiedLinkError ignored) {
            loaded = false;
        }
        return loaded;
    }

    public static boolean isLoaded() { return loaded; }
}
