package com.lsv.virtualspace;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

/** Simple AIDE-friendly theme selector with no external UI dependencies. */
public final class ThemeManager {
    public static final String THEME_SYSTEM = "system";
    public static final String THEME_LIGHT = "light";
    public static final String THEME_DARK = "dark";
    public static final String THEME_BLACK = "black";
    public static final String THEME_WHITE = "white";

    private static final String PREFS = "lsv_ui";
    private static final String KEY_THEME = "theme";

    private ThemeManager() {
    }

    public static String getTheme(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_THEME, THEME_SYSTEM);
    }

    public static void setTheme(Context context, String theme) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_THEME, theme)
            .apply();
    }

    public static void apply(Activity activity) {
        String theme = getTheme(activity);
        if (THEME_DARK.equals(theme)) {
            activity.setTheme(R.style.AppThemeDark);
        } else if (THEME_BLACK.equals(theme)) {
            activity.setTheme(R.style.AppThemeBlack);
        } else if (THEME_WHITE.equals(theme)) {
            activity.setTheme(R.style.AppThemeWhite);
        } else if (THEME_LIGHT.equals(theme)) {
            activity.setTheme(R.style.AppThemeLight);
        } else {
            boolean night = (activity.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
            activity.setTheme(night ? R.style.AppThemeDark : R.style.AppThemeLight);
        }
    }

    public static int background(Context context) {
        String theme = getTheme(context);
        if (THEME_DARK.equals(theme) || THEME_BLACK.equals(theme)) {
            return context.getResources().getColor(R.color.lsv_background_dark);
        }
        return context.getResources().getColor(R.color.lsv_background_light);
    }

    public static int surface(Context context) {
        String theme = getTheme(context);
        if (THEME_BLACK.equals(theme)) {
            return context.getResources().getColor(R.color.lsv_surface_black);
        }
        if (THEME_DARK.equals(theme)) {
            return context.getResources().getColor(R.color.lsv_surface_dark);
        }
        return context.getResources().getColor(R.color.lsv_surface_light);
    }

    public static int primaryText(Context context) {
        String theme = getTheme(context);
        if (THEME_DARK.equals(theme) || THEME_BLACK.equals(theme)) {
            return context.getResources().getColor(R.color.lsv_text_dark);
        }
        return context.getResources().getColor(R.color.lsv_text_light);
    }

    public static int secondaryText(Context context) {
        String theme = getTheme(context);
        if (THEME_DARK.equals(theme) || THEME_BLACK.equals(theme)) {
            return context.getResources().getColor(R.color.lsv_text_secondary_dark);
        }
        return context.getResources().getColor(R.color.lsv_text_secondary_light);
    }
}
