package com.lsv.virtualspace.ipc;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

import com.lsv.virtualspace.process.GuestProcessState;

/** Binder/Messenger endpoint exposed by the dedicated LSV guest-process host service. */
public final class GuestProcessMessenger {
    public interface Listener {
        void onCommand(Message message, int command, String packageName, String component);
    }

    private final Messenger messenger;

    public GuestProcessMessenger(final Listener listener) {
        Handler handler = new Handler(Looper.getMainLooper()) {
            @Override public void handleMessage(Message message) {
                if (listener == null || message == null) return;
                if (message.what != GuestIpcMessage.PREPARE &&
                    message.what != GuestIpcMessage.START &&
                    message.what != GuestIpcMessage.STOP &&
                    message.what != GuestIpcMessage.PING) return;
                if (message.getData().getInt(GuestIpcMessage.KEY_VERSION, 0) != GuestIpcMessage.VERSION) return;
                listener.onCommand(message, message.what,
                    message.getData().getString(GuestIpcMessage.KEY_PACKAGE),
                    message.getData().getString(GuestIpcMessage.KEY_COMPONENT));
            }
        };
        messenger = new Messenger(handler);
    }

    public Messenger getMessenger() { return messenger; }

    public static Message result(String packageName, int state, String detail) {
        Message message = GuestIpcMessage.create(GuestIpcMessage.RESULT, packageName, null);
        message.getData().putString(GuestIpcMessage.KEY_STATUS, GuestProcessState.nameOf(state));
        message.getData().putString(GuestIpcMessage.KEY_DETAIL, detail);
        return message;
    }

    public static Message result(String packageName, GuestProcessState state, String detail) {
        Message message = GuestIpcMessage.create(GuestIpcMessage.RESULT, packageName, null);
        message.getData().putString(GuestIpcMessage.KEY_STATUS, state == null ? "UNKNOWN" : GuestProcessState.nameOf(state.getState()));
        message.getData().putString(GuestIpcMessage.KEY_DETAIL, detail);
        return message;
    }

    public static boolean send(Messenger target, Message message) {
        if (target == null || message == null) return false;
        try {
            target.send(message);
            return true;
        } catch (RemoteException ignored) {
            return false;
        }
    }
}
