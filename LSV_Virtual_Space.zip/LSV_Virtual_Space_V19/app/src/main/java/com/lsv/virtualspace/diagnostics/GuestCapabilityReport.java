package com.lsv.virtualspace.diagnostics;

public final class GuestCapabilityReport {
    private final boolean metadata;
    private final boolean resources;
    private final boolean dexLoader;
    private final boolean nativeCompatible;
    private final boolean processBackend;
    private final String message;

    public GuestCapabilityReport(boolean metadata, boolean resources, boolean dexLoader,
                                 boolean nativeCompatible, boolean processBackend, String message) {
        this.metadata = metadata; this.resources = resources; this.dexLoader = dexLoader;
        this.nativeCompatible = nativeCompatible; this.processBackend = processBackend;
        this.message = message == null ? "" : message;
    }

    public boolean hasMetadata() { return metadata; }
    public boolean hasResources() { return resources; }
    public boolean hasDexLoader() { return dexLoader; }
    public boolean hasNativeCompatibility() { return nativeCompatible; }
    public boolean hasProcessBackend() { return processBackend; }
    public String getMessage() { return message; }
}
