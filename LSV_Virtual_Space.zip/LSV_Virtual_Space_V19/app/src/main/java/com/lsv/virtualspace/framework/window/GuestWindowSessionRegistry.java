package com.lsv.virtualspace.framework.window;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Central guest window/session registry. Android still owns real window tokens. */
public final class GuestWindowSessionRegistry {
    private final Map<String, GuestWindowSession> sessions = new HashMap<String, GuestWindowSession>();

    public synchronized GuestWindowSession open(String packageName, String id, String token, int width, int height, int type) {
        GuestWindowSession session = new GuestWindowSession(packageName, id, token, width, height, type);
        sessions.put(key(packageName, id), session);
        return session;
    }
    public synchronized void setVisible(String packageName, String id, boolean visible) {
        GuestWindowSession session = sessions.get(key(packageName, id));
        if (session != null) session.setVisible(visible);
    }
    public synchronized void close(String packageName, String id) { sessions.remove(key(packageName, id)); }
    public synchronized GuestWindowSession get(String packageName, String id) { return sessions.get(key(packageName, id)); }
    public synchronized List<GuestWindowSession> list(String packageName) {
        List<GuestWindowSession> out = new ArrayList<GuestWindowSession>();
        for (GuestWindowSession s : sessions.values()) if (packageName == null || packageName.equals(s.getPackageName())) out.add(s);
        return out;
    }
    public synchronized void clearPackage(String packageName) {
        List<String> remove = new ArrayList<String>();
        for (Map.Entry<String, GuestWindowSession> e : sessions.entrySet()) if (packageName == null || packageName.equals(e.getValue().getPackageName())) remove.add(e.getKey());
        for (String key : remove) sessions.remove(key);
    }
    private String key(String packageName, String id) { return String.valueOf(packageName) + ":" + String.valueOf(id); }
}
