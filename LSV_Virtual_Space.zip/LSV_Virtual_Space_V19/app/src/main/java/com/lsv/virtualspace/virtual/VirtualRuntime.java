package com.lsv.virtualspace.virtual;

import android.content.Context;

/**
 * Runtime abstraction.
 *
 * The host application owns this API; a future VirtualApp/Android-container
 * backend can implement it without changing the launcher UI.
 */
public interface VirtualRuntime {
    void initialize(Context context);
    boolean isAvailable();
    boolean launch(String packageName);
    void stop(String packageName);
}
