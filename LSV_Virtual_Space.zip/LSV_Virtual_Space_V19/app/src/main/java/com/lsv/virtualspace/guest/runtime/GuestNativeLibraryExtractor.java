package com.lsv.virtualspace.guest.runtime;

import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Extracts guest native libraries into LSV's private per-app directory. */
public final class GuestNativeLibraryExtractor {
    private GuestNativeLibraryExtractor() { }

    public static File extract(List<String> apkPaths, File nativeDir) throws Exception {
        nativeDir.mkdirs();
        String[] abis = Build.VERSION.SDK_INT >= 21 ? Build.SUPPORTED_ABIS : new String[] { "armeabi-v7a", "armeabi" };
        Set<String> wanted = new HashSet<String>();
        for (String abi : abis) {
            wanted.add("lib/" + abi + "/");
        }

        for (String apkPath : apkPaths) {
            ZipFile zip = new ZipFile(apkPath);
            try {
                java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry entry = entries.nextElement();
                    if (entry.isDirectory()) continue;
                    String name = entry.getName();
                    String abiPrefix = findAbiPrefix(name, wanted);
                    if (abiPrefix == null || !name.endsWith(".so")) continue;
                    String libName = name.substring(abiPrefix.length());
                    if (libName.length() == 0 || libName.contains("/")) continue;
                    File target = new File(nativeDir, libName);
                    copy(zip.getInputStream(entry), new FileOutputStream(target));
                }
            } finally {
                zip.close();
            }
        }
        return nativeDir;
    }

    private static String findAbiPrefix(String name, Set<String> wanted) {
        for (String prefix : wanted) {
            if (name.startsWith(prefix)) return prefix;
        }
        return null;
    }

    private static void copy(InputStream in, FileOutputStream out) throws Exception {
        try {
            byte[] buffer = new byte[32768];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            out.flush();
        } finally {
            in.close();
            out.close();
        }
    }
}
