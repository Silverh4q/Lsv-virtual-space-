package com.lsv.virtualspace.framework.bootstrap;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.lsv.virtualspace.apps.VirtualApp;

/** Builds a safe bootstrap description from APK metadata without invoking guest code. */
public final class GuestBootstrapPlanner {
    private GuestBootstrapPlanner() {}

    public static GuestBootstrapPlan plan(VirtualApp app, PackageManager pm) {
        if (app == null || pm == null) return null;
        PackageInfo info = pm.getPackageArchiveInfo(
            app.getApkPath(),
            PackageManager.GET_META_DATA
        );
        if (info == null || info.applicationInfo == null) return null;

        ApplicationInfo ai = info.applicationInfo;
        String appClass = ai.className;
        boolean defaultApplication = appClass == null || appClass.length() == 0;
        if (defaultApplication) appClass = "android.app.Application";

        return new GuestBootstrapPlan(
            info.packageName,
            app.getApkPath(),
            app.getDataPath(),
            appClass,
            ai.targetSdkVersion,
            defaultApplication
        );
    }
}
