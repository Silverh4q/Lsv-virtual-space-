package com.lsv.virtualspace.framework.intent;

import android.content.IntentFilter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Small Android binary-XML reader used only for the manifest intent-filter graph.
 * It does not modify the APK and does not depend on hidden Android framework APIs.
 */
public final class GuestManifestFilterParser {
    private static final int RES_XML_TYPE = 0x0003;
    private static final int RES_STRING_POOL_TYPE = 0x001c;
    private static final int RES_XML_START_ELEMENT_TYPE = 0x0102;
    private static final int RES_XML_END_ELEMENT_TYPE = 0x0103;
    private static final int TYPE_STRING = 0x03;
    private static final int TYPE_INT_BOOLEAN = 0x12;

    private GuestManifestFilterParser() { }

    public static List<GuestIntentFilterRecord> parse(String apkPath, String packageName) {
        List<GuestIntentFilterRecord> result = new ArrayList<GuestIntentFilterRecord>();
        if (apkPath == null || packageName == null) return result;
        try {
            byte[] data = readManifestFromZip(apkPath);
            if (data == null) return result;
            parseXml(data, packageName, result);
        } catch (Throwable ignored) {
            // A malformed/unsupported manifest simply yields no virtual filters.
        }
        return result;
    }

    private static byte[] readManifestFromZip(String apkPath) throws IOException {
        java.util.zip.ZipFile zip = new java.util.zip.ZipFile(new File(apkPath));
        try {
            java.util.zip.ZipEntry entry = zip.getEntry("AndroidManifest.xml");
            if (entry == null) return null;
            java.io.InputStream in = zip.getInputStream(entry);
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                return out.toByteArray();
            } finally { in.close(); }
        } finally { zip.close(); }
    }

    private static void parseXml(byte[] data, String packageName,
                                 List<GuestIntentFilterRecord> out) {
        if (u16(data, 0) != RES_XML_TYPE) return;
        int xmlSize = u32(data, 4);
        int offset = u32(data, 8);
        if (xmlSize <= 0 || xmlSize > data.length) xmlSize = data.length;

        String[] strings = null;
        int p = offset;
        String currentComponent = null;
        String currentType = null;
        boolean currentExported = false;
        boolean exportedExplicit = false;
        IntentFilter currentFilter = null;
        int filterDepth = 0;

        while (p + 8 <= xmlSize && p + 8 <= data.length) {
            int type = u16(data, p);
            int headerSize = u16(data, p + 2);
            int chunkSize = u32(data, p + 4);
            if (chunkSize < 8 || p + chunkSize > data.length) break;

            if (type == RES_STRING_POOL_TYPE) {
                strings = parseStringPool(data, p, chunkSize);
            } else if (type == RES_XML_START_ELEMENT_TYPE && strings != null) {
                int attrStart = u16(data, p + 24);
                int attrSize = u16(data, p + 26);
                int attrCount = u16(data, p + 28);
                int attrs = p + attrStart;
                String tag = string(strings, u32(data, p + 20));

                if ("activity".equals(tag) || "activity-alias".equals(tag) ||
                    "service".equals(tag) || "receiver".equals(tag)) {
                    currentComponent = null;
                    currentType = tag;
                    currentExported = false;
                    exportedExplicit = false;
                    for (int i = 0; i < attrCount; i++) {
                        int a = attrs + i * attrSize;
                        String name = string(strings, u32(data, a + 4));
                        TypedValue value = value(data, a + 12, strings);
                        if ("name".equals(name)) currentComponent = normalizeClass(value.text, packageName);
                        else if ("exported".equals(name)) {
                            exportedExplicit = true;
                            currentExported = value.bool;
                        }
                    }
                } else if ("intent-filter".equals(tag) && currentComponent != null) {
                    currentFilter = new IntentFilter();
                    String priority = findAttr(data, strings, attrs, attrSize, attrCount, "priority");
                    if (priority != null) {
                        try { currentFilter.setPriority(Integer.parseInt(priority)); } catch (NumberFormatException ignored) { }
                    }
                    filterDepth = 1;
                } else if (currentFilter != null && filterDepth > 0) {
                    if ("action".equals(tag)) addAction(data, strings, attrs, attrSize, attrCount, currentFilter);
                    else if ("category".equals(tag)) addCategory(data, strings, attrs, attrSize, attrCount, currentFilter);
                    else if ("data".equals(tag)) addData(data, strings, attrs, attrSize, attrCount, currentFilter);
                    filterDepth++;
                }
            } else if (type == RES_XML_END_ELEMENT_TYPE && strings != null) {
                String tag = string(strings, u32(data, p + 20));
                if ("intent-filter".equals(tag) && currentFilter != null) {
                    boolean exported = exportedExplicit ? currentExported : true;
                    out.add(new GuestIntentFilterRecord(packageName, currentComponent,
                        currentType, currentFilter, exported));
                    currentFilter = null;
                    filterDepth = 0;
                } else if (filterDepth > 0 && !"intent-filter".equals(tag)) {
                    filterDepth--;
                } else if ("activity".equals(tag) || "activity-alias".equals(tag) ||
                           "service".equals(tag) || "receiver".equals(tag)) {
                    currentComponent = null;
                    currentType = null;
                    currentFilter = null;
                    filterDepth = 0;
                }
            }
            p += chunkSize;
        }
    }

    private static void addAction(byte[] d, String[] s, int attrs, int size, int count, IntentFilter f) {
        String v = findAttr(d, s, attrs, size, count, "name");
        if (v != null) try { f.addAction(v); } catch (Throwable ignored) { }
    }
    private static void addCategory(byte[] d, String[] s, int attrs, int size, int count, IntentFilter f) {
        String v = findAttr(d, s, attrs, size, count, "name");
        if (v != null) try { f.addCategory(v); } catch (Throwable ignored) { }
    }
    private static void addData(byte[] d, String[] s, int attrs, int size, int count, IntentFilter f) {
        String mime = findAttr(d, s, attrs, size, count, "mimeType");
        String scheme = findAttr(d, s, attrs, size, count, "scheme");
        String host = findAttr(d, s, attrs, size, count, "host");
        String port = findAttr(d, s, attrs, size, count, "port");
        String path = findAttr(d, s, attrs, size, count, "path");
        String prefix = findAttr(d, s, attrs, size, count, "pathPrefix");
        String pattern = findAttr(d, s, attrs, size, count, "pathPattern");
        String ssp = findAttr(d, s, attrs, size, count, "schemeSpecificPart");
        String sspPrefix = findAttr(d, s, attrs, size, count, "schemeSpecificPartPrefix");
        String sspPattern = findAttr(d, s, attrs, size, count, "schemeSpecificPartPattern");
        try {
            if (mime != null) f.addDataType(mime);
            if (scheme != null) f.addDataScheme(scheme);
            // Avoid compile-time references to API-specific SSP constants/methods.
            if (ssp != null) addSsp(f, ssp, 0);
            if (sspPrefix != null) addSsp(f, sspPrefix, 1);
            if (sspPattern != null) addSsp(f, sspPattern, 2);
            if (host != null) {
                int portValue = -1;
                try { if (port != null) portValue = Integer.parseInt(port); } catch (NumberFormatException ignored) { }
                f.addDataAuthority(host, portValue < 0 ? null : String.valueOf(portValue));
            }
            // IntentFilter pattern constants are stable as 0/1/2 but older AIDE
            // stubs may omit the symbolic fields, so keep the numeric forms local.
            if (path != null) f.addDataPath(path, 0);
            if (prefix != null) f.addDataPath(prefix, 1);
            if (pattern != null) f.addDataPath(pattern, 2);
        } catch (Throwable ignored) { }
    }

    private static void addSsp(IntentFilter filter, String value, int pattern) {
        try {
            java.lang.reflect.Method m = IntentFilter.class.getMethod(
                "addDataSchemeSpecificPart", String.class, Integer.TYPE);
            m.invoke(filter, value, Integer.valueOf(pattern));
            return;
        } catch (Throwable ignored) { }
        try {
            java.lang.reflect.Method m = IntentFilter.class.getMethod(
                "addDataSchemeSpecificPart", String.class);
            m.invoke(filter, value);
        } catch (Throwable ignored) { }
    }

    private static String findAttr(byte[] d, String[] s, int attrs, int size, int count, String wanted) {
        for (int i = 0; i < count; i++) {
            int a = attrs + i * size;
            String name = string(s, u32(d, a + 4));
            if (wanted.equals(name)) return value(d, a + 12, s).text;
        }
        return null;
    }

    private static String normalizeClass(String name, String pkg) {
        if (name == null) return null;
        if (name.length() == 0) return null;
        if (name.charAt(0) == '.') return pkg + name;
        if (name.indexOf('.') < 0) return pkg + "." + name;
        return name;
    }

    private static final class TypedValue {
        String text;
        boolean bool;
    }

    private static TypedValue value(byte[] d, int p, String[] s) {
        TypedValue v = new TypedValue();
        int type = d[p + 3] & 0xff;
        int raw = u32(d, p + 4);
        if (type == TYPE_STRING) v.text = string(s, raw);
        else if (type == TYPE_INT_BOOLEAN) { v.bool = raw != 0; v.text = v.bool ? "true" : "false"; }
        else if (raw != 0) v.text = String.valueOf(raw);
        return v;
    }

    private static String[] parseStringPool(byte[] d, int p, int size) {
        int stringCount = u32(d, p + 8);
        int flags = u32(d, p + 16);
        int stringsStart = u32(d, p + 20);
        int offsets = p + 28;
        String[] out = new String[stringCount];
        boolean utf8 = (flags & 0x00000100) != 0;
        for (int i = 0; i < stringCount; i++) {
            int off = u32(d, offsets + i * 4);
            int pos = p + stringsStart + off;
            try {
                if (utf8) out[i] = readUtf8(d, pos);
                else out[i] = readUtf16(d, pos);
            } catch (Throwable ignored) { out[i] = null; }
        }
        return out;
    }

    private static String readUtf8(byte[] d, int p) {
        int[] a = readLen8(d, p); p = a[1];
        int[] b = readLen8(d, p); int len = b[0]; p = b[1];
        try { return new String(d, p, len, "UTF-8"); } catch (Exception e) { return null; }
    }
    private static int[] readLen8(byte[] d, int p) {
        int len = d[p++] & 0xff;
        if ((len & 0x80) != 0) len = ((len & 0x7f) << 8) | (d[p++] & 0xff);
        return new int[] { len, p };
    }
    private static String readUtf16(byte[] d, int p) {
        int len = u16(d, p); p += 2;
        if ((len & 0x8000) != 0) { len = ((len & 0x7fff) << 16) | u16(d, p); p += 2; }
        try { return new String(d, p, len * 2, "UTF-16LE"); } catch (Exception e) { return null; }
    }
    private static String string(String[] a, int index) {
        return a != null && index >= 0 && index < a.length ? a[index] : null;
    }
    private static int u16(byte[] d, int p) { return (d[p] & 0xff) | ((d[p + 1] & 0xff) << 8); }
    private static int u32(byte[] d, int p) { return (d[p] & 0xff) | ((d[p + 1] & 0xff) << 8) | ((d[p + 2] & 0xff) << 16) | ((d[p + 3] & 0xff) << 24); }
}
