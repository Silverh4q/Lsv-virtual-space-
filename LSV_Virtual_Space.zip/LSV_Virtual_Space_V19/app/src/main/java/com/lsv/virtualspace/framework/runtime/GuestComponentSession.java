package com.lsv.virtualspace.framework.runtime;

/** Lightweight virtual lifecycle record owned by the ActivityManager-style layer. */
public final class GuestComponentSession {
    private final String packageName;
    private final String componentName;
    private final String componentType;
    private String state;
    private final long createdAt;

    public GuestComponentSession(String packageName, String componentName,
                                 String componentType, String state) {
        this.packageName = packageName;
        this.componentName = componentName;
        this.componentType = componentType;
        this.state = state;
        this.createdAt = System.currentTimeMillis();
    }

    public String getPackageName() { return packageName; }
    public String getComponentName() { return componentName; }
    public String getComponentType() { return componentType; }
    public String getState() { return state; }
    public long getCreatedAt() { return createdAt; }
    public void setState(String state) { this.state = state; }
}
