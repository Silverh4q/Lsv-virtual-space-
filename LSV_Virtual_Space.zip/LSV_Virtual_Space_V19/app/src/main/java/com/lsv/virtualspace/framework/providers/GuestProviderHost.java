package com.lsv.virtualspace.framework.providers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.CancellationSignal;
import android.content.res.AssetFileDescriptor;
import android.content.pm.ProviderInfo;

import com.lsv.virtualspace.guest.runtime.GuestComponentEnvironment;

import java.util.HashMap;
import java.util.Map;

/**
 * Hosts real guest ContentProvider instances inside the guest execution process.
 * Android performs the Provider attach step; LSV supplies the guest Context and
 * ProviderInfo rather than registering the guest package with system_server.
 */
public final class GuestProviderHost {
    private final Map<String, ContentProvider> providers = new HashMap<String, ContentProvider>();

    public synchronized ContentProvider get(ContextHolder holder, String packageName,
                                             String authority) throws Exception {
        String key = packageName + ":" + authority;
        ContentProvider cached = providers.get(key);
        if (cached != null) return cached;
        GuestComponentEnvironment env = GuestComponentEnvironment.open(holder.context, packageName);
        ProviderInfo info = findProvider(env.getPackageInfo().providers, authority);
        if (info == null) throw new IllegalStateException("Guest provider not found: " + authority);
        Class<?> type = env.getClassLoader().loadClass(info.name);
        Object value = type.newInstance();
        if (!(value instanceof ContentProvider)) throw new IllegalStateException("Guest provider class is invalid: " + info.name);
        ContentProvider provider = (ContentProvider) value;
        info.applicationInfo = env.getApplicationInfo();
        info.packageName = packageName;
        provider.attachInfo(env.getContext(), info);
        providers.put(key, provider);
        return provider;
    }

    private ProviderInfo findProvider(ProviderInfo[] values, String authority) {
        if (values == null || authority == null) return null;
        for (ProviderInfo info : values) {
            if (info == null || info.authority == null) continue;
            String[] parts = info.authority.split(";");
            for (String part : parts) if (authority.equals(part)) return info;
        }
        return null;
    }

    public synchronized void clearPackage(String packageName) {
        String prefix = packageName + ":";
        java.util.Iterator<String> it = providers.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            if (key.startsWith(prefix)) {
                ContentProvider provider = providers.get(key);
                try { provider.shutdown(); } catch (Throwable ignored) { }
                it.remove();
            }
        }
    }

    public static final class ContextHolder {
        public final android.content.Context context;
        public ContextHolder(android.content.Context context) { this.context = context; }
    }

    public Bundle query(android.content.Context host, String packageName, String authority,
                        Uri uri, String[] projection, String selection, String[] args,
                        String sortOrder) throws Exception {
        Cursor cursor = get(new ContextHolder(host), packageName, authority).query(
            uri, projection, selection, args, sortOrder);
        return cursorToBundle(cursor);
    }

    public Bundle call(android.content.Context host, String packageName, String authority,
                       String method, String arg, Bundle extras) throws Exception {
        Bundle result = get(new ContextHolder(host), packageName, authority).call(method, arg, extras);
        return result == null ? new Bundle() : result;
    }

    public String getType(android.content.Context host, String packageName, String authority,
                          Uri uri) throws Exception {
        return get(new ContextHolder(host), packageName, authority).getType(uri);
    }

    public Uri insert(android.content.Context host, String packageName, String authority,
                      Uri uri, ContentValues values) throws Exception {
        return get(new ContextHolder(host), packageName, authority).insert(uri, values);
    }

    public int delete(android.content.Context host, String packageName, String authority,
                      Uri uri, String selection, String[] args) throws Exception {
        return get(new ContextHolder(host), packageName, authority).delete(uri, selection, args);
    }

    public int update(android.content.Context host, String packageName, String authority,
                      Uri uri, ContentValues values, String selection, String[] args) throws Exception {
        return get(new ContextHolder(host), packageName, authority).update(uri, values, selection, args);
    }

    private Bundle cursorToBundle(Cursor cursor) {
        Bundle out = new Bundle();
        if (cursor == null) return out;
        try {
            String[] columns = cursor.getColumnNames();
            out.putStringArray("columns", columns);
            java.util.ArrayList<Bundle> rows = new java.util.ArrayList<Bundle>();
            int count = 0;
            while (cursor.moveToNext() && count < 500) {
                Bundle row = new Bundle();
                for (int i = 0; i < columns.length; i++) {
                    int type = cursor.getType(i);
                    if (type == Cursor.FIELD_TYPE_NULL) row.putString(columns[i], null);
                    else if (type == Cursor.FIELD_TYPE_INTEGER) row.putLong(columns[i], cursor.getLong(i));
                    else if (type == Cursor.FIELD_TYPE_FLOAT) row.putDouble(columns[i], cursor.getDouble(i));
                    else if (type == Cursor.FIELD_TYPE_BLOB) row.putByteArray(columns[i], cursor.getBlob(i));
                    else row.putString(columns[i], cursor.getString(i));
                }
                rows.add(row);
                count++;
            }
            out.putParcelableArrayList("rows", rows);
            out.putInt("count", count);
        } finally {
            cursor.close();
        }
        return out;
    }
}
