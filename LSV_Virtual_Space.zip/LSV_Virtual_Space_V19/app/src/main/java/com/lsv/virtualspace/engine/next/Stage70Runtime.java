package com.lsv.virtualspace.engine.next;

import android.content.Context;
import com.lsv.virtualspace.ipc.*;
import com.lsv.virtualspace.process.*;
import com.lsv.virtualspace.security.GuestIsolationPolicy;
import com.lsv.virtualspace.virtual.GuestLaunchInfo;

/**
 * Steps 51-70 integration shell. It prepares and validates guest launches but
 * never pretends to create an Android guest process when no real backend exists.
 */
public final class Stage70Runtime {
    private final BackendRegistry registry=new BackendRegistry();
    private final GuestProcessSupervisor supervisor=new GuestProcessSupervisor();
    private final GuestIsolationPolicy policy=new GuestIsolationPolicy();
    private final GuestProcessBridge fallback=new UnavailableGuestProcessBridge();
    private final Context context;
    public Stage70Runtime(Context c){context=c.getApplicationContext();}
    public BackendRegistry getBackends(){return registry;}
    public GuestProcessSupervisor getSupervisor(){return supervisor;}
    public GuestIsolationPolicy getIsolationPolicy(){return policy;}
    public GuestLaunchResult prepare(GuestLaunchInfo info){
        if(info==null)return GuestLaunchResult.rejected("Missing guest launch information.");
        supervisor.prepare(info.getPackageName());
        GuestBackendContract b=registry.getSupported();
        GuestProcessBridge bridge=b==null?fallback:b.getProcessBridge();
        GuestLaunchResult r=bridge.prepare(new GuestLaunchRequest(info.getPackageName(),info.getActivityName(),info.getApkPath(),info.getDataPath()));
        if(r.isAccepted())supervisor.ready(info.getPackageName());else supervisor.fail(info.getPackageName(),r.getMessage());
        return r;
    }
    public GuestLaunchResult start(GuestLaunchInfo info){
        if(info==null)return GuestLaunchResult.rejected("Missing guest launch information.");
        GuestBackendContract b=registry.getSupported();
        GuestProcessBridge bridge=b==null?fallback:b.getProcessBridge();
        GuestLaunchResult r=bridge.start(new GuestLaunchRequest(info.getPackageName(),info.getActivityName(),info.getApkPath(),info.getDataPath()));
        if(r.isAccepted())supervisor.running(info.getPackageName());else supervisor.fail(info.getPackageName(),r.getMessage());
        return r;
    }
    public void stop(String packageName){if(packageName==null)return;GuestBackendContract b=registry.getSupported();if(b!=null)b.getProcessBridge().stop(packageName);else fallback.stop(packageName);supervisor.stop(packageName);}
}
