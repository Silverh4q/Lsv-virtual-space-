package com.lsv.virtualspace.profiles;
public final class GameCompatibilityReport {
    private final String packageName,gameName; private final boolean known,ready; private final String notes;
    public GameCompatibilityReport(String p,String n,boolean k,boolean r,String x){packageName=p;gameName=n;known=k;ready=r;notes=x;}
    public String getPackageName(){return packageName;} public String getGameName(){return gameName;} public boolean isKnown(){return known;} public boolean isReady(){return ready;} public String getNotes(){return notes;}
}
