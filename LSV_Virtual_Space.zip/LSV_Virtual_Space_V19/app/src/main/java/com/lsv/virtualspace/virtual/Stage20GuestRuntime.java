package com.lsv.virtualspace.virtual;

import android.content.Context;

import com.lsv.virtualspace.apps.VirtualApp;
import com.lsv.virtualspace.diagnostics.GuestCapabilityAnalyzer;
import com.lsv.virtualspace.diagnostics.GuestCapabilityReport;
import com.lsv.virtualspace.routing.GuestIntentRouter;
import com.lsv.virtualspace.lifecycle.GuestApplicationRegistry;

/**
 * Stage 10-20 coordinator. It prepares all host-side structures but deliberately
 * refuses to claim arbitrary guest execution until the real process/Binder backend exists.
 */
public final class Stage20GuestRuntime {
    private final GuestRuntimeConfig config;
    private final GuestCapabilityAnalyzer analyzer;
    private final GuestIntentRouter router;
    private final GuestApplicationRegistry lifecycle;

    public Stage20GuestRuntime(Context context, VirtualActivityManager activities) {
        config = GuestRuntimeConfig.safeDefault();
        analyzer = new GuestCapabilityAnalyzer(context);
        router = new GuestIntentRouter(activities);
        lifecycle = new GuestApplicationRegistry();
    }

    public GuestCapabilityReport inspect(VirtualApp app) {
        return analyzer.analyze(app);
    }

    public GuestRuntimeStatus status(VirtualApp app) {
        return GuestExecutionGate.evaluate(config, inspect(app));
    }

    public GuestIntentRouter getIntentRouter() { return router; }
    public GuestApplicationRegistry getLifecycle() { return lifecycle; }
    public GuestRuntimeConfig getConfig() { return config; }
}
