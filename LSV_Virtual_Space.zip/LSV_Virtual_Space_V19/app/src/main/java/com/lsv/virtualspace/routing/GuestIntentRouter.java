package com.lsv.virtualspace.routing;

import android.content.Intent;

import com.lsv.virtualspace.virtual.VirtualActivityManager;

/** Resolves intents against LSV metadata rather than Android's installed package manager. */
public final class GuestIntentRouter {
    private final VirtualActivityManager activities;

    public GuestIntentRouter(VirtualActivityManager activities) {
        this.activities = activities;
    }

    public GuestIntentRoute route(String packageName, Intent intent) {
        if (packageName == null || intent == null) return null;
        String component = intent.getComponent() == null ? null
            : intent.getComponent().getClassName();
        if (component != null) {
            return new GuestIntentRoute(packageName, component, intent.getAction());
        }
        String launchable = activities.findLaunchableActivity(packageName);
        if (launchable == null) return null;
        return new GuestIntentRoute(packageName, launchable, intent.getAction());
    }
}
