package com.lsv.virtualspace.graphics;
public final class GuestGraphicsProfile {
    private final GuestGraphicsMode mode; private final int minGlesMajor; private final boolean vulkanPreferred;
    public GuestGraphicsProfile(GuestGraphicsMode m,int g,boolean v){mode=m;minGlesMajor=g;vulkanPreferred=v;}
    public GuestGraphicsMode getMode(){return mode;} public int getMinGlesMajor(){return minGlesMajor;} public boolean isVulkanPreferred(){return vulkanPreferred;}
}
