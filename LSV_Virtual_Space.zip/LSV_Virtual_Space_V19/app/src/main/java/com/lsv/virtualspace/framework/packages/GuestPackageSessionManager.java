package com.lsv.virtualspace.framework.packages;

import java.util.HashMap;
import java.util.Map;

public final class GuestPackageSessionManager {
    private final Map<String, GuestPackageSession> sessions = new HashMap<String, GuestPackageSession>();
    public synchronized GuestPackageSession open(String packageName) {
        GuestPackageSession s = sessions.get(packageName);
        if (s == null) { s = new GuestPackageSession(packageName); sessions.put(packageName, s); }
        s.setActive(true); return s;
    }
    public synchronized void close(String packageName) { GuestPackageSession s = sessions.get(packageName); if (s != null) s.setActive(false); }
    public synchronized GuestPackageSession get(String packageName) { return sessions.get(packageName); }
}
