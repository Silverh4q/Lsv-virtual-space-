package com.lsv.virtualspace.guest;

import com.lsv.virtualspace.apps.VirtualApp;

import java.util.HashMap;
import java.util.Map;

import dalvik.system.DexClassLoader;

/** Keeps one prepared class loader per active guest package. */
public class GuestClassLoaderRegistry {
    private final Map<String, DexClassLoader> loaders =
        new HashMap<String, DexClassLoader>();

    public synchronized DexClassLoader get(VirtualApp app) {
        return loaders.get(app.getPackageName());
    }

    public synchronized void put(VirtualApp app, DexClassLoader loader) {
        loaders.put(app.getPackageName(), loader);
    }

    public synchronized void remove(String packageName) {
        loaders.remove(packageName);
    }

    public synchronized void clear() {
        loaders.clear();
    }
}
