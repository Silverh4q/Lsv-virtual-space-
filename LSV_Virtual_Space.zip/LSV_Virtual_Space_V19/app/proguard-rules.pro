# LSV Virtual Space release rules. No custom shrinking rules required.
