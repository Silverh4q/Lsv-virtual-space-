# LSV Virtual Space runtime roadmap

## Completed
- APK import from Android storage
- private APK repository
- per-app private data directories
- package metadata parsing
- exported activity discovery
- guest session state
- runtime controller
- execution-backend interface

## Current backend
`MetadataGuestRuntime` is intentionally non-executing. It prepares and
describes a guest but never claims that an arbitrary APK is running.

## Actual guest execution
A real non-root execution backend needs to provide:
- a supported application virtualization runtime
- guest process/application lifecycle
- package and resource loading
- activity/service/provider compatibility
- permission mediation
- compatible native library loading
- 32/64-bit handling as appropriate
- graphics compatibility for games

This should be integrated as a self-contained backend behind `GuestRuntime`.

## Google Play
Play Services and Play Store should be treated as a separate compatibility
layer. Merely copying Google's APKs into LSV private storage is not sufficient.


## Steps 5-10 completed in this milestone

5. Guest artifact layer: dex/resource preparation and class-loader registry.
6. Guest component layer: activity/service/provider resolution.
7. Policy layer: virtual permission records and private guest data paths.
8. Compatibility layer: Android API, ABI, native-library and graphics diagnostics.
9. Google layer: host GMS/Play Store detection and guest-compatibility report.
10. Integration layer: `GuestEngine`/`PreparationGuestEngine` wired into `VirtualRuntimeController`.

These are preparation/integration layers. A real arbitrary-APK guest process still requires the actual Android framework virtualization implementation (process hosting, Binder/service routing, ActivityManager/PackageManager compatibility, and lifecycle interception). LSV does not falsely mark that capability as available.


## Steps 11-20 completed in this milestone

11. Runtime configuration and explicit execution gate.
12. Guest resource locator for APK resource inspection.
13. Guest DexClassLoader factory for preparation/diagnostics.
14. Guest intent/component routing model.
15. Guest application lifecycle registry.
16. Stable per-guest storage layout.
17. Capability report covering metadata/resources/dex/native readiness.
18. Central execution gate that prevents false "running" state.
19. Stage20 coordinator wired into VirtualRuntimeController.
20. AIDE-friendly Java-8 integration with no native sources or lambda syntax.

The process/Binder backend remains intentionally disabled. These steps make the
architecture ready for a legitimate virtualization engine without claiming that
Android arbitrary-APK execution has been solved.

## Steps 21-50
21-25: component registry, lifecycle/security policy, execution planning.
26-30: guest isolation and routing support.
31-35: graphics/input capability detection.
36-40: performance and storage management.
41-45: compatibility catalog and game diagnostics.
46-50: crash reporting, service registry and Stage50 coordinator.

Game profiles included for diagnostic/compatibility purposes only: Free Fire, Free Fire MAX, Call of Duty: Mobile, PUBG Mobile (package identifiers may vary by region/version). No anti-cheat bypass, memory modification, injection, or integrity circumvention is implemented.

## Steps 51-70
- Guest process state/supervision model added.
- Pluggable guest-process IPC contract added.
- Explicit unavailable-backend implementation retained as the default.
- Guest isolation policy made explicit.
- Guest component table added.
- Backend registry added for a future real virtualization implementation.
- Stage70Runtime coordinates preparation/start/stop without falsely claiming guest execution.


## Steps 71-90 — Framework-facing virtualization layer

- Step 71: Real host Activity proxy endpoint for virtual activity routes.
- Step 72: Guest intent envelope and proxy intent creation.
- Step 73: Virtual task/session records for foreground guest routes.
- Step 74: Logical service binding router.
- Step 75: Namespaced provider authority router.
- Step 76: Per-guest permission decision context.
- Step 77: Stable guest configuration snapshot (locale/API).
- Step 78: ABI-specific native-library staging; guest `.so` files are not loaded into the host process.
- Step 79: Graphics surface hand-off contract for a future real renderer backend.
- Step 80: Crash boundary for backend failures.
- Steps 81-90: Integration/diagnostic groundwork for task cleanup, service/provider lifecycle, graphics hand-off, native ABI reporting, and modern Android compatibility.

### Important runtime boundary

These steps provide actual Android-facing host routing and lifecycle endpoints, but they do not claim to execute an arbitrary third-party APK's Activity inside LSV. A full general-purpose virtual Android framework requires substantially deeper PackageManager/ActivityManager/Binder virtualization and must respect Android version-specific restrictions.

## Steps 91-110 — Framework/Binder virtualization boundary

Implemented:
- Guest Binder request/reply models and operation codes.
- Host-side Binder router for guest-scoped requests.
- Virtual service binding manager with per-package binding counts.
- Virtual provider authority namespace and provider routing envelope.
- Guest package session lifecycle manager.
- Lifecycle bridge integrated with the host proxy Activity.
- GuestFrameworkHost now exposes Binder dispatch and guest lifecycle state.
- Explicit capability failures for operations that require privileged Android system Binder access.

Important Android limitation:
- Ordinary applications cannot replace or globally intercept system ActivityManagerService, PackageManagerService, or system Binder transactions. These classes therefore remain host-side virtualization boundaries rather than pretending to be replacements for Android internals.
- Full arbitrary APK execution still requires a dedicated virtualization engine capable of safely reproducing the required framework contracts on each Android release.

## Steps 111-130 — Guest application boundary

Implemented a real preparation boundary for guest application execution without falsely executing arbitrary imported APK code in the LSV host process.

- Guest bootstrap metadata planning (`Application` class and target SDK)
- Guest context path specification for data/files/cache
- Guest context boundary with guest Resources/ClassLoader injection points
- Guest component construction plans for activities/services/providers
- Guest resource session manager
- Android API compatibility capability detection
- Guest runtime preparation coordinator
- Integration with `VirtualCore` and `GuestFrameworkHost`
- Proxy activity now displays the prepared guest application metadata and Android compatibility state

Security/architecture note: an imported third-party APK is untrusted code. LSV does not instantiate its `Application` or components inside the host process merely because they were imported. A production arbitrary-APK runtime needs a dedicated isolated execution process and a complete, version-specific Android framework virtualization backend.


## Steps 131-150
- Dedicated LSV guest host process boundary via an Android Service running under `:guest`.
- Guest process command/controller and explicit lifecycle boundary.
- Guest execution boundary object for future isolated guest engine integration.
- Storage permission helper with legacy `READ_EXTERNAL_STORAGE` handling through API 32.
- Modern storage uses Storage Access Framework; no broad storage-management permission is requested.
- APK export to user-selected storage via `ACTION_CREATE_DOCUMENT`.
- Project resource completion: colors, dimensions, theme, and XML file paths.
- These components prepare isolation and storage access but do not claim arbitrary guest APK code executes in the separate process yet.

## Steps 151-170 — Guest process IPC and lifecycle boundary

- Versioned Messenger/Binder IPC envelope for the dedicated `:guest` host process.
- Guest process client for prepare/start/stop commands.
- Activity-result routing model with request-code namespacing.
- Conservative guest-process crash/restart policy.
- Configuration-change bridge for orientation, UI mode, density, and font-scale state.
- Surface handoff contract for future guest rendering.
- Input dispatch boundary for future guest rendering/input integration.
- AndroidManifest audit: explicit `com.lsv.virtualspace` package, `:guest` service process, proxy Activity, launcher Activity, and API-limited legacy storage permissions.
- Storage remains SAF-based on modern Android; no broad `MANAGE_EXTERNAL_STORAGE` permission is added.

This stage provides the host-side IPC/lifecycle boundary. It does not claim that Android's privileged system ActivityManager/PackageManager/Binder services have been replaced, nor does it execute arbitrary imported APK code inside the host process.
