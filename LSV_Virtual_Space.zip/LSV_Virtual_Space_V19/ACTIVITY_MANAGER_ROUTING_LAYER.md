# LSV ActivityManager-style Routing Layer

This layer sits on top of the framework Binder boundary and adds generic manifest-driven component resolution.

## Added
- Android binary `AndroidManifest.xml` intent-filter parser implemented without hidden framework APIs.
- Virtual intent-filter records for activities, activity-aliases, services and receivers.
- Actions, categories, MIME types, schemes, authorities, ports and common path matching.
- Intent-filter priority support.
- Generic activity/service resolution through `IntentFilter.match()`.
- `GuestActivityManagerRouter` for ActivityManager-style guest routing.
- Binder `RESOLVE_INTENT` operation for guest-side framework requests.
- Package registration now registers the APK's manifest filter graph.

## Resolution model
1. Explicit component is validated against the virtual PackageInfo.
2. Otherwise the guest manifest filter graph is searched.
3. Only exported matching components are returned by cross-component routing.
4. The selected component remains a guest class name; execution continues through the existing LSV proxy/runtime layer.

## Deliberate boundary
This does not hook Android system_server or replace the host PackageManager. It is an application-side virtual framework facade.

## Verification
- Java source lexical brace audit: passed.
- Java lambda scan: 0 lambda expressions.
- APK/ZIP work is structural; Android SDK/Gradle compilation was not available in this environment, so AIDE compilation still needs to be performed on-device.
