# LSV Real Virtual Guest Stage

This stage changes LSV from an external Android launch fallback to an in-process guest Activity bootstrap.

## Launch path

1. LSV starts the declared `GuestActivityProxy` in the dedicated `:guest` process.
2. `LsvApplication.attachBaseContext()` installs `GuestInstrumentation` before the proxy Activity is constructed.
3. `GuestInstrumentation.newActivity()` recognizes the LSV proxy intent and constructs the guest Activity class from the private APK/split class loader.
4. Android's own ActivityThread performs the framework Activity attachment for that guest Activity. LSV does not invoke `Activity.attach()` directly.
5. Before `Instrumentation.callActivityOnCreate()`, `GuestExecutionSession` replaces the Activity's application, metadata, intent and base Context with the virtual guest equivalents.
6. The guest Application is created with a private `GuestContext` and receives `onCreate()`.
7. The guest Activity receives the normal Instrumentation lifecycle callbacks while its window remains the Android-managed window for the LSV guest process.

## Private guest resources

- APK and split APKs are staged into the LSV private repository.
- Dex files are loaded through a read-only staged path.
- Guest resources are attached through an AssetManager containing the base and split APKs.
- Native libraries are extracted to the guest private native directory for the device ABI.
- Guest package/data/resource paths are exposed through `GuestContext`.

## Hidden framework bootstrap

A small bootstrap is included for Android releases that enforce non-SDK restrictions. It is used only to make the framework metadata needed by the client-side instrumentation bridge accessible. The normal launch path no longer calls `Activity.attach()` reflectively.

## Important compatibility boundary

This is an application-level virtualization engine. It is not an Android system image, emulator, root environment, or replacement Android framework. Apps that depend on privileged system services, Play Integrity/DRM, protected providers, special SELinux domains, or device-specific native behavior can still require additional guest service virtualization.

LSV deliberately does not fall back to Android's external PackageManager launch from the **Launch** button. If the virtual instrumentation bridge cannot start, the user gets a virtual-engine failure instead of the target being opened outside LSV.
