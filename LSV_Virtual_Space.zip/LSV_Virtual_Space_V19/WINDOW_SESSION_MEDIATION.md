# Window Session Mediation

LSV records a guest-owned logical session for every WindowManager add/update/remove operation.

The real Android window token remains owned by ActivityThread/system_server. LSV never fabricates a Binder window token or claims another package at the kernel boundary. For overlay windows, LSV requires the guest package to have the virtual overlay grant before the real WindowManager call is attempted. The actual host permission therefore remains controlled by LSV.
