# Guest Context + Window Identity Layer

This layer connects the virtual package database to the guest-facing Context and
makes WindowManager operations carry a single LSV-owned guest identity record.

Implemented:
- GuestContext exposes the virtual PackageManager facade for guest-aware code.
- GuestContext resolves guest package/application metadata and manifest queries.
- GuestContext routes clipboard and notification operations through the same Binder/service boundary.
- GuestContext returns a runtime WindowManager proxy that records add/update/remove operations against the guest namespace.
- Window LayoutParams keep the real host package at the Android Binder boundary; the guest package remains virtual state, avoiding a false kernel/package identity.
- Clipboard and notification state is isolated by guest package name.

The next framework layer is lifecycle-backed window sessions, provider/client routing,
and concrete notification/clipboard UI mediation. Those are separate from this layer.
