# LSV Virtual Space — AIDE / Engine Finalization

## What was changed

The previous `virtual-engine` module from the Sandbox reference was removed from the build. Its old `com.lody.*` Java/AIDL/native implementation was written for a different project and Android assumptions, and it produced the large AIDE error set shown during the build.

Sandbox1 was used as an **architecture reference only**. LSV now uses its own `com.lsv.virtualspace` classes and public Android APIs.

## AIDE rules

- One application module: `:app`
- Java 8 syntax
- No Java lambdas
- No Android hidden/internal classes
- No external AndroidX dependency required by the engine
- No custom Gradle signing configuration
- Direct SDK/version literals in `app/build.gradle`
- No required NDK build step

## SDK settings

```groovy
compileSdkVersion 35
minSdkVersion 23
targetSdkVersion 35
versionCode 1
versionName '1.0.0'
```

## ARM native bridge

Prebuilt, self-contained ABI bridge libraries are packaged for:

- `arm64-v8a`
- `armeabi-v7a`

They are loaded optionally by `NativeRuntimeBridge`. The bridge is intentionally independent of the virtualization policy so the project can build in AIDE without requiring an NDK installation.

The native bridge is **not** an anti-cheat, memory editor, injector, or hidden-framework hook.

## Execution boundary

The LSV engine prepares virtual package metadata, private storage, component routing, guest process state, resources, and IPC models. For arbitrary third-party APK execution on current Android, the supported execution fallback is Android's own PackageInstaller/package sandbox. LSV does not claim to replace privileged AMS/PMS/Binder services from an ordinary application.

## Important when replacing the project in AIDE

Use a **fresh project directory** from this ZIP. Do not merge it over the previous project directory. The old `virtual-engine` directory must not remain in the project, otherwise AIDE may continue indexing its incompatible sources.
