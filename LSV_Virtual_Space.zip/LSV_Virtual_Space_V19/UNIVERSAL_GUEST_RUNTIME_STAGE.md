# LSV Universal Guest Runtime Stage

This stage changes the project from an APK loader with a proxy Activity into a generic guest bootstrap path.

## Guest bootstrap

1. LSV imports the APK without installing it into Android's real PackageManager.
2. The guest base/split APKs are attached to a dedicated AssetManager.
3. Guest Resources are constructed from those APKs using the device configuration.
4. A DexClassLoader loads the guest Application and Activity classes.
5. The guest Application is attached to GuestContext and receives onCreate().
6. The guest Activity is instantiated by the :guest process Instrumentation bridge.
7. Before guest Activity onCreate(), LSV binds the guest Context, Resources, Application, ActivityInfo and Intent.
8. The guest class loader is installed as the thread context class loader during Activity creation.
9. Guest data/native-library paths remain under the virtual application's private directory.

## Android framework boundary

The proxy Activity is only the route endpoint. It is not the guest UI. The guest Activity is instantiated in the LSV :guest process.

The bridge uses the hidden framework state only where Android's public Activity API does not expose the required attachment operation. Hidden API access is attempted through the existing LSV bootstrap. If the device rejects that boundary, the failure is surfaced as a guest bootstrap failure rather than silently claiming that the guest is virtualized.

## Universal policy

No package-name checks or Unity/Flutter/game-specific resource fixes are used. The same guest bootstrap is used for every imported APK.

## Current scope

Implemented here: guest package metadata, base/split resources, class loading, native-library extraction, private data paths, guest Application bootstrap, guest Activity context/application/resource binding, Activity lifecycle routing, and dedicated guest process routing.

Still separate framework work: complete PackageManager/Binder service virtualization for APIs that directly query Android's system services, plus full service/provider/receiver process hosting. Those are framework layers, not per-application patches.
