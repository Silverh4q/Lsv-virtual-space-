# LSV guest launch crash fix

The previous guest bootstrap could crash on modern Android because it attempted to modify hidden Activity fields and to attach a guest Application reflectively. The launch path now leaves Android's ActivityThread-owned attachment intact.

Changes:
- Guest Activity preparation uses the public `Activity.setIntent()` and `setTheme()` APIs.
- No reflective writes to `Activity.mBase`, `Activity.mApplication`, or `Activity.mActivityInfo`.
- Guest Application reflection is best-effort only; failure no longer kills the guest process.
- A visible themed launch dialog with a centered spinner is shown from the LSV main screen while the guest process starts.
- The project remains Java-8/AIDE friendly and contains no Java lambda expressions.

This prevents the specific hidden-field bootstrap crash. It does not claim that every guest APK can execute fully on every Android/OEM build.
