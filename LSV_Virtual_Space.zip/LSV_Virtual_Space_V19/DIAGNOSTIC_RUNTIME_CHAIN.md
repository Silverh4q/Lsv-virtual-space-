# LSV Virtual Space — Continuous Runtime Verification Chain

This build follows the continuous implementation rule: complete the dependency chain in one pass instead of stopping after a single numbered step.

## Runtime chain implemented in this build

1. Launch transaction creation
2. Guest package identity capture
3. Guest component identity capture
4. Guest process attach breadcrumb
5. Uncaught Java exception handler installation
6. Persistent crash-report directory
7. Runtime event timeline
8. Package lookup diagnostics
9. Package metadata diagnostics
10. Activity resolution diagnostics
11. Native-library preparation diagnostics
12. Guest class-loader diagnostics
13. Guest resource creation diagnostics
14. Guest Application creation diagnostics
15. Application context attach diagnostics
16. Application.onCreate diagnostics
17. Framework registration diagnostics
18. Guest Activity creation diagnostics
19. Guest Activity context binding diagnostics
20. Activity.onCreate diagnostics
21. Activity lifecycle breadcrumbs
22. WindowManager operation breadcrumbs
23. Guest system-service operation breadcrumbs
24. Guest-process heartbeat/watchdog
25. Process-disappearance detection
26. 25-point pre-launch runtime verification
27. Host crash-report presentation
28. Crash report copy-to-clipboard action
29. Persisted latest-report retrieval
30. Java 8 / AIDE static source audit

## Important validation boundary

This build records and reports runtime failures, but a real Android/AIDE installation test is still required before claiming arbitrary third-party guest compatibility. The project does not claim that every modern APK will run merely because the diagnostic chain passes.

## Expected debugging result

A guest failure should now produce one of:

- JAVA_EXCEPTION
- GUEST_ACTIVITY_EXCEPTION
- APPLICATION_BOOTSTRAP_FAILURE
- PACKAGE_METADATA_FAILURE
- ACTIVITY_RESOLUTION_FAILURE
- PROCESS_DISAPPEARED
- PROCESS_NEVER_OBSERVED

with the last known runtime stage and timeline preserved.
