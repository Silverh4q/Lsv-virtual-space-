# LSV Guest Process Bootstrap Hardening

This pass makes the :guest process deterministic and observable.

1. LsvApplication stays lightweight in :guest.
2. GuestProcessService is the first heavy bootstrap boundary.
3. GuestProcessService initializes VirtualCore and the optional native bridge.
4. GuestInstrumentation is installed before the host is told READY.
5. Host waits for a Binder/Messenger READY response before starting GuestActivityProxy.
6. Host and guest share one pending diagnostic transaction seed.
7. GuestExecutionSession preserves that transaction instead of starting a second report.
8. Process state is persisted for post-mortem inspection.
9. Watchdog timeout is longer than the explicit handshake timeout and does not overwrite detailed bootstrap failures.
10. Instrumentation installation failures now include the underlying exception description.

This does not claim device runtime success. It removes a specific startup race and makes the next Android 16 failure boundary observable.
