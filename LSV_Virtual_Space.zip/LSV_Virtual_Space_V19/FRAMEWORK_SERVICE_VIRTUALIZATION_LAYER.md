# LSV Virtual Space — Framework Service Virtualization Layer

This stage moves LSV from a collection of guest helpers toward an actual host/guest framework boundary.

## Implemented in this layer

- Virtual package registry backed by imported APK metadata.
- Stable per-package virtual UID/user identity model.
- Per-guest permission decision manager.
- Provider authority registry and virtual authority mapping.
- Central Binder request router for package, permission, activity, service and provider operations.
- Real Android Binder boundary (`GuestFrameworkService`) between `:guest` and the host process.
- Guest Binder client with lazy host-framework connection.
- Guest `Context` permission checks routed through the framework Binder.
- Host-framework service binding is explicitly distinguished from guest service routing, preventing recursive proxying.
- Existing activity/service/broadcast proxy routing remains package-generic.

## Architectural rule

No package-name-specific behavior is introduced. All decisions are derived from the guest APK's package metadata and the guest's virtual identity.

## Important scope

This is a framework boundary, not yet a complete replacement for Android system_server. In particular, a future layer still needs full lifecycle hosting for guest Services and ContentProviders, broader system-service mediation, persistent cross-process virtual state, and Play Services compatibility. Those pieces should build on this Binder boundary rather than adding APK-specific patches.
