# LSV Virtual Space — Universal Guest Context Fix

This build moves the latest resource/context repair into the generic guest runtime instead of targeting any individual application.

## Changes
- Added `GuestActivityContextBridge`.
- Guest Activities now receive the prepared guest `Context`/resource set on the framework-created Activity when Android permits the corresponding framework fields.
- Guest `Resources` are constructed from the complete base/split APK path list with an independent configuration snapshot.
- Guest theme/resource caches are updated through the same generic bridge.
- No Unity, Flutter, game, or package-specific branches were added.
- Java 8 compatible; no lambda expressions.
- Existing non-root architecture, overlay permission, APK import, ARM64 native-library extraction, and guest-process routing are retained.

## Important
The bridge is deliberately best-effort around Android framework implementation details. Android 16 can reject non-SDK reflection on some devices. This build therefore never converts that rejection into an application-specific workaround or a host-process crash.

The project could not be compiled in this container because a Gradle executable/wrapper is not present. Java source/brace/lambda audits were completed successfully. AIDE should perform the authoritative Android build.
